/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafos;

import java.util.ArrayList;

/**
 *
 * @author HOME
 */
public class Grafo {
    public ArrayList<Vertice> vertice;
    public ArrayList<Arco> arcos;

    public Grafo() {
        this.vertice = new ArrayList();
        this.arcos = new ArrayList();
    }
    
    public boolean insertarVertice(Vertice v){
        if(this.vertice.contains(v))
            return false;
        return this.vertice.add(v);
    }
    
    public boolean insertarArco(Arco a) {
        if(arcos.contains(a) || !vertice.contains(a.origen) || !vertice.contains(a.destino))
            return false;
        if(arcos.add(a))
            if(a.origen.arcoSaliente.add(a))
                return true;
            else{
                arcos.remove(a);
                return false;
            }
        return false;
    }
    
    public boolean sonAdyacentes(Vertice a, Vertice b){
        return (a.esAdyacente(b) || a.esAdyacente(b));
    }
    
    public int gradoEntrada(Vertice a){
        int grado = 0;
        for(Arco b: arcos){
            if(b.destino.equals(a))
                grado++;
        }
        return grado;
    }
    
    public int gradoSalida(Vertice v){
        if(this.vertice.contains(v))
            return v.gradoSalida();
        return -1;
    }
    
    public int grado(Vertice V){
        return this.gradoEntrada(V) + gradoSalida(V);
    }
}
