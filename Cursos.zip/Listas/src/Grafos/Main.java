/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafos;

/**
 *
 * @author HOME
 */
public class Main {
    public static void main(String[] args) {
        Grafo g = new Grafo();
        Vertice a = new Vertice('A');
        Vertice b = new Vertice('B');
        Vertice c = new Vertice('C');
        /*
        g.vertice.add(a);
        g.vertice.add(b);
        g.vertice.add(c);
        */
        Arco ab = new Arco(a,b,null);
        Arco bc = new Arco(b,c,null);
        /*
        g.arcos.add(ab);
        a.arcoSaliente.add(ab);
        
        g.arcos.add(bc);
        a.arcoSaliente.add(bc);*/
        System.out.println(g.insertarVertice(a));
        System.out.println(g.insertarVertice(c));
        System.out.println(g.insertarVertice(b));
        System.out.println(g.insertarArco(ab));
        System.out.println(g.insertarArco(bc));
        System.out.println(g.gradoEntrada(a));
        System.out.println(g.grado(a));
        System.out.println(g.gradoSalida(a));
        
    }
}
