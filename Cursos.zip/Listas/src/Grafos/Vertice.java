/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafos;

import java.util.ArrayList;

/**
 *
 * @author HOME
 */
public class Vertice {
    public Comparable ponderacion;
    ArrayList<Arco> arcoSaliente;

    public Vertice(Comparable ponderacion) {
        this.ponderacion = ponderacion;
        this.arcoSaliente = new ArrayList<>();

    }
    
    public boolean esAdyacente(Vertice a){
        for(Arco b: arcoSaliente){
            if(b.destino.equals(a)){
                return true;
            }
        }
        return false;
    }
    public int gradoSalida(){
        return this.arcoSaliente.size();
    }
}
