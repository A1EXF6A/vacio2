/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafos;

/**
 *
 * @author HOME
 */
public class Arco {
    public Vertice origen;
    public Vertice destino;
    public Comparable ponderacion;

    public Arco(Vertice arigen, Vertice destino, Comparable ponderacion) {
        this.origen = arigen;
        this.destino = destino;
        this.ponderacion = ponderacion;
    }
}
