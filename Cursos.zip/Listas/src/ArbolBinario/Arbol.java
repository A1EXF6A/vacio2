/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolBinario;

/**
 *
 * @author HOME
 */
public class Arbol {
    public NodoBin raíz;

    public Arbol() {
        this.raíz = null;
    }

    void imprimirSimetrico() {
        if (this.raíz != null)
            this.raíz.imprimirSimetrico();
    }
    
    boolean insertarLexicografico(Comparable dato) {
        if (this.raíz != null)
            return this.raíz.insertarLexicografico(dato);
        this.raíz = new NodoBin(dato);
        return true;
    }
    
    void imprimirPosorden() {
        if (this.raíz != null)
            this.raíz.imprimirPosorden();
    }
    
    void imprimirPreorden() {
        if (this.raíz != null)
            this.raíz.imprimirPreorden();
    }
    
    int nivelArbol() {
        if (this.raíz != null)
            return this.raíz.nivelArbol();
        return 0;
    }
    
    int gradoArbol() {
        if (this.raíz != null)
            return this.raíz.gradoNodo();
        return 0; 
    }
    
    int cantHijos(Comparable dato){
        NodoBin buscado = this.buscar(dato);
        if(buscado == null)
            return -1;
        int cont = 0;
        if(buscado.izq !=null){
            cont = 1;
            buscado = buscado.izq;
            while(buscado.der != null){
                buscado = buscado.der;
                cont++;
            }
        }
        return cont;
    }
    
    private NodoBin buscar(Comparable dato){
        if(this.raíz == null)
            return null;
        return this.raíz.buscar(dato);   
    }
    
    NodoBin padreDe(NodoBin buscar) {
    if (this.raíz == null || buscar == null) {
        return null;
    }

    return null;
}
}
