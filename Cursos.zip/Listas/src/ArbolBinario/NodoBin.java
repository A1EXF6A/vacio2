/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolBinario;

/**
 *
 * @author HOME
 */
public class NodoBin {
    public Comparable dato;
    public NodoBin izq, der, padre;

    public NodoBin(Comparable dato) {
        this.dato = dato;
        this.izq = this.der = null;
    }

    public NodoBin(Comparable dato, NodoBin izq, NodoBin der) {
        this.dato = dato;
        this.izq = izq;
        this.der = der;
    }

    void imprimirSimetrico() {
        if (this.izq != null)
            this.izq.imprimirSimetrico();
        System.out.println(this.dato);
        if (this.der != null)
            this.der.imprimirSimetrico();
    }

    public boolean insertarLexicografico(Comparable dato) {
        if (this.dato.equals(dato))
            return false;
        if (this.dato.compareTo(dato) < 0) {
            if (this.der == null) {
                this.der = new NodoBin(dato);
                return true;
            }
            return this.der.insertarLexicografico(dato);
        }
        if (this.izq == null) {
            this.izq = new NodoBin(dato);
            return true;
        }
        return this.izq.insertarLexicografico(dato);
    }
    
    void imprimirPreorden() {
        System.out.println(dato);
        if (izq != null)
            this.izq.imprimirPreorden();
        
        if (der != null)
            this.der.imprimirPreorden();
    }
    
    void imprimirPosorden() {
        if (izq != null)
            this.izq.imprimirPosorden();
        
        if (der != null)
            this.der.imprimirPosorden();
        
        System.out.println(dato);
    }
    
    int nivelArbol() {
    int nivelIzquierdo = (this.izq != null) ? this.izq.nivelArbol() : 0;
    int nivelDerecho = (this.der != null) ? this.der.nivelArbol() : 0;
    return 1 + Math.max(nivelIzquierdo, nivelDerecho);
}


  
    int gradoNodo() {
        int gradoActual = 0;
        if (this.izq != null) gradoActual++;
        if (this.der != null) gradoActual++;
        
        
        int gradoIzquierdo = (this.izq != null) ? this.izq.gradoNodo() : 0;
        int gradoDerecho = (this.der != null) ? this.der.gradoNodo() : 0;
        return Math.max(gradoActual, Math.max(gradoIzquierdo, gradoDerecho));  
    }
    
    NodoBin buscar(Comparable dato){
        if(this.dato.equals(dato))
            return this;
        NodoBin buscado = null;
        if(this.izq != null)
            buscado = this.izq.buscar(dato);
        if(buscado == null && this.der !=null)
            return this.der.buscar(dato);
        
        return buscado;
    }
    
    NodoBin padreDe(NodoBin buscar, NodoBin padre) {
        if (this == buscar) {
            return padre;
        }

        NodoBin resultado = null;
         if (izq != null) {
         resultado = izq.padreDe(buscar, this);
         }
         if (resultado == null && der != null) {
          resultado = der.padreDe(buscar, this);
         }
          return resultado;
}
}
