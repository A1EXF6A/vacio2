/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolBinario;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
    Arbol arbol = new Arbol();
    arbol.insertarLexicografico(10);
    arbol.insertarLexicografico(5);
    arbol.insertarLexicografico(15);
    arbol.insertarLexicografico(12);

    System.out.println("Grado del árbol: " + arbol.gradoArbol()); 
    System.out.println("Nivel del árbol: " + arbol.nivelArbol()); 
    System.out.println("//////////////////");
    arbol.imprimirPosorden();
    System.out.println("//////////////////");
    arbol.imprimirPreorden();
    System.out.println("//////////////////");
    arbol.imprimirSimetrico();
}

}
