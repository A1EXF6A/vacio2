/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListaGenerica;

/**
 *
 * @author Estudiante
 */
public class Nodo<T>{
    T dato;
    Nodo siguiente;
    
    public Nodo(T dato, Nodo siguiente){
        this.dato = dato;
        this.siguiente = siguiente;
    }
    
    public Nodo(T dato){
        this.dato = dato;
        this.siguiente = null;
    }
}
