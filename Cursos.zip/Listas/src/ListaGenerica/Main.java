/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListaGenerica;

/**
 *
 * @author HOME
 */
public class Main {
    public static void main(String[] args) {
        Lista<Persona> a = new Lista();
        Persona b = new Persona("", "hola0", "");
        Persona c = new Persona("", "hola1", "");
        Persona d = new Persona("", "hola2", "");
        Persona e = new Persona("", "hola3", "");
        Persona f = new Persona("", "hola4", "");
        Persona g = new Persona("", "hola5", "");
        Persona h = new Persona("", "hola6", "");
        Persona i = new Persona("", "hola7", "");
        System.out.println(a.insertar(b));
        System.out.println(a.insertar(c));
        System.out.println(a.insertar(d));
        System.out.println(a.insertar(e));
        System.out.println(a.insertar(f));
        System.out.println(a.insertar(g));
        System.out.println(a.insertar(h));
        System.out.println(a.insertar(i));
        /*System.out.println("ffff");
        System.out.println(a.eliminarDato(d));
        System.out.println("llll");*/
        //a.imprimir();
        
        a.imprimirParesImpares(true);
    }
}
