/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

/**
 *
 * @author HOME
 */
public class NodoHilvanado {
    int dato;
    NodoHilvanado izq, der;
    boolean realizq, realder;
    
    public NodoHilvanado(int a){
        this.dato = a;
        this.izq = this.der = null;
        this.realizq = this.realder = true;
    }
    
    public NodoHilvanado(int a,NodoHilvanado b,NodoHilvanado c, boolean d,boolean e){
        this.dato = a;
        this.izq = b;this.der = c;
        this.realizq = d; this.realder = e;
    }
}
