/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

/**
 *
 * @author HOME
 */
public class ArbolHilvanado {
    NodoHilvanado raiz;
    
    boolean insertar(int dato){
        if(raiz==null){
            this.raiz = new NodoHilvanado(dato);
            return true;
        }
        NodoHilvanado futuroPadre = this.futuroPadre(dato);
        if(futuroPadre.dato < dato){
            futuroPadre.der = new NodoHilvanado(dato, futuroPadre, futuroPadre.der, false, futuroPadre.realder);
            futuroPadre.realder = true;
            return true;
        }
        futuroPadre.izq = new NodoHilvanado(dato, futuroPadre.izq, futuroPadre, futuroPadre.realizq, false);
        futuroPadre.realizq = true;    
        return true;
    }
    
    
    NodoHilvanado futuroPadre(int dato){
        if (this.raiz == null)
            return null;
        NodoHilvanado futuroPadre = this.raiz;
        while (true){
            if (futuroPadre.dato == dato)
                return null;
            if (futuroPadre.dato < dato){
                if (futuroPadre.der == null || !futuroPadre.realder)
                    return futuroPadre;
                futuroPadre = futuroPadre.der;
            }else{
                if (futuroPadre.izq == null || !futuroPadre.realizq)
                        return futuroPadre;
                futuroPadre = futuroPadre.izq;
            }
        }
           
    }
    
    void simetrico(){
        if(raiz == null){
            return;
        }
        NodoHilvanado actual = raiz;
        while(actual.izq != null){
            actual = actual.izq;
            while(actual!=null){
                System.out.println(actual.dato);
                if(actual.der == null || !actual.realder)
                    actual = actual.der;
                else{
                    NodoHilvanado siguiente = actual.der;
                    while(siguiente.izq != actual)
                        siguiente = siguiente.izq;
                    actual = siguiente;
                }
            }
            
                
        }
    }
    
    void simetricoInverso() {
    if (raiz == null) {
        return;
    }
    NodoHilvanado actual = raiz;
    while (actual.der != null && actual.realder) {
        actual = actual.der;
    }
    while (actual != null) {
        System.out.println(actual.dato);

        if (actual.izq == null || !actual.realizq) {
            actual = actual.izq; 
        } else {
            NodoHilvanado predecesor = actual.izq;
            while (predecesor.der != null && predecesor.der != actual) {
                predecesor = predecesor.der;
            }
            actual = predecesor;
        }
    }
}

    
    
}
