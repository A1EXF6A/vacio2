/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
        ArbolHilvanado a = new ArbolHilvanado();
        a.insertar(5);
        a.insertar(3);
        a.insertar(1);
        a.insertar(4);
        a.insertar(2);
        a.insertar(8);
        a.insertar(10);
        a.simetrico();
    }
}
