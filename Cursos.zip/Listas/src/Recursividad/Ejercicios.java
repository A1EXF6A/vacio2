/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Recursividad;

/**
 *
 * @author HOME
 */
public class Ejercicios {
    public static void main(String[] args) {
        int[] n = {5,4,3,2,1};
        int[] arreglo = {1, 3, 5, 7, 9};
        int valor = 4;
        /*
        
        
        System.out.println("Ejercicio 1: "+fibonacci(10));
        System.out.println("Ejercicio 4: "+suma(5));
        ordenar(n, 0);
        System.out.println("Ejercicio 3: ");
        System.out.println("Ejercicio 5: "+sumaPares(10));
        System.out.println("Ejercicio 6: "+mcd(10,5));
        System.out.println("Ejercicio 7: "+binario(10));
        System.out.println("Ejercicio 8: "+Decimal("1010"));
        */
        System.out.println(cm(arreglo, valor, 0));
    }
    
    
    public static int fibonacci(int n) {
    if (n == 0 || n == 1)
        return 1;
    if(n<0)
          return -1;
    return fibonacci(n - 1) + fibonacci(n - 2);
}
    
    
    static int suma(int n){
      if(n<0)
          return -1;
      if(n==0||n==1)
          return n;
      return n+suma(n-1);
  }
  static void ordenar(int[] arr, int start) {
    if (start >= arr.length - 1) return;

    int minIndex = start;
    for (int i = start + 1; i < arr.length; i++) {
        if (arr[i] < arr[minIndex]) {
            minIndex = i;
        }
    }
  
    int temp = arr[start];
    arr[start] = arr[minIndex];
    arr[minIndex] = temp;

    ordenar(arr, start + 1);
}
    
    static int sumaPares(int n){
      if(n%2!=0 || n<0){
          System.out.println("Eror");
          return -1;
      }
      if(n==2)
          return n;
      return n+sumaPares(n-2);
  }
   
  static int mcd(int m, int n) {
    if (n == 0) return m;
    return mcd(n, m % n);
}

 static String binario(int n) {
    if (n == 0) return "0";
    if (n == 1) return "1";
    return binario(n / 2) + (n % 2);
}

public static int Decimal(String binario) {
    return binarioDecimal(binario, binario.length() - 1, 0);
}

private static int binarioDecimal(String binario, int num, int poscion) {
    if (num < 0) return 0;
    int digit = binario.charAt(num) - '0';
    return digit * (int) Math.pow(2, poscion) + binarioDecimal(binario, num - 1, poscion + 1);
}

public static int sumaArray(int[] arr, int inicio) {
    if (inicio == arr.length-1) return arr[inicio];
    return arr[inicio] + sumaArray(arr, inicio + 1);
}

public static void revertirArray(int[] arr, int start, int end) {
    if (start >= end) return;
    int temp = arr[start];
    arr[start] = arr[end];
    arr[end] = temp;
    revertirArray(arr, start + 1, end - 1);
}


static int f(int x) {
    if (x > 100) {
        return x - 10;
    } else {
        return f(f(x + 11));
    }
}




public static void descomponer(int n, int max, String result) {
    if (n == 0) {
        System.out.println(result.trim());
        return;
    }
    for (int i = Math.min(max, n); i >= 1; i--) {
        descomponer(n - i, i, result + " " + i);
    }
}

  public static boolean esPalindromo(String cadena) {
        cadena = cadena.toLowerCase().replaceAll("\\s+", "");
        return esPalindromoRecursivo(cadena, 0, cadena.length() - 1);
    }
    
    private static boolean esPalindromoRecursivo(String cadena, int inicio, int fin) {
        if (inicio >= fin) {
            return true;
        } else {
            
            if (cadena.charAt(inicio) != cadena.charAt(fin)) {
                return false; 
            } else {
                return esPalindromoRecursivo(cadena, inicio + 1, fin - 1);
            }
        }
    }


    static int cm(int a[],int v,int c){
        int cont = 0;
        if(c==a.length)
            return 0;
        if(a[c]>v)
            cont++;
        return cm(a, v, c+1) +cont;
    }
    
    
    
}
