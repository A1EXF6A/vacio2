/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListaCircularDoble;

import ListaDoble.*;
import ListaGenerica.*;

/**
 *
 * @author Estudiante
 */
public class Nodo<T>{
    T dato;
    Nodo siguiente;
    Nodo anterior;
    
    public Nodo(T dato, Nodo siguiente){
        this.dato = dato;
        this.siguiente = siguiente;
        this.anterior = null;
    }
    
    public Nodo(T dato){
        this.dato = dato;
        this.siguiente = null;
    }

    public Nodo(T dato, Nodo siguiente, Nodo anterior) {
        this.dato = dato;
        this.siguiente = siguiente;
        this.anterior = anterior;
    }
    
}
