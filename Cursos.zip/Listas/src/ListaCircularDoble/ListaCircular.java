package ListaCircularDoble;

public class ListaCircular<P> {

    Nodo<P> primero;
    int cant;

    public ListaCircular() {
        this.primero = null;
        this.cant = 0;
    }

    public boolean estáVacía() {
        return this.primero == null;
    }

    public boolean insertar(P dato) {
        Nodo<P> nuevo;
        try {
            nuevo = new Nodo<>(dato);
        } catch (Exception e) {
            return false;
        }
        if (this.estáVacía()) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero;
            this.primero.anterior = this.primero;
        } else {
            Nodo<P> ultimo = this.primero.anterior; 
            ultimo.siguiente = nuevo;
            nuevo.anterior = ultimo;
            nuevo.siguiente = this.primero;
            this.primero.anterior = nuevo;
        }
        this.cant++;
        return true;
    }

    public boolean insertarPorPrimero(P dato) {
        Nodo<P> nuevo;
        try {
            nuevo = new Nodo<>(dato);
        } catch (Exception e) {
            return false;
        }
        if (this.estáVacía()) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero;
            this.primero.anterior = this.primero;
        } else {
            Nodo<P> ultimo = this.primero.anterior;
            nuevo.siguiente = this.primero;
            nuevo.anterior = ultimo;
            ultimo.siguiente = nuevo;
            this.primero.anterior = nuevo;
            this.primero = nuevo;
        }
        this.cant++;
        return true;
    }

    public boolean insertar(P dato, int pos) {
        if (pos < 0 || pos > this.cant) {
            return false;
        }
        if (pos == 0) {
            return insertarPorPrimero(dato);
        }
        if (pos == this.cant) {
            return insertar(dato);
        }
        Nodo<P> anterior = this.getNodo(pos - 1);
        Nodo<P> nuevo;
        try {
            nuevo = new Nodo<>(dato, anterior.siguiente, anterior);
            anterior.siguiente.anterior = nuevo;
            anterior.siguiente = nuevo;
            this.cant++;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean borrarPorPosicion(int pos) {
        if (this.estáVacía() || pos < 0 || pos >= this.cant) {
            return false;
        }
        if (pos == 0) {
            if (this.cant == 1) {
                this.primero = null;
            } else {
                Nodo<P> ultimo = this.primero.anterior;
                this.primero = this.primero.siguiente; 
                this.primero.anterior = ultimo;
                ultimo.siguiente = this.primero;
            }
        } else {
            Nodo<P> actual = this.getNodo(pos);
            actual.anterior.siguiente = actual.siguiente;
            actual.siguiente.anterior = actual.anterior;
        }

        this.cant--;
        return true;
    }

    public Nodo<P> getNodo(int pos) {
        if (pos < 0 || pos >= this.cant) {
            return null;
        }
        Nodo<P> actual = this.primero;
        for (int i = 0; i < pos; i++) {
            actual = actual.siguiente;
        }
        return actual;
    }
    
    //NO TIENE APLICACIÓN DADO QUE EN EL INSERTAR NO VERIFICAMOS QUE NO SE INSERTEN VALORES REPETIDOS
    public boolean borrarPorDatoSinDuplicados(P dato) {
        if (this.estáVacía() || dato == null) {
            return false;
        }
        Nodo<P> actual = this.primero;
        if (actual.dato.equals(dato)) {
            if (this.cant == 1) { 
                this.primero = null;
            } else { 
                Nodo<P> ultimo = this.primero.anterior;
                this.primero = this.primero.siguiente; 
                this.primero.anterior = ultimo; 
                ultimo.siguiente = this.primero;
            }
            this.cant--;
            return true;
        }
        actual = this.primero.siguiente;
        while (actual != this.primero) {
            if (actual.dato.equals(dato)) {
                actual.anterior.siguiente = actual.siguiente; 
                actual.siguiente.anterior = actual.anterior;
                this.cant--;
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    public boolean borrarPorDato(P dato) {
        Nodo<P> actual = this.primero;
        for (int i = 0; i < this.cant; i++) {
            if (actual.dato.equals(dato)) {
                if (i == 0) {
                    this.primero = this.primero.siguiente;
                    Nodo<P> ultimo = this.primero.anterior;
                    this.primero.anterior = ultimo;
                    ultimo.siguiente = this.primero;
                } else {
                    actual.anterior.siguiente = actual.siguiente;
                    actual.siguiente.anterior = actual.anterior;
                }
                this.cant--;
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    public P buscar(P dato) {
        Nodo<P> actual = this.primero;
        for (int i = 0; i < this.cant; i++) {
            if (actual.dato.equals(dato)) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void imprimir() {
        if (this.estáVacía()) {
            return;
        }
        Nodo<P> actual = this.primero;
        for (int i = 0; i < this.cant; i++) {
            System.out.println(actual.dato);
            actual = actual.siguiente;
        }
    }

    public int getCantidad() {
        return this.cant;
    }
}
