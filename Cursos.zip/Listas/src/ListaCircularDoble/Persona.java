/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListaCircularDoble;

import ListaDoble.*;
import ListaGenerica.*;
import listas.*;

/**
 *
 * @author HOME
 */
public class Persona {
    String ci, nom, dir;
    

    public Persona(String ci, String nom, String dir) {
        this.ci = ci;
        this.nom = nom;
        this.dir = dir;
    }
    
    @Override
    public String toString(){
        return "Nombre"+nom;
    }
}
