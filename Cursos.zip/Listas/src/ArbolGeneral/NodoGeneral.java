/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolGeneral;

import ArbolBinario.NodoBin;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author HOME
 */
public class NodoGeneral {

    int dato;
    LinkedList<NodoGeneral> hijos;

    public NodoGeneral(int dato) {
        this.dato = dato;
        this.hijos = new LinkedList<>();
    }

    public boolean insertar(int dato, NodoGeneral futuroPadre) {
        try {
            futuroPadre.hijos.add(new NodoGeneral(dato));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public NodoGeneral buscar(int dato) {
        if (this.dato == dato) {
            return this;
        }
        for (NodoGeneral a : hijos) {
            NodoGeneral en = a.buscar(dato);
            if (en != null) {
                return a;
            }
        }
        return null;
    }

    public NodoGeneral buscarSin(int dato) {
        LinkedList<NodoGeneral> cola = new LinkedList<>();
        cola.add(this);
        while (!cola.isEmpty()) {
            NodoGeneral nodo = cola.poll();
            if (nodo.dato == dato) {
                return nodo;
            } else {
                cola.addAll(nodo.hijos);
            }
        }
        return null;
    }
    
    void alimentar(NodoBin a){
        if(this.hijos.size()>0){
            a.izq = new NodoBin(this.hijos.get(0).dato);
            this.hijos.get(0).alimentar(a.izq);
            NodoBin aux = a.izq;
            for (int i = 1; i < this.hijos.size(); i++) {
                aux.der = new NodoBin(this.hijos.get(i).dato);
                this.hijos.get(i).alimentar(aux.der);
                aux = aux.der;
            }
        }
    }
    
    void alimentar2(NodoBin a) {
    if (this.hijos.isEmpty()) {
        return;
    }
    Queue<NodoBin> colaBin = new LinkedList<>();
    Queue<NodoGeneral> colaGen = new LinkedList<>();

    NodoGeneral primerHijo = this.hijos.get(0);
    a.izq = new NodoBin(primerHijo.dato);
    colaBin.add(a.izq);
    colaGen.add(primerHijo);

    while (!colaBin.isEmpty()) {
        NodoBin actualBin = colaBin.poll();
        NodoGeneral actualGen = colaGen.poll();

        if (!actualGen.hijos.isEmpty()) {
            NodoGeneral hijoIzqGen = actualGen.hijos.get(0);
            actualBin.izq = new NodoBin(hijoIzqGen.dato);
            colaBin.add(actualBin.izq);
            colaGen.add(hijoIzqGen);
            NodoBin auxBin = actualBin.izq;
            for (int i = 1; i < actualGen.hijos.size(); i++) {
                NodoGeneral hermanoGen = actualGen.hijos.get(i);
                auxBin.der = new NodoBin(hermanoGen.dato);
                colaBin.add(auxBin.der);
                colaGen.add(hermanoGen);
                auxBin = auxBin.der;
            }
        }
    }
}


}
