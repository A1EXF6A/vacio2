/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolGeneral;

import ArbolBinario.Arbol;
import ArbolBinario.NodoBin;

/**
 *
 * @author HOME
 */
public class ArbolGeneral {
    NodoGeneral raiz;
    
    public Arbol equivalente(){
        Arbol a = new Arbol();
        if(raiz != null) {
            a.raíz = new NodoBin(this.raiz.dato);
            raiz.alimentar(a.raíz);
        }
        return a;
    }
    
    public Arbol equivalente2(){
        Arbol a = new Arbol();
        if(raiz != null) {
            a.raíz = new NodoBin(this.raiz.dato);
            raiz.alimentar2(a.raíz);
        }
        return a;
    }

}
