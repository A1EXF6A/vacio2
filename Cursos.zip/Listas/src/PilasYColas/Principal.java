package PilasYColas;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.UUID;

public class Principal {
	
	public static void main(String[] args){
        Stack<Integer> stack = new Stack<>();
        stack.push(5);
        stack.push(8);
        stack.push(4);
        stack.push(9);
        stack.push(2);
        while(!stack.isEmpty()) {
          
            System.out.println(stack.pop());
        }
    Queue<Integer> queue = new LinkedList<>();
        queue.add(5);
        queue.add(8);
        queue.add(4);
        queue.add(9);
        queue.add(2);
        System.out.println("Queue: " + queue);
        int front = queue.remove();
        System.out.println("Removed element: " + front);

	}
        
        
         
	
	
	
}