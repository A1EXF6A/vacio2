/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafo;

import java.util.LinkedList;

/**
 *
 * @author HOME
 */
public class Grafo {

    Comparable[] vertices;
    LinkedList<Comparable>[][] arcos;

    public Grafo(int dim) {
        this.vertices = new Comparable[dim];
        this.arcos = new LinkedList[dim][dim];
        
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                arcos[i][j] = new LinkedList<>();
            }
        }
    }

    public boolean insertarVertice(Comparable pond) {
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i] != null && vertices[i].equals(pond)) {
                return false;
            }
            if (vertices[i] == null) {
                vertices[i] = pond;
                return true;
            }
        }
        return false;
    }

    public boolean insertarArco(Comparable pondVerticeO, Comparable pondVerticeD, Comparable pondArco) {
        if (pondArco == null) {
            return false;
        }
        int posOrigen = posicion(pondVerticeO);
        int posDestino = posicion(pondVerticeD);

        if (posOrigen == -1 || posDestino == -1 || this.arcos[posOrigen][posDestino].contains(pondArco)) {
            return false;
        }
        return this.arcos[posOrigen][posDestino].add(pondArco);
    }

    public int posicion(Comparable pondVertice) {
        if (pondVertice == null) {
            return -1;
        }
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i] != null && vertices[i].equals(pondVertice)) {
                return i;
            }
        }
        return -1;
    }

    public boolean eliminarArco(Comparable pondVerticeO, Comparable pondVerticeD, Comparable pond) {
        int posOrigen = posicion(pondVerticeO);
        int posDestino = posicion(pondVerticeD);

        if (posOrigen == -1 || posDestino == -1 || pond == null) {
            return false;
        }
        
        return this.arcos[posOrigen][posDestino].remove(pond);
    }

    public boolean eliminarVertice(Comparable pond) {
        int pos = posicion(pond);
        if (pos == -1) {
            return false;
        }

        vertices[pos] = null;
        for (int i = 0; i < arcos.length; i++) {
            arcos[pos][i].clear();
            arcos[i][pos].clear();
        }
        return true;
    }

    public boolean estaVacio() {
        if (arcos == null && vertices == null) {
            return true;
        }
        return false;
    }

    

    public int contarSale(Comparable vertice) {
        int pos = posicion(vertice);
        if (pos == -1) {
            return -1;
        }

        int cont = 0;
        for (int i = 0; i < vertices.length; i++) {
            if (arcos[pos][i] != null) {
                cont += arcos[pos][i].size();
            }
        }
        return cont;
    }

    public int contarEntra(Comparable vertice) {
        int pos = posicion(vertice);
        if (pos == -1) {
            return -1; 
        }
        int cont = 0;
        for (int i = 0; i < vertices.length; i++) {
            if (arcos[i][pos] != null) {
                cont += arcos[i][pos].size();
            }
        }
        return cont;
    }

    public int contarArcosTotales(Comparable vertice) {
        int arcosSalientes = contarSale(vertice);
        int arcosEntrantes = contarEntra(vertice);

        if (arcosSalientes == -1 || arcosEntrantes == -1) {
            return -1; 
        }

        return arcosSalientes + arcosEntrantes;
    }

}
