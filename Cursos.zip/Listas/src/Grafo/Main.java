/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafo;

/**
 *
 * @author HOME
 */
public class Main {
    public static void main(String[] args) {
        Grafo a = new Grafo(6);
        System.out.println(a.insertarVertice('A'));
        System.out.println(a.insertarVertice('b'));
        System.out.println(a.insertarVertice('c'));
        System.out.println(a.insertarVertice('d'));
        System.out.println(a.insertarVertice('e'));
        System.out.println(a.insertarVertice('f'));
        System.out.println("///////////////");
        System.out.println(a.insertarArco('A', 'b', 1));
        System.out.println(a.insertarArco('A', 'c', 5));
        System.out.println(a.insertarArco('c', 'd', 2));
        System.out.println(a.insertarArco('d', 'e', 8));
        System.out.println(a.insertarArco('d', 'f', 9));
        System.out.println(a.insertarArco('e', 'b', 13));
        System.out.println(a.insertarArco('f', 'b', 6));
    }
}
