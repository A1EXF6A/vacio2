/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Letras;

/**
 *
 * @author HOME
 */
import java.util.Random;

/**
 *
 * @author ASUS VIVOBOOK
 */
public class MatrizDeLetras {
    private char[][] matriz;
    private Random aleatorio = new Random();

    public MatrizDeLetras(int tamanio) {
        matriz = new char[tamanio][tamanio];
        llenarConLetrasAleatorias();
    }

    private void llenarConLetrasAleatorias() {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = (char) ('A' + aleatorio.nextInt(26));
            }
        }
    }


     public void mostrarMatriz() {
    // Imprimir encabezados de columnas
    System.out.print("    "); // Espacio para el encabezado de filas
    for (int col = 1; col <= matriz[0].length; col++) {
        System.out.printf("%3d", col); // Ancho fijo para cada nÃºmero de columna
    }
    System.out.println();

    // Imprimir la matriz con encabezados de filas
    for (int fila = 0; fila < matriz.length; fila++) {
        System.out.printf("%3d ", fila + 1); // Encabezado de fila con ancho fijo
        for (int col = 0; col < matriz[fila].length; col++) {
            System.out.printf("%2c ", matriz[fila][col]); // Celda con ancho fijo
        }
        System.out.println();
    }
}

 
    

    public boolean validarPosicionPalabra(String palabra, String intento) {
    String[] posiciones = intento.split(" ");
    if (posiciones.length != 2) {
        System.out.println("Formato de entrada invÃ¡lido. Use 'fila_inicio,columna_inicio fila_fin,columna_fin'.");
        return false;
    }

    try {
        String[] inicio = posiciones[0].split(",");
        String[] fin = posiciones[1].split(",");
        int filaInicio = Integer.parseInt(inicio[0]) - 1;
        int columnaInicio = Integer.parseInt(inicio[1]) - 1;
        int filaFin = Integer.parseInt(fin[0]) - 1;
        int columnaFin = Integer.parseInt(fin[1]) - 1;

        int longitud = palabra.length();

        // Validar horizontal (izquierda a derecha)
        if (filaInicio == filaFin && columnaFin - columnaInicio + 1 == longitud) {
            for (int i = 0; i < longitud; i++) {
                if (matriz[filaInicio][columnaInicio + i] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

        // Validar vertical (arriba hacia abajo)
        if (columnaInicio == columnaFin && filaFin - filaInicio + 1 == longitud) {
            for (int i = 0; i < longitud; i++) {
                if (matriz[filaInicio + i][columnaInicio] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

        // Validar diagonal (izquierda a derecha)
        if (filaFin - filaInicio == columnaFin - columnaInicio && filaFin - filaInicio + 1 == longitud) {
            for (int i = 0; i < longitud; i++) {
                if (matriz[filaInicio + i][columnaInicio + i] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

    } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
        System.out.println("Coordenadas invÃ¡lidas. AsegÃºrese de que estÃ¡n dentro del rango de la matriz.");
    }

    return false;
}

    
    public void colocarPalabra(String palabra) {
    int longitud = palabra.length();
    int direccion; 
    int fila, columna;

    boolean colocada = false;
    while (!colocada) {
        direccion = aleatorio.nextInt(3);
        fila = aleatorio.nextInt(matriz.length);
        columna = aleatorio.nextInt(matriz[0].length);

        switch (direccion) {
            case 0: 
                if (columna + longitud <= matriz[0].length) {
                    for (int i = 0; i < longitud; i++) {
                        matriz[fila][columna + i] = palabra.charAt(i);
                    }
                    colocada = true;
                }
                break;

            case 1:
                if (fila + longitud <= matriz.length) {
                    for (int i = 0; i < longitud; i++) {
                        matriz[fila + i][columna] = palabra.charAt(i);
                    }
                    colocada = true;
                }
                break;

            case 2: 
                if (fila + longitud <= matriz.length && columna + longitud <= matriz[0].length) {
                    for (int i = 0; i < longitud; i++) {
                        matriz[fila + i][columna + i] = palabra.charAt(i);
                    }
                    colocada = true;
                }
                break;
        }
    }
}
    
}