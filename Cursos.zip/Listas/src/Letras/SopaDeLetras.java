/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Letras;

/**
 *
 * @author HOME
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.*;
import java.util.*;
/**
 *
 * @author ASUS VIVOBOOK
 */
class SopaDeLetras {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Random aleatorio = new Random();
    private static final List<String> palabras = new ArrayList<>();
    private static final List<Jugador> jugadores = new ArrayList<>();
    private static final String RUTA_ARCHIVO = "Palabras.txt";
    private static ConfiguracionJuego configuracion = new ConfiguracionJuego();

    public void menu() {
        cargarPalabrasDesdeArchivo(RUTA_ARCHIVO);
        int opcion;
        do {
            System.out.println("\n--- Sopa de Letras ---");
            System.out.println("1. Registrar Jugadores");
            System.out.println("2. Configuracion del Juego");
            System.out.println("3. Iniciar Juego");
            System.out.println("4. Gestionar Palabras");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opcion: ");
            opcion = leerEnteroSeguro();
            switch (opcion) {
                case 1 -> registrarJugadores();
                case 2 -> configuracion.configurarJuego(scanner);
                case 3 -> iniciarJuego();
                case 4 -> gestionarPalabras();
                case 5 -> System.out.println("Saliendo del juego. Adios!");
                default -> System.out.println("Opcion invalida. Intente nuevamente.");
            }
        } while (opcion != 5);
    }

    private void cargarPalabrasDesdeArchivo(String rutaArchivo) {
        palabras.clear(); // Limpiar lista antes de cargar
        File archivo = new File(rutaArchivo);
        if (!archivo.exists()) {
            System.out.println("El archivo no existe. Creando uno nuevo...");
            try {
                archivo.createNewFile();
            } catch (IOException e) {
                System.out.println("Error al crear el archivo: " + e.getMessage());
            }
        }
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] arregloPalabras = linea.split(",");
                for (String palabra : arregloPalabras) {
                    palabras.add(palabra.trim().toUpperCase());
                }
            }
            System.out.println("Palabras cargadas correctamente desde " + rutaArchivo);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    private void gestionarPalabras() {
        int opcion;
        do {
            System.out.println("\n--- Gestion de Palabras ---");
            System.out.println("1. Ver Palabras");
            System.out.println("2. Agregar Palabra");
            System.out.println("3. Editar Palabra");
            System.out.println("4. Eliminar Palabra");
            System.out.println("5. Volver al Menu Principal");
            System.out.print("Ingrese una opcion: ");
            opcion = leerEnteroSeguro();
            switch (opcion) {
                case 1 -> verPalabras();
                case 2 -> agregarPalabra();
                case 3 -> editarPalabra();
                case 4 -> eliminarPalabra();
                case 5 -> System.out.println("Volviendo al menu principal...");
                default -> System.out.println("Opcion invalida. Intente nuevamente.");
            }
        } while (opcion != 5);
    }

    private void verPalabras() {
        if (palabras.isEmpty()) {
            System.out.println("No hay palabras registradas.");
        } else {
            System.out.println("Palabras actuales:");
            for (int i = 0; i < palabras.size(); i++) {
                System.out.println((i + 1) + ". " + palabras.get(i));
            }
        }
    }

    private void agregarPalabra() {
        System.out.print("Ingrese la nueva palabra: ");
        String nuevaPalabra = scanner.nextLine().trim().toUpperCase();
        if (nuevaPalabra.isEmpty() || palabras.contains(nuevaPalabra)) {
            System.out.println("La palabra es invalida o ya existe.");
            return;
        }
        palabras.add(nuevaPalabra);
        guardarPalabrasEnArchivo();
        System.out.println("Palabra agregada correctamente.");
    }

    private void editarPalabra() {
        verPalabras();
        if (palabras.isEmpty()) return;

        System.out.print("Ingrese el numero de la palabra que desea editar: ");
        int indice = leerEnteroSeguro() - 1;
        if (indice < 0 || indice >= palabras.size()) {
            System.out.println("Numero invalido.");
            return;
        }
        System.out.print("Ingrese la nueva palabra: ");
        String nuevaPalabra = scanner.nextLine().trim().toUpperCase();
        if (nuevaPalabra.isEmpty() || palabras.contains(nuevaPalabra)) {
            System.out.println("La palabra es invalida o ya existe.");
            return;
        }
        palabras.set(indice, nuevaPalabra);
        guardarPalabrasEnArchivo();
        System.out.println("Palabra editada correctamente.");
    }

    private void eliminarPalabra() {
        verPalabras();
        if (palabras.isEmpty()) return;

        System.out.print("Ingrese el numero de la palabra que desea eliminar: ");
        int indice = leerEnteroSeguro() - 1;
        if (indice < 0 || indice >= palabras.size()) {
            System.out.println("Numero invalido.");
            return;
        }
        String eliminada = palabras.remove(indice);
        guardarPalabrasEnArchivo();
        System.out.println("Palabra '" + eliminada + "' eliminada correctamente.");
    }

    private void guardarPalabrasEnArchivo() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_ARCHIVO))) {
            bw.write(String.join(",", palabras));
            System.out.println("Cambios guardados en el archivo.");
        } catch (IOException e) {
            System.out.println("Error al guardar el archivo: " + e.getMessage());
        }
    }

    private int leerEnteroSeguro() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Entrada invalida. Por favor, ingrese un numero: ");
            }
        }
    }


    private void registrarJugadores() {
    int opcion = 0;
    do {
        try {
            System.out.println("\n--- Gestion de Jugadores ---");
            System.out.println("1. Registrar jugadores");
            System.out.println("2. Eliminar jugadores");
            System.out.println("3. Ver jugadores registrados");
            System.out.println("4. Salir");
            System.out.print("Ingrese una opcion: ");
            opcion = Integer.parseInt(scanner.nextLine().trim()); // Leer y convertir la opciÃ³n

            switch (opcion) {
                case 1 -> {
                    System.out.println("Ingrese los nombres de los jugadores (escriba 'listo' para finalizar):");
                    String nombre;
                    while (!(nombre = scanner.nextLine().trim()).equalsIgnoreCase("LISTO")) {
                        if (nombre.isEmpty()) {
                            System.out.println("El nombre no puede estar vacio. Intente nuevamente.");
                        } else if (nombre.length() < 2) {
                            System.out.println("El nombre debe tener al menos 2 letras. Intente nuevamente.");
                        } else {
                            // Validar si el jugador ya estÃ¡ registrado
                            boolean existe = false;
                            for (Jugador j : jugadores) {
                                if (j.obtenerNombre().equalsIgnoreCase(nombre)) {
                                    existe = true;
                                    break; // Detener la bÃºsqueda si se encuentra
                                }
                            }

                            if (existe) {
                                System.out.println("El jugador '" + nombre + "' ya esta registrado.");
                            } else {
                                jugadores.add(new Jugador(nombre));
                                System.out.println("Jugador '" + nombre + "' registrado correctamente.");
                            }
                        }
                    }
                }
                case 2 -> {
                    if (jugadores.isEmpty()) {
                        System.out.println("No hay jugadores registrados para eliminar.");
                    } else {
                        System.out.println("Jugadores registrados:");
                        for (int i = 0; i < jugadores.size(); i++) {
                            System.out.println((i + 1) + ". " + jugadores.get(i).obtenerNombre());
                        }
                        System.out.print("Ingrese el numero del jugador a eliminar: ");
                        try {
                            int indice = Integer.parseInt(scanner.nextLine().trim());
                            if (indice > 0 && indice <= jugadores.size()) {
                                Jugador eliminado = jugadores.remove(indice - 1);
                                System.out.println("Jugador '" + eliminado.obtenerNombre() + "' eliminado correctamente.");
                            } else {
                                System.out.println("Numero invalido. Intente nuevamente.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Debe ingresar un numero valido.");
                        }
                    }
                }
                case 3 -> {
                    if (jugadores.isEmpty()) {
                        System.out.println("No hay jugadores registrados.");
                    } else {
                        System.out.println("Jugadores registrados:");
                        for (Jugador jugador : jugadores) {
                            System.out.println("- " + jugador.obtenerNombre());
                        }
                    }
                }
                case 4 -> System.out.println("Saliendo de la gestion de jugadores.");
                default -> System.out.println("Opcion invalida. Intente nuevamente.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Debe ingresar un numero valido para seleccionar una opcion.");
        }
    } while (opcion != 4);
}


    private void iniciarJuego() {
    if (jugadores.isEmpty()) {
        System.out.println("No hay jugadores registrados. Por favor registre jugadores primero.");
        return;
    }
    if (palabras.isEmpty()) {
        System.out.println("No hay palabras disponibles. Por favor cargue palabras desde un archivo.");
        return;
    }

    System.out.println("\n--- Seleccione el nivel de dificultad ---");
    System.out.println("1. Fácil (1 palabra, sopa pequeña)");
    System.out.println("2. Medio (3 palabras, sopa mediana)");
    System.out.println("3. Difícil (6 palabras, sopa grande)");
    System.out.println("4. MegaPro (10 palabras, sopa gigante)");
    System.out.print("Ingrese una opción: ");

    int nivelDificultad = leerEnteroSeguro();
    int numPalabras = 0;
    int tamanioSopa = 0;

    switch (nivelDificultad) {
        case 1 -> { numPalabras = 1; tamanioSopa = 10; }
        case 2 -> { numPalabras = 3; tamanioSopa = 15; }
        case 3 -> { numPalabras = 6; tamanioSopa = 20; }
        case 4 -> { numPalabras = 10; tamanioSopa = 25; }
        default -> {
            System.out.println("Opción inválida. Seleccionando nivel fácil por defecto.");
            numPalabras = 1; tamanioSopa = 10;
        }
    }

    System.out.println("\n--- Iniciando el Juego ---");

    for (int ronda = 1; ronda <= configuracion.getRondas(); ronda++) {
        System.out.println("\n--- Ronda " + ronda + " ---");

        for (Jugador jugador : jugadores) {
            // Crear conjunto de palabras únicas para el jugador
            List<String> palabrasJugador = new ArrayList<>();
            Set<String> palabrasUsadas = new HashSet<>();
            while (palabrasJugador.size() < numPalabras && palabrasUsadas.size() < palabras.size()) {
                String palabra = palabras.get(aleatorio.nextInt(palabras.size()));
                if (!palabrasUsadas.contains(palabra)) {
                    palabrasJugador.add(palabra);
                    palabrasUsadas.add(palabra);
                }
            }

            // Crear la sopa de letras
            MatrizDeLetras matriz = new MatrizDeLetras(tamanioSopa);
            for (String palabra : palabrasJugador) {
                matriz.colocarPalabra(palabra);
            }
            matriz.mostrarMatriz();

            System.out.println("\nJugador: " + jugador.obtenerNombre());
            for (String palabra : palabrasJugador) {
                System.out.println("Encuentre la palabra: " + palabra);
                System.out.println("Adivine la posición de la palabra (fila_inicio,columna_inicio fila_fin,columna_fin):");

                final boolean[] tiempoAgotado = {false};

                Thread hiloTiempo = new Thread(() -> {
                    try {
                        Thread.sleep(configuracion.getTiempoMaximo() * 1000);
                        tiempoAgotado[0] = true;
                        System.out.println("\nTiempo agotado para " + jugador.obtenerNombre());
                    } catch (InterruptedException ignored) {
                    }
                });

                hiloTiempo.start();

                String intento = null;
                if (!tiempoAgotado[0]) {
                    try {
                        intento = scanner.nextLine().trim();
                        if (!tiempoAgotado[0]) {
                            hiloTiempo.interrupt(); // Detener el hilo si el jugador responde a tiempo
                        }
                    } catch (Exception e) {
                        System.out.println("Error al leer la entrada. Pasando al siguiente jugador.");
                    }
                }

                if (tiempoAgotado[0]) {
                    continue; // Pasar al siguiente jugador si el tiempo se agotó
                }

                if (intento == null || !matriz.validarPosicionPalabra(palabra, intento)) {
                    System.out.println("Incorrecto. No se otorgan puntos.");
                } else {
                    System.out.println("¡Correcto! Se otorgan puntos.");
                    jugador.agregarPuntos(10);
                }
            }
        }
    }

    System.out.println("\nFin del juego. Mostrando resultados...");
    mostrarResultados();
}



    private void mostrarResultados() {
        System.out.println("\n--- Resultados del Juego ---");
        jugadores.sort(Comparator.comparingInt(Jugador::obtenerPuntos).reversed());

        for (int i = 0; i < jugadores.size(); i++) {
            System.out.println((i + 1) + ". " + jugadores.get(i));
        }
        System.out.println("Ganador: " + jugadores.get(0).obtenerNombre());
    }
}