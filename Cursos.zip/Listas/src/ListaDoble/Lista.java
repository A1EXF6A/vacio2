/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListaDoble;

import ListaGenerica.*;

/**
 *
 * @author Estudiante
 */
public class Lista<P> {

    Nodo<P> primero;
    int cant;

    public Lista() {
        this.primero = null;
        this.cant = 0;
    }

    public boolean estáVacía() {
        return this.primero == null;
    }

    public boolean insertar(P dato) {
        Nodo<P> nuevo;
        try {
            nuevo = new Nodo<>(dato);
        } catch (Exception e) {
            return false;
        }
        if (this.estáVacía()) {
            this.primero = nuevo;
            this.cant = 1;
        } else {
            Nodo ultimo = this.getÚltimo();
            ultimo.siguiente = nuevo;
            nuevo.anterior = ultimo;
            this.cant++;
        }
        return true;
    }

    private Nodo getÚltimo() {
        if (this.estáVacía()) {
            return null;
        }
        Nodo último = this.primero;
        while (último.siguiente != null) {
            último = último.siguiente;
        }
        return último;
    }

    public boolean insertarPorPrimero(P dato) {
        try {
            this.primero = new Nodo<>(dato, this.primero, null);

        } catch (Exception e) {
            return false;
        }
        if (this.primero.siguiente != null) {
                this.primero.siguiente.anterior = this.primero;
            }
        this.cant++;
        return true;
    }

    public boolean insertar(P dato, int pos) {
        if (pos < 0 || pos > this.cant) {
            return false;
        }
        if (pos == 0) {
            return insertarPorPrimero(dato);
        }
        if (pos == this.cant) {
            return insertar(dato);
        }
        Nodo anterior = this.getNodo(pos-1);
        try {
            anterior.siguiente = new Nodo(dato, anterior.siguiente, anterior);
            anterior.siguiente.siguiente.anterior = anterior.siguiente;
            this.cant++;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean borrarPorPosicion(int pos) {
        if (this.estáVacía() || pos < 0 || pos >= this.cant) {
            return false;
        }
        if(pos==0){
            this.primero = this.primero.siguiente;
            if(this.cant!=1)
                this.primero.anterior = null;
        }else{
            Nodo anterior = this.getNodo(pos);
            anterior.anterior.siguiente = anterior.siguiente;
            if(anterior.siguiente!=null)
                anterior.siguiente.anterior = anterior.anterior;}

        this.cant--;
        return true;
    }

    private Nodo getNodo(int pos) {
        if (pos < 1 || pos >= this.cant) {
            return null;
        }
        Nodo anterior = this.primero;
        for (int posActual = 0; posActual < pos; posActual++) {
            anterior = anterior.siguiente;
        }
        return anterior;
    }

    //NO TIENE APLICACIÓN DADO QUE EN EL INSERTAR NO VERIFICAMOS QUE NO SE INSERTEN VALORES REPETIDOS
    public boolean borrarPorDatoSinDuplicados(P dato) {
        if (this.estáVacía() || dato == null) {
            return false;
        }
        if (this.primero.dato.equals(dato)) {
            this.primero = this.primero.siguiente;
            if(this.cant!=1)
                this.primero.anterior = null;
            return true;
        }
        Nodo<P> actual = this.primero;
        while (actual.siguiente != null) {
            if (actual.siguiente.dato.equals(dato)) {
                actual.siguiente = actual.siguiente.siguiente;
                if(actual.siguiente!=null)
                    actual.siguiente.anterior = actual;
                this.cant--;
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    public boolean borrarPorDato(P dato) {
        boolean borrado = false;
        if (!this.estáVacía() && dato != null) {
            while (!this.estáVacía() && this.primero.dato.equals(dato)) {
                this.primero = this.primero.siguiente;
                if (this.primero!=null) {
                    this.primero.anterior = null;
                }
                this.cant--;
                borrado = true;
            }
            if (!this.estáVacía()) {
                Nodo aux = this.primero;
                while (aux.siguiente != null) {
                    if (aux.siguiente.dato.equals(dato)) {
                        aux.siguiente = aux.siguiente.siguiente;
                        if(aux.siguiente!=null){
                            aux.siguiente.anterior = aux;
                        }
                        this.cant--;
                        borrado = true;
                    } else {
                        aux = aux.siguiente;
                    }
                }
            }
        }
        return borrado;
    }

    public P buscar(P dato) {
        Nodo<P> actual = this.primero;
        while (actual != null) {
            if (actual.dato.equals(dato)) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public P buscar(int índice) {
        if (índice < 0 || índice >= cant) {
            return null;
        }
        Nodo<P> actual = this.primero;
        for (int i = 0; i < índice; i++) {
            actual = actual.siguiente;
        }
        return actual.dato;
    }

    public void imprimir() {
        if (this.estáVacía()) {
            return;
        }
        Nodo<P> actual = this.primero;
        while (actual != null) {
            System.out.println(actual.dato);
            actual = actual.siguiente;
        }
    }

    public void imprimirParesImpares(boolean par) {
        Nodo<P> pi = par ? this.primero : this.primero.siguiente;

        while (pi != null) {
            System.out.println(pi.dato);
            if (pi.siguiente != null) {
                pi = pi.siguiente.siguiente;
            } else {
                pi = null;
            }
        }
    }

    public int getCantidad() {
        return this.cant;
    }
}     