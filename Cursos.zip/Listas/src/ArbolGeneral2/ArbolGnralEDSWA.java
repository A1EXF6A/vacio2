/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ArbolGeneral2;

/**
 *
 * @author Estudiante
 */
public class ArbolGnralEDSWA {

    public static void main(String[] args) {
        ÁrbolGnral a = new ÁrbolGnral();
        /*
        a.raíz = new NodoAGnral(3);
        a.raíz.hijos.add(new NodoAGnral(5));
        a.raíz.hijos.add(new NodoAGnral(8));
        a.raíz.hijos.add(new NodoAGnral(10));
        a.raíz.hijos.get(0).hijos.add(new NodoAGnral(2));
        a.raíz.hijos.get(0).hijos.add(new NodoAGnral(1));
        */
        a.insertar(3, null);
        a.insertar(5, 3);
        a.insertar(8, 3);
        a.insertar(10, 3);
        a.insertar(2, 5);
        a.insertar(1, 5);
        ÁrbolBin equivalente = a.transformarEnBinario();
        System.out.println("SIMÉTRICO ARBOL BINARIO EQUIVALENTE");
        equivalente.imprimirSimétrico();
        System.out.println("PREORDEN ARBOL GNRAL");
        a.imprimirPreorden();
        int cantHijos = equivalente.cantHijos(a.raíz.dato);
        NodoABin padreDe = equivalente.padreDe(equivalente.buscar(8));
    }
}
