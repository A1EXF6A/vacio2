/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolGeneral2;

import java.util.LinkedList;

/**
 *
 * @author Estudiante
 */
class NodoABin {

    Comparable dato;
    NodoABin izq;
    NodoABin der, padre;

    public NodoABin(Comparable dato) {
        this.dato = dato;
        this.izq = this.der = this.padre = null;
    }

    public NodoABin(Comparable dato, NodoABin izq, NodoABin der, NodoABin padre) {
        this.dato = dato;
        this.izq = izq;
        this.der = der;
        this.padre = padre;
    }

    void imprimirSimétrico() {
        if (this.izq != null) {
            this.izq.imprimirSimétrico();
        }
        System.out.println(this.dato);
        if (this.der != null) {
            this.der.imprimirSimétrico();
        }
    }

    void imprimirPreorden() {
        System.out.println(this.dato);
        if (this.izq != null) {
            this.izq.imprimirPreorden();
        }
        if (this.der != null) {
            this.der.imprimirPreorden();
        }
    }

    void imprimirPosorden() {
        if (this.izq != null) {
            this.izq.imprimirPosorden();
        }
        if (this.der != null) {
            this.der.imprimirPosorden();
        }
        System.out.println(this.dato);
    }

    boolean insertarLexicográfico(Comparable dato) {
        if (this.dato.equals(dato)) {
            return false;
        }
        if (this.dato.compareTo(dato) < 0) {
            if (this.der == null) {
                this.der = new NodoABin(dato, null, null, this);
                return true;
            }
            return this.der.insertarLexicográfico(dato);
        }
        if (this.izq == null) {
            this.izq = new NodoABin(dato, null, null, this);
            return true;
        }
        return this.izq.insertarLexicográfico(dato);
    }

    int nivel() {
        if (this.padre == null) {
            return 0;
        }
        return this.padre.nivel() + 1;
    }

    int grado() {
        int grado = 0;
        if (this.izq != null) {
            grado++;
        }
        if (this.der != null) {
            grado++;
        }
        return grado;
    }

    NodoABin buscar(Comparable dato) {
        if (this.dato.equals(dato)) {
            return this;
        }
        NodoABin buscado = null;
        if (this.izq != null) {
            buscado = this.izq.buscar(dato);
        }
        if (buscado == null && this.der != null) {
            return this.der.buscar(dato);
        }
        return buscado;
    }

    NodoABin padreDe(NodoABin hijo) {
        if (this == hijo || this.izq == null) {
            return null;
        }
        NodoABin aux = this.izq;
        while (aux != null) {
            if (aux == hijo) {
                return this;
            } else {
                aux = aux.der;
            }
        }

        NodoABin padre = null;

        if (this.izq != null) {
            padre = this.izq.padreDe(hijo);
        }

        if (padre == null && this.der != null) {
            padre = this.der.padreDe(hijo);
        }

        return padre;
    }

    LinkedList<NodoABin> hermanos() {
        LinkedList a = new LinkedList<>();
        if (this.padre != null) {
            NodoABin b = this.padre.izq;
            while (b != null) {
                if (b != this) {
                    a.add(b);
                }
            }
        }
        return a;
    }

    int nivelNodo(Comparable dato) {
        if (this.padre == null) {
            return 0;
        }

        return 1 + this.padre.nivel();

    }

    void imprimirPreordenNoSm(){
        System.out.println(this.dato);
        
    }

}
