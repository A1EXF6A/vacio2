/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolGeneral2;

import java.util.LinkedList;

/**
 *
 * @author Estudiante
 */
class ÁrbolBin {
    NodoABin raíz;

    public ÁrbolBin() {
        this.raíz = null;
    }

    void imprimirSimétrico() {
        if (this.raíz != null)
            this.raíz.imprimirSimétrico();
    }
    
    void imprimirPreorden() {
        if (this.raíz != null)
            this.raíz.imprimirPreorden();
    }
    
    void imprimirPosorden() {
        if (this.raíz != null)
            this.raíz.imprimirPosorden();
    }
         
    boolean insertarLexicográfico(Comparable dato){
        if (this.raíz != null)
            return this.raíz.insertarLexicográfico(dato);
        this.raíz = new NodoABin(dato);
        return true;
    }

    int cantHijos(Comparable dato) {
        NodoABin buscado = this.buscar(dato);
        if (buscado == null)
            return -1;
        int cantHijos = 0;
        if (buscado.izq != null){
            buscado = buscado.izq;
            cantHijos = 1;
            while (buscado.der != null){
                buscado = buscado.der;
                cantHijos ++;
            }
        }
        return cantHijos;
    }

    public NodoABin buscar(Comparable dato) {
        if (this.raíz == null)
            return null;
        return this.raíz.buscar(dato);
    }

    NodoABin padreDe(NodoABin hijo) {
        if (this.raíz == null)
            return null;
        return this.raíz.padreDe(hijo);
    }
    
    LinkedList<NodoABin> hermanos(Comparable bro){
        NodoABin hermano = this.buscar(bro);
        return hermano.hermanos();
    }
    
}
