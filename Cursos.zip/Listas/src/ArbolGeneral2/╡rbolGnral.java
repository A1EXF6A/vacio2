/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolGeneral2;

/**
 *
 * @author Estudiante
 */
class ÁrbolGnral {

    NodoAGnral raíz;

    private boolean insertar(Comparable dato, NodoAGnral futuroPadre) {
        if (futuroPadre == null) {
            if (this.raíz != null) {
                return false;
            } else {
                try {
                    this.raíz = new NodoAGnral(dato);
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        }
        try {
            futuroPadre.hijos.add(new NodoAGnral(dato));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean insertar(Comparable dato, Comparable datoFuturoPadre) {
        NodoAGnral futuroPadre = this.buscar(datoFuturoPadre);
        return this.insertar(dato, futuroPadre);
    }

    public NodoAGnral buscar(Comparable dato) {
        if (this.raíz == null) {
            return null;
        }
        return this.raíz.buscar(dato);
    }

    ÁrbolBin transformarEnBinario() {
        ÁrbolBin equivalente = new ÁrbolBin();
        if (this.raíz != null){
            equivalente.raíz = new NodoABin(this.raíz.dato);
            this.raíz.alimentar(equivalente.raíz);
        }
        return equivalente;
    }

    void imprimirPreorden() {
        if (this.raíz != null)
            this.raíz.imprimirPreorden();
    }
}
