/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ArbolGeneral2;

import java.util.LinkedList;

/**
 *
 * @author Estudiante
 */
class NodoAGnral {
    Comparable dato;
    LinkedList<NodoAGnral> hijos;
    
    public NodoAGnral(Comparable dato){
        this.dato = dato;
        this.hijos = new LinkedList<>();
    }

    NodoAGnral buscar(Comparable dato) {
        if (this.dato.equals(dato))
            return this;
        for (NodoAGnral n : this.hijos){
            NodoAGnral encontrado = n.buscar(dato);
            if (encontrado != null)
                return encontrado;
        }
        return null;
    }

    void alimentar(NodoABin equivalente) {
        if (!this.hijos.isEmpty()){
            equivalente.izq = new NodoABin(this.hijos.get(0).dato,null,null,equivalente);
            this.hijos.get(0).alimentar(equivalente.izq);
            NodoABin aux = equivalente.izq;
            for (int i = 1; i < this.hijos.size(); i ++){
                aux.der = new NodoABin(this.hijos.get(i).dato,null,null,equivalente);
                this.hijos.get(i).alimentar(aux.der);
                aux = aux.der;
            }
        }
    }

    void imprimirPreorden() {
        System.out.println(this.dato);
        for (NodoAGnral hijo : this.hijos)
            hijo.imprimirPreorden();
    }
    
    
}
