/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listas;

/**
 *
 * @author HOME
 */
public class Listas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GestorPersona a = new GestorPersona();
        a.insertar(new Persona("18", "luis", "hola"));
        a.insertar(new Persona("18", "luis", "hola"));
       a.insertar(new Persona("18", "luis", "hola"));
       a.imprimir();
    }
    
}
