/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Letras;

/**
 *
 * @author HOME
 */


import java.util.Scanner;

public class ConfiguracionJuego {
    private int rondas = 5;
    private int tiempoMaximo = 30;

    public void configurarJuego(Scanner scanner) {
        System.out.println("Configuración del juego:");

        // Configurar número de rondas
        while (true) {
            try {
                System.out.print("Ingrese el número de rondas (predeterminado 5): ");
                String inputRondas = scanner.nextLine();
                if (!inputRondas.isEmpty()) {
                    int rondasIngresadas = Integer.parseInt(inputRondas);
                    if (rondasIngresadas > 0) {
                        rondas = rondasIngresadas;
                        break;
                    } else {
                        System.out.println("El número de rondas debe ser mayor que 0. Intente de nuevo.");
                    }
                } else {
                    break; // Mantener valor predeterminado
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número válido.");
            }
        }

        // Configurar tiempo máximo por turno
        while (true) {
            try {
                System.out.print("Ingrese el tiempo máximo por turno en segundos (predeterminado 30): ");
                String inputTiempo = scanner.nextLine();
                if (!inputTiempo.isEmpty()) {
                    int tiempoIngresado = Integer.parseInt(inputTiempo);
                    if (tiempoIngresado > 0) {
                        tiempoMaximo = tiempoIngresado;
                        break;
                    } else {
                        System.out.println("El tiempo máximo debe ser mayor que 0. Intente de nuevo.");
                    }
                } else {
                    break; // Mantener valor predeterminado
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número válido.");
            }
        }

        System.out.println("Configuración actualizada:");
        System.out.println("Rondas: " + rondas);
        System.out.println("Tiempo máximo por turno: " + tiempoMaximo + " segundos");
    }

    public int getRondas() {
        return rondas;
    }

    public int getTiempoMaximo() {
        return tiempoMaximo;
    }
}


