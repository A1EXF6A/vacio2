/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

/**
 *
 * @author HOME
 */
public class Solo_Estudiante extends Estudiante{
    Carrera carrera; 

    public Solo_Estudiante(Carrera carrera, String cedula, String nombreC, String direccion, String sexo, String fechaN) {
        super(cedula, nombreC, direccion, sexo, fechaN);
        this.carrera = carrera;
    }
    
    public String datos(){
        return toString()+carrera.toString();
    }
}
