/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

/**
 *
 * @author HOME
 */
package Gestion;

public class Carrera {
    public String name;
    public int semestre;

    public Carrera(String name, int semestre) {
        this.name = name;
        this.semestre = semestre;
    }

    @Override
    public String toString() {
        return "Carrera: " + this.name + ", Semestre: " + this.semestre;
    }
}

