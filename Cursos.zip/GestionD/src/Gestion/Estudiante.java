package Gestion;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HOME
 */
public class Estudiante {
    String cedula;
    String nombreC;
    String direccion; 
    String sexo;
    String fechaN;
    

    public Estudiante(String cedula, String nombreC, String direccion, String sexo, String fechaN) {
        this.cedula = cedula;
        this.nombreC = nombreC;
        this.direccion = direccion;
        this.sexo = sexo;
        this.fechaN = fechaN;
    }
    
    @Override
    public String toString(){
        return "cedula: "+this.cedula+" Nombre completo: "+this.nombreC+" Direccion: "+this.direccion+" Sexo: "+this.sexo+" FechaN: "+this.fechaN;
    }

    
    
    
}
