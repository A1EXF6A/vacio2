package Gestion;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HOME
 */
public class Empleo {
    String ermpresa;
    String cargo;

    public Empleo(String ermpresa, String cargo) {
        this.ermpresa = ermpresa;
        this.cargo = cargo;
    }
    
    @Override
    public String toString(){
        return "Empresa: "+this.ermpresa+" Cargo: "+this.cargo;
    }
}
