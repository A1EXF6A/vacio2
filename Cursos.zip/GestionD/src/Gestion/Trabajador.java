package Gestion;


import Gestion.Estudiante;
import Gestion.Empleo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HOME
 */
public class Trabajador extends Solo_Estudiante{
    Empleo empleo;

    public Trabajador(Empleo empleo, Carrera carrera, String cedula, String nombreC, String direccion, String sexo, String fechaN) {
        super(carrera, cedula, nombreC, direccion, sexo, fechaN);
        this.empleo = empleo;
    }

    

    
    public String datos1(){
        return datos()+empleo.toString();
    }
    
}
