package Gestion;

public class Main {
    public static void main(String[] args) {
        Carrera ingenieria = new Carrera("Ingeniería", 5);
        Carrera medicina = new Carrera("Medicina", 3);
        Empleo empleo1 = new Empleo("Empresa XYZ", "Desarrollador");

        Solo_Estudiante estudiante1 = new Solo_Estudiante(ingenieria, "1234567890", "Juan Pérez", "Calle 1", "M", "01/01/2000");
        Trabajador estudiante2 = new Trabajador(empleo1, medicina, "9876543210", "Ana Gómez", "Calle 2", "F", "02/02/1998");

        Gestor gestor = new Gestor();
        gestor.añadirEstudiantes(estudiante1);
        gestor.añadirEstudiantes(estudiante2);

        System.out.println("Información general de los estudiantes:");
        gestor.informacionGeneral();

        System.out.println("\nInformación de los estudiantes que solo estudian:");
        gestor.informacionEstudiantes();

        System.out.println("\nInformación de los estudiantes que trabajan:");
        gestor.informacionTrabajadores();
    }
}
