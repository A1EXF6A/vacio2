package Gestion;

import java.util.LinkedList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HOME
 */



public class Gestor {
    private LinkedList<Estudiante> estudiantes;

    public Gestor() {
        estudiantes = new LinkedList<>();
    }

    public void añadirEstudiantes(Estudiante a) {
        estudiantes.add(a);
    }

    public void informacionGeneral() {
        for (Estudiante a : estudiantes) {
            System.out.println(a.toString());
        }
    }

    public void informacionEstudiantes() {
        for (Estudiante a : estudiantes) {
            if (a instanceof Solo_Estudiante && !(a instanceof Trabajador)) {
                System.out.println(((Solo_Estudiante) a).datos());
            }
        }
    }

    public void informacionTrabajadores() {
        for (Estudiante a : estudiantes) {
            if (a instanceof Trabajador) {
                System.out.println(((Trabajador) a).datos1());
            }
        }
    }
}
