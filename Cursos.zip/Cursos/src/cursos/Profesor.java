/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cursos;

import java.time.LocalDate;
import java.time.Period;

/**
 *
 * @author HOME
 */
public class Profesor {
    final int NO_VALID_DATE = -1;
    String cedula;
    String nomApelli;
    LocalDate fechaIngreso; 
    Cursos[] lista;
    public Profesor(String cedula,String name){
        this.cedula=cedula;
        this.nomApelli = name;
        
    }
    int años(){
        LocalDate fecha = LocalDate.now();
        return ((this.fechaIngreso!=null)&&(fecha!=null))?Period.between(fechaIngreso, fecha).getYears():NO_VALID_DATE;
    }
    
}