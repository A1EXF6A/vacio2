/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cursos;

import java.time.LocalDate;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
        GestorCursos a = new GestorCursos(20);
        a.agregarCurso(new Cursos("Mate", 30, new Profesor("1850274414","luis"), 30));
        a.agregarCurso(new Cursos("Quimica", 30, new Profesor("1850274414","Maria"), 30));
        a.agregarCurso(new Cursos("Fisica", 30, new Profesor("1850274414","Madelaine"), 30));
        
        Estudiante B = new Estudiante("Luis marquez", "1111", "Ambato");
        Estudiante C = new Estudiante("Rafa Leao", "2222", "Quito");
        
        a.matricular("Mate", C);
        a.matricular("Mate", B);
        a.matricular("Historia", C);

        a.mostrarCursos();
        System.out.println("");
        a.eliminar("Fisica");
        System.out.println("");
        a.mostrarCursos();
        System.out.println("");
        a.VerEstudiantesCurso("Mate");
    }
}


















