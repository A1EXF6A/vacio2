/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cursos;

/**
 *
 * @author HOME
 */
public class GestorCursos {
    Cursos[] cursos;
    public GestorCursos(int Cantidad){
        cursos = new Cursos[Cantidad];
    }
    
    public void mostrarCursos() {
        System.out.println("Cursos: ");
        for (int i = 0; i < cursos.length; i++) {
            if (cursos[i] != null) {
                System.out.println("Curso: "+cursos[i].nombre + " Docente: " + cursos[i].profe.nomApelli+" Horas: "+cursos[i].horas);
            }
        }
    
    }
    public boolean agregarCurso(Cursos a){
        if(cursos!=null){
            for (int i = 0; i < cursos.length; i++) {
            if(cursos[i]==null){
                cursos[i]=a;
                return true;
            }
        }
            
        }return false;
        
    }
    public void matricular(String curso,Estudiante a){
        if(cursos!=null){
            for (int i = 0; i < cursos.length; i++) {
                if(cursos[i].nombre.equalsIgnoreCase(curso)){
                    cursos[i].matricularEstudiante(a);
                    break;
                }else{
                    System.out.println("No hay el curso"+" "+curso);
                    break;
                }
            }
        }else{
            //System.out.println("No hay cursos");
        }
    }
    public void VerEstudiantesCurso(String o){
        if(cursos!=null){
            for (int i = 0; i < cursos.length; i++) {
                if(cursos[i].nombre.equalsIgnoreCase(o)){
                    cursos[i].Matriculados();
                    break;
                }
            }
        }
    }
    
    public void eliminar(String a){
        if(cursos!=null){
            for (int i = 0; i < cursos.length; i++) {
                if(cursos[i].nombre.equalsIgnoreCase(a)){
                    cursos[i]=null;
                break;
            }}
        }else{
            System.out.println("No hay cursos para eliminar");
        }
    }
}
