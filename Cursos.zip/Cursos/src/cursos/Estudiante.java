/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cursos;

import java.time.LocalDate;

/**
 *
 * @author HOME
 */
public class Estudiante {
    String nomApelli;
    String cedula;
    String direccion;
    //LocalDate fechaNa;
    public Estudiante(String nomApelli,String cedula,String direccion){
        this.cedula = cedula;
        this.nomApelli = nomApelli;
        this.direccion = direccion;
    }
    
    
}
