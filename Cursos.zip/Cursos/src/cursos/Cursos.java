/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cursos;

/**
 *
 * @author HOME
 */
public class Cursos {
    String nombre;
    int horas;
    Estudiante[] matriculados;
    Profesor profe;

    public Cursos(String nombre, int horas, Profesor profe, int cantidadEstudiantes) {
        this.nombre = nombre;
        this.horas = horas;
        this.profe = profe;
        matriculados = new Estudiante[cantidadEstudiantes];
    }

    public void matricularEstudiante(Estudiante estudiante) {
        for (int j = 0; j < matriculados.length; j++) {
            if (matriculados[j] == null) {
                matriculados[j] = estudiante;
                //System.out.println("Estudiante matriculado en el curso " + nombre);
                return;
            }
        }
        System.out.println("Ya está lleno el curso");
    }
    
    public void Matriculados(){
        if(matriculados!=null){
            System.out.println("Estudiantes matriculados en "+nombre);
            for (int i = 0; i < matriculados.length; i++) {
                if(matriculados[i]!=null){
                    System.out.println("Nombre: "+matriculados[i].nomApelli+" Direccion: "+matriculados[i].direccion);
                    
                }else{
                    break;
                }
            }
        }
    }
}
