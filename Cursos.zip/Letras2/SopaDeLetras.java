import java.io.*;
import java.util.*;


public class SopaDeLetras {

    private static final Scanner scanner = new Scanner(System.in);
    private static final Random aleatorio = new Random();

    private static final List<String> palabras = new ArrayList<>();
    private static final List<Jugador> jugadores = new ArrayList<>();
    private static int rondas = 5;
    private static int tiempoMaximo = 30; // en segundos

    public static void main(String[] args) {
        cargarPalabrasDesdeArchivo("Palabras.txt"); // Suponiendo que Palabras.txt contiene 100 palabras
        int opcion;
        do {
            System.out.println("\n--- Sopa de Letras ---");
            System.out.println("1. Registrar Jugador");
            System.out.println("2. Configuración del Juego");
            System.out.println("3. Iniciar Juego");
            System.out.println("4. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 
            switch (opcion) {
                case 1 -> registrarJugadores();
                case 2 -> configurarJuego();
                case 3 -> iniciarJuego();
                case 4 -> System.out.println("Saliendo del juego. ¡Adiós!");
                default -> System.out.println("Opción inválida. Intente nuevamente.");
            }
        } while (opcion != 4);
    }

    private static void cargarPalabrasDesdeArchivo(String rutaArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                // Dividir palabras por comas, eliminar espacios y convertir a mayúsculas
                String[] arregloPalabras = linea.split(",");
                for (String palabra : arregloPalabras) {
                    palabras.add(palabra.trim().toUpperCase());
                }
            }
            System.out.println("Palabras cargadas correctamente desde " + rutaArchivo);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
    
    private static void registrarJugadores() {
        System.out.println("Ingrese los nombres de los jugadores (escriba 'listo' para finalizar):");
        String nombre;
        while (!(nombre = scanner.nextLine().trim()).equalsIgnoreCase("LISTO")) {
            if (!nombre.isEmpty()) {
                jugadores.add(new Jugador(nombre));
            }
        }
        System.out.println("Jugadores registrados correctamente.");
    }

    private static void configurarJuego() {
        System.out.print("Ingrese el número de rondas (predeterminado 5): ");
        int rondasIngresadas = scanner.nextInt();
        if (rondasIngresadas > 0) {
            rondas = rondasIngresadas;
        }

        System.out.print("Ingrese el tiempo máximo por turno en segundos (predeterminado 30): ");
        int tiempoIngresado = scanner.nextInt();
        if (tiempoIngresado > 0) {
            tiempoMaximo = tiempoIngresado;
        }
        scanner.nextLine(); // Consumir el salto de línea
        System.out.println("Juego configurado correctamente.");
    }

    private static void iniciarJuego() {
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores registrados. Por favor registre jugadores primero.");
            return;
        }
        
        if (palabras.isEmpty()) {
            System.out.println("No hay palabras disponibles. Por favor cargue palabras desde un archivo.");
            return;
        }
        
        System.out.println("\n--- Iniciando el Juego ---");
        for (int ronda = 1; ronda <= rondas; ronda++) {
            System.out.println("\n--- Ronda " + ronda + " ---");
            String palabra = palabras.get(aleatorio.nextInt(palabras.size())); // Escoge una palabra al azar
            System.out.println("Palabra seleccionada: " + palabra); // Muestra solo la palabra seleccionada
            System.out.println("La palabra tiene " + palabra.length() + " caracteres.");
            
            char[][] matriz = generarMatriz(palabra); // Matriz fija de 15x15
            System.out.println("Matriz de palabras:");
            mostrarMatriz(matriz);

            for (Jugador jugador : jugadores) {
                System.out.println("\nJugador: " + jugador.obtenerNombre());
                System.out.println("Adivine la posición de la palabra (fila_inicio,columna_inicio fila_fin,columna_fin):");
                long tiempoInicio = System.currentTimeMillis();
                
                String intento = scanner.nextLine().trim();
                
                if (!intento.matches("\\d+,\\d+ \\d+,\\d+")) {
                    System.out.println("Formato inválido. Use 'fila1,columna1 fila2,columna2'.");
                    continue;
                }

                String[] posiciones = intento.split(" ");
                long tiempoFin = System.currentTimeMillis();
                int tiempoTranscurrido = (int) ((tiempoFin - tiempoInicio) / 1000);

                if (tiempoTranscurrido > tiempoMaximo) {
                    System.out.println("Tiempo excedido. No se otorgan puntos.");
                } else if (posiciones.length == 2 &&
                        validarPosicionPalabra(matriz, palabra, posiciones[0], posiciones[1])) {
                    System.out.println("¡Correcto! Se otorgan puntos.");
                    jugador.agregarPuntos(10);
                    jugador.agregarTiempo(tiempoTranscurrido);
                } else {
                    System.out.println("Incorrecto. No se otorgan puntos.");
                }
            }
        }
        mostrarResultados();
    }

    public static char[][] generarMatriz(String palabra) {
        final int TAMANIO_MATRIZ = 15; // Tamaño fijo de la matriz
        char[][] matriz = new char[TAMANIO_MATRIZ][TAMANIO_MATRIZ];

        // Llenar la matriz con letras aleatorias
        for (int i = 0; i < TAMANIO_MATRIZ; i++) {
            for (int j = 0; j < TAMANIO_MATRIZ; j++) {
                matriz[i][j] = (char) ('A' + aleatorio.nextInt(26)); // Letras A-Z
            }
        }

        // Colocar la palabra al azar
        colocarPalabraEnMatriz(matriz, palabra);

        return matriz;
    }

    private static void colocarPalabraEnMatriz(char[][] matriz, String palabra) {
        int tamanio = palabra.length();
        int direccion = aleatorio.nextInt(6); // 0: izq-der, 1: der-izq, 2: arr-aba, 3: aba-arr, 4: diagonal
        int fila = aleatorio.nextInt(tamanio);
        int columna = aleatorio.nextInt(tamanio);

        switch (direccion) {
            case 0: // Izquierda a derecha
                if (columna + tamanio <= matriz.length) {
                    for (int i = 0; i < tamanio; i++) {
                        matriz[fila][columna + i] = palabra.charAt(i);
                    }
                }
                break;
            case 1: // Derecha a izquierda
                if (columna - tamanio >= -1) {
                    for (int i = 0; i < tamanio; i++) {
                        matriz[fila][columna - i] = palabra.charAt(i);
                    }
                }
                break;
            case 2: // Arriba hacia abajo
                if (fila + tamanio <= matriz.length) {
                    for (int i = 0; i < tamanio; i++) {
                        matriz[fila + i][columna] = palabra.charAt(i);
                    }
                }
                break;
            case 3: // Abajo hacia arriba
                if (fila - tamanio >= -1) {
                    for (int i = 0; i < tamanio; i++) {
                        matriz[fila - i][columna] = palabra.charAt(i);
                    }
                }
                break;
            case 4: // Diagonal (izquierda a derecha)
                if (fila + tamanio <= matriz.length && columna + tamanio <= matriz.length) {
                    for (int i = 0; i < tamanio; i++) {
                        matriz[fila + i][columna + i] = palabra.charAt(i);
                    }
                }
                break;
            case 5: // Diagonal (derecha a izquierda)
                if (fila + tamanio <= matriz.length && columna - tamanio >= -1) {
                    for (int i = 0; i < tamanio; i++) {
                        matriz[fila + i][columna - i] = palabra.charAt(i);
                    }
                }
                break;
        }
    }

    private static void mostrarMatriz(char[][] matriz) {
        for (char[] fila : matriz) {
            for (char celda : fila) {
                System.out.print(celda + " ");
            }
            System.out.println();
        }
    }

    private static void mostrarResultados() {
        System.out.println("\n--- Resultados del Juego ---");
        jugadores.sort(Comparator.comparingInt(Jugador::obtenerPuntos).reversed()
                .thenComparingInt(Jugador::obtenerTiempoTotal));

        for (int i = 0; i < jugadores.size(); i++) {
            System.out.println((i + 1) + ". " + jugadores.get(i));
        }

        if (jugadores.size() > 1 &&
                jugadores.get(0).obtenerPuntos() == jugadores.get(1).obtenerPuntos()) {
            System.out.println("¡Empate! Ganador decidido por el tiempo total.");
        } else {
            System.out.println("Ganador: " + jugadores.get(0).obtenerNombre());
        }
    }
        public static boolean validarPosicionPalabra(char[][] matriz, String palabra, String inicio, String fin) {
    String[] coordenadasInicio = inicio.split(",");
    String[] coordenadasFin = fin.split(",");

    if (coordenadasInicio.length != 2 || coordenadasFin.length != 2) {
        System.out.println("Formato de entrada inválido. Use fila,columna.");
        return false;
    }

    try {
        int filaInicio = Integer.parseInt(coordenadasInicio[0]) - 1;
        int columnaInicio = Integer.parseInt(coordenadasInicio[1]) - 1;
        int filaFin = Integer.parseInt(coordenadasFin[0]) - 1;
        int columnaFin = Integer.parseInt(coordenadasFin[1]) - 1;

        int longitudPalabra = palabra.length();

        // Validar horizontal (izquierda a derecha)
        if (filaInicio == filaFin && columnaFin - columnaInicio + 1 == longitudPalabra) {
            for (int i = 0; i < longitudPalabra; i++) {
                if (matriz[filaInicio][columnaInicio + i] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

        // Validar horizontal (derecha a izquierda)
        if (filaInicio == filaFin && columnaInicio - columnaFin + 1 == longitudPalabra) {
            for (int i = 0; i < longitudPalabra; i++) {
                if (matriz[filaInicio][columnaInicio - i] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

        // Validar vertical (arriba hacia abajo)
        if (columnaInicio == columnaFin && filaFin - filaInicio + 1 == longitudPalabra) {
            for (int i = 0; i < longitudPalabra; i++) {
                if (matriz[filaInicio + i][columnaInicio] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

        // Validar vertical (abajo hacia arriba)
        if (columnaInicio == columnaFin && filaInicio - filaFin + 1 == longitudPalabra) {
            for (int i = 0; i < longitudPalabra; i++) {
                if (matriz[filaInicio - i][columnaInicio] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

        // Validar diagonal (izquierda a derecha)
        if (filaFin - filaInicio == columnaFin - columnaInicio && filaFin - filaInicio + 1 == longitudPalabra) {
            for (int i = 0; i < longitudPalabra; i++) {
                if (matriz[filaInicio + i][columnaInicio + i] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

        // Validar diagonal (derecha a izquierda)
        if (filaFin - filaInicio == columnaInicio - columnaFin && filaFin - filaInicio + 1 == longitudPalabra) {
            for (int i = 0; i < longitudPalabra; i++) {
                if (matriz[filaInicio + i][columnaInicio - i] != palabra.charAt(i)) {
                    return false;
                }
            }
            return true;
        }

    } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
        System.out.println("Coordenadas inválidas. Asegúrese de que están dentro del rango de la matriz.");
    }

    return false;
}
}

 
