class Jugador {
    private final String nombre;
    private int puntos;
    private int tiempoTotal;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.puntos = 0;
        this.tiempoTotal = 0;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public int obtenerPuntos() {
        return puntos;
    }

    public int obtenerTiempoTotal() {
        return tiempoTotal;
    }

    public void agregarPuntos(int puntos) {
        this.puntos += puntos;
    }

    public void agregarTiempo(int tiempo) {
        this.tiempoTotal += tiempo;
    }

    @Override
    public String toString() {
        return nombre + " - Puntos: " + puntos + ", Tiempo: " + tiempoTotal + "s";
    }
}
