package gestor;

import java.time.LocalDate;

public class Profesor extends Trabajador {

    private int añosExperiencia;
    private Lista<Curso> cursos;  // Usamos la clase Lista en lugar del arreglo
    private static final int CantidadMaxCursos = 4;

    public Lista<Curso> getCursos() {
        return cursos;
    }

    public Profesor(int añosExperiencia, float salario, String cedula, String nombre1, String nombre2, String apellido1, String apellido2, LocalDate fechaNacimiento) {
        super(salario, cedula, nombre1, nombre2, apellido1, apellido2, fechaNacimiento);
        this.añosExperiencia = añosExperiencia;
        this.cursos = new Lista<>();  // Inicializamos la lista de cursos
    }

    // Método modificado para usar la lista en lugar de un arreglo
    public boolean asignarCurso(Curso c) {
        if (this.cursos.cant < CantidadMaxCursos) {  // Aseguramos que no exceda el límite
            this.cursos.insertar(c);
            c.setProfesor(this);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return super.toString() + "Años de Experiencia: " + añosExperiencia;
    }
}
