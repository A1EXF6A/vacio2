package gestor;

import java.time.LocalDate;

public class Estudiante extends Persona {

    private float promedioCalificaciones;
    private String direccion;
    private Lista<Curso> cursos;  // Usamos la clase Lista en lugar del arreglo
    private final static int cantCursos = 5;

    public Estudiante(float promedioCalificaciones, String direccion, String cedula, String nombre1, String nombre2, String apellido1, String apellido2, LocalDate fechaNacimiento) {
        super(cedula, nombre1, nombre2, apellido1, apellido2, fechaNacimiento);
        this.promedioCalificaciones = promedioCalificaciones;
        this.direccion = direccion;
        this.cursos = new Lista<>();  // Inicializamos la lista de cursos
    }

    public float getPromedioCalificaciones() {
        return promedioCalificaciones;
    }

    public void setPromedioCalificaciones(float promedioCalificaciones) {
        this.promedioCalificaciones = promedioCalificaciones;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Lista<Curso> getCursos() {
        return cursos;
    }

    public void setCursos(Lista<Curso> cursos) {
        this.cursos = cursos;
    }

    
    public boolean asignarCursoEstudiante(Curso c) {
    if (c != null && this.cursos.cant < cantCursos) {
        Nodo<Curso> actual = cursos.primero;
        while (actual != null) {
            if (actual.dato.getCodigo()==c.getCodigo()) {
                return false;
            }
            actual = actual.siguiente;
        }
        this.cursos.insertar(c);
        return true;
    }
    return false;
}


    @Override
    public String toString() {
        return super.toString() + "\nPromedio de Calificaciones = " + promedioCalificaciones + "\nDireccion = " + direccion;
    }
}
