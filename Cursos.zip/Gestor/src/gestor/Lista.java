/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestor;

/**
 *
 * @author HOME
 */
public class Lista<T> {

    Nodo<T> primero;
    int cant;

    public Lista() {
        this.primero = null;
        this.cant = 0;
    }

    boolean vacia() {
        if (primero == null) {
            return true;
        }
        return false;
    }

    public boolean insertar(T a) {
        Nodo<T> nuevo;
        try {
            nuevo = new Nodo<>(a, null);
            cant++;
        } catch (Exception e) {
            return false;
        }

        if (vacia()) {
            this.primero = nuevo;
            cant++;
            return true;
        }
        Nodo<T> b = primero;
        while (b.siguiente != null) {
            b = b.siguiente;

        }
        b.siguiente = nuevo;
        cant++;
        return true;

    }

    public boolean insertarPrimero(T a) {
        Nodo<T> nuevo;
        try {
            nuevo = new Nodo<>(a, null);
            cant++;
        } catch (Exception e) {
            return false;
        }

        if (vacia()) {
            this.primero = nuevo;
            cant++;
            return true;
        }
        nuevo.siguiente = this.primero;
        this.primero = nuevo;
        cant++;
        return true;

    }

    public boolean insertarPosicion(T dato, int pos) {
        if (pos < 0 || pos > this.cant) {
            return false;
        }
        if (pos == 0) {
            return insertarPrimero(dato);
        }
        if (pos == this.cant) {
            return insertar(dato);
        }
        Nodo<T> nuevo = this.primero;
        int posA = 0;
        pos--;
        while (posA < pos) {
            nuevo = nuevo.siguiente;
            posA++;
        }
            try {
                nuevo.siguiente = new Nodo<>(dato, nuevo.siguiente);
                cant++;
                return true;
            } catch (Exception e) {
                return false;
            }
    }

    public T buscarDato(T dato) {
        if (vacia()) {
            return null;
        }
        Nodo<T> a = primero;
        while (a.siguiente != null) {
            if (a.dato.equals(dato)) {
                return a.dato;
            }

            a = a.siguiente;
        }
        return null;
    }

    public boolean eliminarDato(T dato) {
    if (vacia()) {
        return false;
    }

    boolean borra = false;
    while (primero != null && primero.dato.equals(dato)) {
        primero = primero.siguiente;
        borra = true;
        this.cant--;
    }
    Nodo<T> actual = primero;
    while (actual != null && actual.siguiente != null) {
        if (actual.siguiente.dato.equals(dato)) {
            actual.siguiente = actual.siguiente.siguiente;
            borra = true;
            this.cant--;
        } else {
            actual = actual.siguiente;
        }
    }
    return borra;
}

    
    public boolean eliminarPosicion(int pos){
        Nodo<T> act = primero;
        if(vacia()||pos<0||pos>=cant){
            return false;
        }
        if(pos==0){
            primero=primero.siguiente;
            cant--;
            return true;
        }
        pos--;
        for (int i = 0; i < pos; i++) {
            
            act = act.siguiente;
        }
        if(act.siguiente!=null){
            act.siguiente = act.siguiente.siguiente;
            cant--;
            return true;
        }
        return false;
    }

    public void imprimir() {
        while (primero != null) {
            System.out.println(primero.toString());
            primero = primero.siguiente;
        }
    }
}
