package gestor;

public class GestorUnidad {

    private Lista<Estudiante> estudiantes;
    private Lista<Profesor> profesores;
    private Lista<Curso> cursos;

    public GestorUnidad() {
        this.estudiantes = new Lista<>();
        this.profesores = new Lista<>();
        this.cursos = new Lista<>();
    }

    // Registrar Estudiante
    public boolean registrarEstudiante(Estudiante estudiante) {
        return this.estudiantes.insertar(estudiante);
    }

    // Registrar Profesor
    public boolean registrarProfesor(Profesor profesor) {
        return this.profesores.insertar(profesor);
    }

    // Crear Curso
    public boolean crearCurso(Curso curso) {
        return this.cursos.insertar(curso);
    }

    // Inscribir Estudiante en Curso
    public boolean inscribirEstudianteEnCurso(String cedulaEstudiante, int codigoCurso) {
        Estudiante estudiante = buscarEstudiantePorCedula(cedulaEstudiante);
        Curso curso = buscarCursoPorCodigo(codigoCurso);

        if (estudiante != null && curso != null) {
            if (curso.matricularEstudianteCurso(estudiante)&&estudiante.asignarCursoEstudiante(curso)) {
                
                return true;
            }
        }
        return false;
    }

    // Buscar estudiante por cédula
    public Estudiante buscarEstudiantePorCedula(String cedula) {
        Nodo<Estudiante> actual = estudiantes.primero;
        while (actual != null) {
            if (actual.dato.getCedula().equals(cedula)) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    // Buscar curso por código
    public Curso buscarCursoPorCodigo(int codigo) {
        Nodo<Curso> actual = cursos.primero;
        while (actual != null) {
            if (actual.dato.getCodigo() == codigo) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    // Generar reporte de estudiantes y profesores
    public void generarReporteEstudiantesYProfesores() {
        System.out.println("Lista de Estudiantes:");
        Nodo<Estudiante> actualEstudiante = estudiantes.primero;
        while (actualEstudiante != null) {
            System.out.println(actualEstudiante.dato.toString());
            actualEstudiante = actualEstudiante.siguiente;
        }

        System.out.println("\nLista de Profesores:");
        Nodo<Profesor> actualProfesor = profesores.primero;
        while (actualProfesor != null) {
            System.out.println(actualProfesor.dato.toString());
            actualProfesor = actualProfesor.siguiente;
        }
    }

    // Generar reporte de estudiantes inscritos por curso
    public void generarReporteEstudiantesPorCurso() {
        Nodo<Curso> actualCurso = cursos.primero;
        while (actualCurso != null) {
            System.out.println("\nCurso: " + actualCurso.dato.getNombre());
            System.out.println("Estudiantes inscritos:");
            Nodo<Estudiante> actualEstudiante = actualCurso.dato.getEstudiantes().primero;
            if (actualEstudiante == null) {
                System.out.println("No hay estudiantes inscritos en este curso.");
            } else {
                while (actualEstudiante != null) {
                    System.out.println(actualEstudiante.dato.nombreCompleto());
                    actualEstudiante = actualEstudiante.siguiente;
                }
            }
            actualCurso = actualCurso.siguiente;
        }
    }
}
