/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestor;

/**
 *
 * @author HOME
 */
public class Nodo<T> {
    T dato;
    Nodo< T> siguiente;
    public Nodo(T a) {
        this.dato = a;
        siguiente = null;
    }
    
    public Nodo(T a,Nodo b) {
        this.dato = a;
        this.siguiente = b;
    }
    
}
