package gestor;

class Curso  {

    private String nombre;
    private int cantHoras;
    private Lista<Estudiante> estudiantes;
    public Profesor profesor;
    private int codigo;

    public Curso(String nombre, int cantHoras, Profesor profesor, int codigo) {
        this.nombre = nombre;
        this.cantHoras = cantHoras;
        this.profesor = profesor;
        this.codigo = codigo;
        this.estudiantes = new Lista<>();
    }

    public int getCodigo() {
        return this.codigo;
    }

    

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return " Codigo de Curso = " + this.codigo + "\n Nombre del Curso = " + this.nombre + "\n Cantidad de horas = " + this.cantHoras
                + "\n Profesor = " + this.profesor.toString();
    }

    

    

    

    public int getCantHoras() {
        return this.cantHoras;
    }

    public void setCantHoras(int cantHoras) {
        this.cantHoras = cantHoras;
    }

    public Profesor getProfesor() {
        return this.profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Lista<Estudiante> getEstudiantes() {
        return this.estudiantes;
    }

    public boolean matricularEstudianteCurso(Estudiante e) {
    if (estudiantes.primero == null) {
        return this.estudiantes.insertar(e);
    }
    Nodo<Estudiante> actual = estudiantes.primero;
    while (actual != null) {
        if (actual.dato.cedula.equals(e.cedula)) {
            return false; 
        }
        actual = actual.siguiente;
    }
    return this.estudiantes.insertar(e);
}
}
