/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestor;

import java.time.LocalDate;

/**
 *
 * @author HOME
 */
public class Gestor {

    /**
     * @param args the command line arguments
     */
  
    
    public static void main(String[] args) {
        // Crear una instancia del gestor
        GestorUnidad gestor = new GestorUnidad();

        // Registrar algunos estudiantes
        Estudiante estudiante1 = new Estudiante(9.5f, "Calle Falsa 123", "0102030405", "Juan", "Carlos", "Pérez", "Ramírez", LocalDate.of(2000, 5, 15));
        Estudiante estudiante2 = new Estudiante(8.2f, "Av. Siempreviva 742", "0203040506", "Ana", "María", "López", "García", LocalDate.of(2001, 8, 23));
        Estudiante estudiante3 = new Estudiante(7.8f, "Calle Luna 45", "0304050607", "Luis", "Alberto", "Sánchez", "Martínez", LocalDate.of(1999, 11, 3));
        
        System.out.println(gestor.registrarEstudiante(estudiante1));
        System.out.println(gestor.registrarEstudiante(estudiante2));
        System.out.println(gestor.registrarEstudiante(estudiante3));

        // Registrar algunos profesores
        Profesor profesor1 = new Profesor(10, 1200.0f, "1111111111", "Carlos", "Andrés", "Ramírez", "Hernández", LocalDate.of(1980, 1, 10));
        Profesor profesor2 = new Profesor(5, 1000.0f, "2222222222", "Marta", "Elena", "Gómez", "Suárez", LocalDate.of(1985, 2, 20));
        
        gestor.registrarProfesor(profesor1);
        gestor.registrarProfesor(profesor2);

        // Crear algunos cursos
        Curso curso1 = new Curso("Matemáticas", 40, profesor1, 101);
        Curso curso2 = new Curso("Programación", 60, profesor2, 102);
        
        gestor.crearCurso(curso1);
        //System.out.println("111"+gestor.crearCurso(curso1));
        gestor.crearCurso(curso2);

        System.out.println(gestor.buscarEstudiantePorCedula("0102030405").nombre1);
        System.out.println(gestor.buscarCursoPorCodigo(101).getNombre());
        // Inscribir estudiantes en cursos
        
        System.out.println(gestor.inscribirEstudianteEnCurso("0102030405", 101)); // Juan Carlos en Matemáticas
        System.out.println(gestor.inscribirEstudianteEnCurso("0102030405", 101)+"444");
        System.out.println(gestor.inscribirEstudianteEnCurso("0203040506", 101)); // Ana María en Matemáticas
        System.out.println(gestor.inscribirEstudianteEnCurso("0304050607", 102)); // Luis Alberto en Programación
        System.out.println(gestor.inscribirEstudianteEnCurso("0102030405", 102)); // Juan Carlos en Programación

        // Generar reportes
        System.out.println("Reporte de Estudiantes y Profesores:");
        gestor.generarReporteEstudiantesYProfesores();
        
        System.out.println("\nReporte de Estudiantes por Curso:");
        gestor.generarReporteEstudiantesPorCurso();
    }}
    

