/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuadrado_O_Rectangulo;

/**
 *
 * @author HOME
 */
public class Rectangulo extends Cuadrado{
    double otroLado;

    public Rectangulo(double otroLado, double lado) {
        super(lado);
        this.otroLado = otroLado;
    }
    
    @Override
    public double area(){
        return super.lado*otroLado;
    }
}
