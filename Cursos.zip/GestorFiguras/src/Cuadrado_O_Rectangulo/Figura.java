/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuadrado_O_Rectangulo;

/**
 *
 * @author HOME
 */
public abstract class Figura {
    double lado;

    public Figura(double lado) {
        this.lado = lado;
    }
    
}
