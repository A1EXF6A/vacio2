/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuadrado_O_Rectangulo;

/**
 *
 * @author HOME
 */
public class Cuadrado2 extends Rectangulo2{
    
    double lado1,lado2;
    public Cuadrado2(double ancho, double largo) {
        super(ancho, largo);
        lado1=ancho;
        lado2=ancho;
        
    }
    
    @Override
    public double area(){
        return lado1*lado2;
    }
    
    
    
    
    
}
