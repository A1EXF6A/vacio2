/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuadrado_O_Rectangulo;

/**
 *
 * @author HOME
 */
public class Figura2 {
    double ancho, largo;

    public Figura2(double ancho, double largo) {
        this.ancho = ancho;
        this.largo = largo;
    }
    
}
