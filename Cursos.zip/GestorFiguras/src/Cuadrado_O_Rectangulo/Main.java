/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuadrado_O_Rectangulo;

/**
 *
 * @author HOME
 */
public class Main {
    public static void main(String[] args) {
        Cuadrado a = new Cuadrado(10);
        Rectangulo b = new Rectangulo(5, 10);
        System.out.println(a.area());
        System.out.println(b.area());
    }
}
