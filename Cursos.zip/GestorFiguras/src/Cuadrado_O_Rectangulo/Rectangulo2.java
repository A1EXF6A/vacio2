/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuadrado_O_Rectangulo;

/**
 *
 * @author HOME
 */
public class Rectangulo2 extends Figura2{

    public Rectangulo2(double ancho, double largo) {
        super(ancho, largo);
    }
    
    public double area(){
        return ancho*largo;
    }
    
}
