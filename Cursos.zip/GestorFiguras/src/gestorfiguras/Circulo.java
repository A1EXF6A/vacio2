/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestorfiguras;

import java.awt.geom.Area;

/**
 *
 * @author HOME
 */
public class Circulo extends Figura{
    double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }
    
    @Override
    public double area(){
        return Math.PI+Math.pow(radio, 2);
    }
    
}
