/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo7;



/**
 *
 * @author ASUS
 */
public class Ventas {
   Vehiculo vehiculo;
   String fech_nac;
   float prec_ven;

    public Ventas(Vehiculo vehiculo, String fech_nac, float prec_ven) {
        this.vehiculo = vehiculo;
        this.fech_nac = fech_nac;
        this.prec_ven = prec_ven;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public String getFech_nac() {
        return fech_nac;
    }

    public void setFech_nac(String fech_nac) {
        this.fech_nac = fech_nac;
    }

    public float getPrec_ven() {
        return prec_ven;
    }

    public void setPrec_ven(float prec_ven) {
        this.prec_ven = prec_ven;
    }

    @Override
    public String toString() {
        return "Ventas{" + "vehiculo=" + vehiculo + ", fech_nac=" + fech_nac + ", prec_ven=" + prec_ven + '}';
    }
   
    
}
