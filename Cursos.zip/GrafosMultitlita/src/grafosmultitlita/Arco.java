/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafosmultitlita;

/**
 *
 * @author ASUS VIVOBOOK
 */
class Arco {
    private Vertice origen;
    private Vertice destino;

    public Arco(Vertice origen, Vertice destino) {
        this.origen = origen;
        this.destino = destino;
    }

    public Vertice getOrigen() {
        return origen;
    }

    public Vertice getDestino() {
        return destino;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Arco) {
            Arco otro = (Arco) obj;
            return this.origen.equals(otro.origen) && this.destino.equals(otro.destino);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return origen.hashCode() + destino.hashCode();
    }
}
