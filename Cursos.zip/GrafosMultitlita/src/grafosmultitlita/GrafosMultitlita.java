/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafosmultitlita;

/**
 *
 * @author ASUS VIVOBOOK
 */
public class GrafosMultitlita {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Grafo grafo = new Grafo();

        System.out.println("Creando un grafo...");

        // Insertar vértices
        grafo.insertarVertice("A");
        grafo.insertarVertice("B");
        grafo.insertarVertice("C");
        System.out.println("Vértices insertados: A, B, C");

        // Insertar arcos
        grafo.insertarArco("A", "B");
        grafo.insertarArco("B", "C");
        System.out.println("Arcos insertados: A -> B, B -> C");

        // Verificar si el grafo está vacío
        System.out.println("¿El grafo está vacío? " + (grafo.estaVacio() ? "Sí" : "No"));

        // Verificar adyacencia entre vértices
        System.out.println("¿A y B son adyacentes? " + (grafo.sonAdyacentes("A", "B") ? "Sí" : "No"));
        System.out.println("¿C y A son adyacentes? " + (grafo.sonAdyacentes("C", "A") ? "Sí" : "No"));

        // Obtener vértices adyacentes
        System.out.println("Vértices adyacentes a B: " + grafo.obtenerAdyacentes("B"));
        System.out.println("Vértices que tienen como destino a C: " + grafo.obtenerPredecesores("C"));

        // Eliminar un arco y verificar nuevamente
        grafo.eliminarArco("A", "B");
        System.out.println("Arco A -> B eliminado.");
        System.out.println("¿A y B son adyacentes tras eliminar el arco? " + (grafo.sonAdyacentes("A", "B") ? "Sí" : "No"));

        // Eliminar un vértice
        grafo.eliminarVertice("C");
        System.out.println("Vértice C eliminado.");
        System.out.println("Vértices adyacentes a C: " + grafo.obtenerAdyacentes("C"));
    }
    
}
