/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafosmultitlita;

import java.util.LinkedList;

/**
 *
 * @author ASUS VIVOBOOK
 */
public class Grafo {
    private LinkedList<Vertice> vertices;
    private LinkedList<Arco> arcos;

    public Grafo() {
        this.vertices = new LinkedList<>();
        this.arcos = new LinkedList<>();
    }

    // Verificar si el grafo está vacío
    public boolean estaVacio() {
        return this.vertices.isEmpty();
    }

    // Método para insertar un vértice
    public boolean insertarVertice(Object ponderacion) {
        if (buscarVertice(ponderacion) == null) {
            this.vertices.add(new Vertice(ponderacion));
            return true;
        }
        return false;
    }

    // Método para insertar un arco entre dos vértices
    public boolean insertarArco(Object origenPonderacion, Object destinoPonderacion) {
        Vertice origen = buscarVertice(origenPonderacion);
        Vertice destino = buscarVertice(destinoPonderacion);

        if (origen == null || destino == null) {
            return false; // Uno de los vértices no existe
        }

        Arco nuevoArco = new Arco(origen, destino);
        if (!this.arcos.contains(nuevoArco)) {
            this.arcos.add(nuevoArco);
            origen.agregarArcoSaliente(destino);
            return true;
        }
        return false; // Arco ya existe
    }

    // Método para eliminar un vértice y sus arcos relacionados
    public boolean eliminarVertice(Object ponderacion) {
        Vertice vertice = buscarVertice(ponderacion);
        if (vertice == null) {
            return false; // Vértice no existe
        }

        this.arcos.removeIf(arco -> arco.getOrigen().equals(vertice) || arco.getDestino().equals(vertice));
        this.vertices.remove(vertice);
        return true;
    }

    // Método para eliminar un arco
    public boolean eliminarArco(Object origenPonderacion, Object destinoPonderacion) {
        Vertice origen = buscarVertice(origenPonderacion);
        Vertice destino = buscarVertice(destinoPonderacion);

        if (origen == null || destino == null) {
            return false; // Uno de los vértices no existe
        }

        return this.arcos.removeIf(arco -> arco.getOrigen().equals(origen) && arco.getDestino().equals(destino));
    }

    // Verificar si dos vértices son adyacentes
    public boolean sonAdyacentes(Object origenPonderacion, Object destinoPonderacion) {
        Vertice origen = buscarVertice(origenPonderacion);
        Vertice destino = buscarVertice(destinoPonderacion);

        if (origen == null || destino == null) {
            return false;
        }

        return origen.esAdyacente(destino);
    }

    // Obtener la lista de vértices adyacentes de un vértice dado
    public LinkedList<Vertice> obtenerAdyacentes(Object ponderacion) {
        Vertice vertice = buscarVertice(ponderacion);
        if (vertice == null) {
            return null; // Vértice no existe
        }
        return vertice.getAdyacentes();
    }

    // Obtener la lista de vértices que tienen como destino un vértice dado
    public LinkedList<Vertice> obtenerPredecesores(Object ponderacion) {
        Vertice vertice = buscarVertice(ponderacion);
        if (vertice == null) {
            return null; // Vértice no existe
        }

        LinkedList<Vertice> predecesores = new LinkedList<>();
        for (Arco arco : this.arcos) {
            if (arco.getDestino().equals(vertice)) {
                predecesores.add(arco.getOrigen());
            }
        }
        return predecesores;
    }

    // Método privado para buscar un vértice por su ponderación
    private Vertice buscarVertice(Object ponderacion) {
        for (Vertice v : this.vertices) {
            if (v.getPonderacion().equals(ponderacion)) {
                return v;
            }
        }
        return null;
    }
}

