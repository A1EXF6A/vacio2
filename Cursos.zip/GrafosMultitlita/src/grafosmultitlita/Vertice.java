/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafosmultitlita;

import java.util.LinkedList;

/**
 *
 * @author ASUS VIVOBOOK
 */
class Vertice {

    private Object ponderacion;
    private LinkedList<Vertice> adyacentes;

    public Vertice(Object ponderacion) {
        this.ponderacion = ponderacion;
        this.adyacentes = new LinkedList<>();
    }

    public Object getPonderacion() {
        return ponderacion;
    }

    public LinkedList<Vertice> getAdyacentes() {
        return adyacentes;
    }

    public boolean esAdyacente(Vertice destino) {
        return adyacentes.contains(destino);
    }

    public void agregarArcoSaliente(Vertice destino) {
        if (!adyacentes.contains(destino)) {
            adyacentes.add(destino);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Vertice) {
            return this.ponderacion.equals(((Vertice) obj).ponderacion);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return ponderacion.hashCode();
    }

    @Override
    public String toString() {
        return ponderacion.toString();
    }
}
