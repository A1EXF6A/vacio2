/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

/**
 *
 * @author HOME
 */
public class Gestor {
    
    public boolean matricular(Estudiante i, Curso j) {
    if (i.añadirC(j)) {
        if (j.añadirE(i)) {
            return true;
        } else {
            j.quitarE(i);
            i.quitarC(j); 
        }
    }
    return false;
}
    
    public boolean asignar(Curso i, Profesor j){
         return j.asignar(i);
    }
    
    public void reporte(Curso i){
        System.out.println("Profesor: "+i.prof.name+" Curso: "+i.nombre);
        for (int j = 0; j < i.es.length; j++) {
            if(i.es[j]==null) return;
            System.out.println("Estudiante: "+i.es[j].name+" Apellido: "+i.es[j].ape);
        }
    }

}
