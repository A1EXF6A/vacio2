/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */
public class Main {
    public static void main(String[] args) {
    // Crear un profesor
        Profesor profesor1 = new Profesor("Juan", "Pérez", "1234567890", 10, 3); // Capacidad para 3 cursos

        // Crear algunos estudiantes
        Estudiante estudiante1 = new Estudiante("Carlos", "García", "Calle 123", LocalDateTime.now(), 2); // Capacidad para 2 cursos
        Estudiante estudiante2 = new Estudiante("Ana", "Martínez", "Calle 456", LocalDateTime.now(), 2);

        // Crear algunos cursos
        Curso curso1 = new Curso("Matemáticas", 50, 5); // Capacidad para 5 estudiantes
        Curso curso2 = new Curso("Física", 40, 3);      // Capacidad para 3 estudiantes

        // Crear el gestor
        Gestor gestor = new Gestor();

        // Asignar curso1 al profesor1
        boolean asignado = gestor.asignar(curso1, profesor1);
        boolean asignado1 = gestor.asignar(curso2, profesor1);
        System.out.println("Curso asignado al profesor: " + asignado); // true

        // Matricular estudiante1 en curso1
        boolean matriculado1 = gestor.matricular(estudiante1, curso1);
        System.out.println("Estudiante 1 matriculado en curso 1: " + matriculado1); // true
        
        boolean matriculado11 = gestor.matricular(estudiante1, curso1);
        System.out.println("Estudiante 1 matriculado en curso 1: " + matriculado11); // false

        // Matricular estudiante2 en curso1
        boolean matriculado2 = gestor.matricular(estudiante2, curso1);
        System.out.println("Estudiante 2 matriculado en curso 1: " + matriculado2); // true

        // Intentar matricular estudiante1 en curso2
        boolean matriculado3 = gestor.matricular(estudiante1, curso2);
        System.out.println("Estudiante 1 matriculado en curso 2: " + matriculado3); // true

        // Mostrar que el estudiante 1 está en los cursos
        System.out.println("Estudiante 1 está en Matemáticas: " + estudiante1.buscar(curso1)); // true
        System.out.println("Estudiante 1 está en Física: " + estudiante1.buscar(curso2)); // true
        
        gestor.reporte(curso1);
        System.out.println("");
        gestor.reporte(curso2);
    }
}
