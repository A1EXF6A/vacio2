
package Gestion;

public class Curso {
    String nombre;
    int horas;
    Estudiante [] es;
    Profesor prof;

    public Curso(String nombre, int horas,int max) {
        this.nombre = nombre;
        this.horas = horas;
        this.es = new Estudiante[max];
    }
    
    public boolean añadirE(Estudiante i){
        if(buscar(i)) return false;
        for (int j = 0; j < es.length; j++) {
            if(es[j]==null){
                es[j]=i;
                return true;
            }
        }
        return false;
    }
    
    public void quitarE(Estudiante i){
        for (int j = 0; j < es.length; j++) {
            if(es[j]!=null&&es[j].equals(i)){
                es[j]=null;
            }
        }
    }
    
    public boolean buscar(Estudiante i){
        for(Estudiante a: es){
            if(a!=null&&a.equals(i)) return true;
        }
        return false;
    }
}
