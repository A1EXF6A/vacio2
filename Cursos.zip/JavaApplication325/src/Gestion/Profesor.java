/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

/**
 *
 * @author HOME
 */
public class Profesor {
    String name;
    String ape;
    Curso[] curso;
    String cedula;
    int años;

    public Profesor(String name, String ape, String cedula, int años, int cur) {
        this.name = name;
        this.ape = ape;
        this.cedula = cedula;
        this.años = años;
        this.curso = new Curso[cur];
    }
    
    
     boolean asignar(Curso i){
        int posN= -1;
        for(int posA = 0; posA < this.curso.length;posA++){
            if(this.curso[posA]==null && posN==-1)
                posN= posA;
            if(this.curso[posA]!=null&&this.curso[posA].equals(i))
                return false;
        }
     
        if(posN==-1)
            return false;
        this.curso[posN]=i;
        i.prof = this;
        return true;
    }
    
    
}
