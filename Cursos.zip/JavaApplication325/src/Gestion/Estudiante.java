/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */
public class Estudiante {
    String name;
    String ape;
    String dire;
    LocalDateTime fe;
    Curso [] cur;

    public Estudiante(String name, String ape, String dire, LocalDateTime fe, int max) {
        this.name = name;
        this.ape = ape;
        this.dire = dire;
        this.fe = fe;
        this.cur = new Curso[max];
    }
    
    public boolean añadirC(Curso i){
        if(buscar(i)) return false;
        for (int j = 0; j < cur.length; j++) {
            if(cur[j]==null){
                cur[j]=i;
                return true;
            }
        }
        return false;
        
    }
    
    public void quitarC(Curso i){
        for (int j = 0; j < cur.length; j++) {
            if(cur[j]!=null&&cur[j].equals(i)){
                cur[j]=null;
            }
        }
    }
    
    public boolean buscar(Curso i){
        for(Curso a: cur){
            if(a!=null&&a.equals(i)) return true;
        }
        return false;
    }
    
}

