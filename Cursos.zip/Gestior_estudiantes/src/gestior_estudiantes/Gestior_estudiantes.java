/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestior_estudiantes;

/**
 *
 * @author HOME
 */
public class Gestior_estudiantes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Gestor g = new Gestor(10);
        Carrera c = new Carrera("Software");
        g.registrar(new Estudiante("1809383848", "Juan Martínez", "Ambato", "10/10/2008", 'M', c));
        g.registrar(new Estudiante("0938384948", "María González", "Guayaquil", "10/12/2012", 'F', c));
        g.registrar(new Trabajador(new Empleo(new Empresa("Quiport"), "Comercial"), "2138384948", "Pedro Gómez", "Guaranda", "10/12/2002", 'M', new Carrera("TI")));
        //g.imprimir();
        g.imprimirEs();
    }

}
