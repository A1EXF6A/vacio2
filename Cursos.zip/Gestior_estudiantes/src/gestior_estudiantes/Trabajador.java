/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestior_estudiantes;

/**
 *
 * @author HOME
 */
public class Trabajador extends Estudiante{
    Empleo empleo;

    public Trabajador(Empleo empleo, String cédula, String nombre, String dirección, String fecha, char sexo, Carrera carrera) {
        super(cédula, nombre, dirección, fecha, sexo, carrera);
        this.empleo = empleo;
    }
    
    @Override
    public void imprimir(){
        super.imprimir();
        System.out.println("Empresa: " + this.empleo.empresa.nombre);
        System.out.println("Puesto: " + this.empleo.puesto);
    }
    
    public String toString(){
        return super.toString()+empleo.toString();
    }
    
}