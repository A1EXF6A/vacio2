/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestior_estudiantes;

/**
 *
 * @author HOME
 */
public class Empleo {
    
    Empresa empresa;
    String puesto;

    public Empleo(Empresa empresa, String puesto) {
        this.empresa = empresa;
        this.puesto = puesto;
    }
    
    public String toString(){
        return empresa.toString()+" Puesto: "+puesto;
    }
}

