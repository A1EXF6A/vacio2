/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestior_estudiantes;

/**
 *
 * @author HOME
 */
public class Gestor {
    Estudiante[] estudiantes;

    public Gestor( int cantMáxEst ) {
        this.estudiantes = new Estudiante[ cantMáxEst ];
    }
    
    public boolean registrar(Estudiante estudiante){
        int posNuevoEst = -1;
        
        for (int i = 0; i < this.estudiantes.length; i++){
            if (this.estudiantes[i] == null){
                if (posNuevoEst == -1)
                    posNuevoEst = i;
            } else
                if (this.estudiantes[i].equals(estudiante))
                    return false;
        }
        
        if (posNuevoEst != -1){
            this.estudiantes[posNuevoEst] = estudiante;
            return true;
        }
        
        return false;
    }
    
    public void imprimir(){
        int id = 1;
        for (Estudiante e : this.estudiantes){
            if (e != null){
                System.out.println("Estudiante #" + id);
                e.imprimir();
                System.out.println("   ");
                id ++;
            }
        }
    }
    
    public void imprimirEs(){
        int i = 1;
        for(Estudiante a: estudiantes){
            if(a!=null){
                System.out.println(i+"._ "+a.toString());
                i++;
            }
        }
    }
    
    
}
