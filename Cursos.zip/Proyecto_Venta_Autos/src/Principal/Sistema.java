/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author HOME
 */
public class Sistema {

    GestorDatos gestorArchivos;
    LinkedList<Cliente> clientes;
    LinkedList<Vehiculo> vehiculos;
    LinkedList<Venta> ventas;
    LinkedList<Intereses> intereses;
    Scanner tec = new Scanner(System.in);

    public Sistema() {
        this.clientes = new LinkedList<>();
        this.vehiculos = new LinkedList<>();
        this.ventas = new LinkedList<>();
        this.intereses = new LinkedList<>();
        this.gestorArchivos = new GestorDatos();
    }

    public boolean registrarClientes(Cliente e) {
        if (buscarClientePorCedula(e.getCedula()) != null) {
            return false;
        }
        if (e != null) {
            this.clientes.add(e);
            return true;
        }
        return false;
    }

    public boolean añadirInteres(Cliente e, Vehiculo i) {
        if (e != null && i != null) {
            Intereses interes = new Intereses(e, i);
            this.intereses.add(interes);
            return true;
        }
        return false;
    }

    public boolean registrarVenta(Cliente cliente, Vehiculo vehiculo) {
        if (cliente != null && vehiculo != null && vehiculo.getStock() > 0) {
            float precio = calcularPrecio(vehiculo);
            System.out.println("El precio calculado del vehículo es: $" + precio);
            System.out.println("¿Desea proceder con la compra? (s/n)");
            String respuesta = tec.nextLine();
            if (respuesta.equalsIgnoreCase("s")) {
                vehiculo.reducirStock(); 

               
                if (vehiculo.getStock() == 0) {
                    vehiculos.remove(vehiculo); 
                    System.out.println("El vehículo con placa " + vehiculo.getPlaca() + " se ha agotado y ha sido eliminado del sistema.");
                }

                Venta venta = new Venta(cliente, vehiculo, precio);
                ventas.add(venta);
                cliente.añadir(vehiculo, precio);
                return true;
            } else {
                System.out.println("Compra cancelada.");
                return false;
            }
        }
        return false;
    }

    public List<Vehiculo> filtrarVehiculos(String tipo, String marca, Integer año, String color) {
        List<Vehiculo> resultados = new ArrayList<>(vehiculos);

        if (tipo != null) {
            resultados.retainAll(filtrarPorTipo(tipo));
        }
        if (marca != null) {
            resultados.retainAll(filtrarPorMarca(marca));
        }
        if (año != null) {
            resultados.retainAll(filtrarPorAño(año));
        }
        if (color != null) {
            resultados.retainAll(filtrarPorColor(color));
        }
        return resultados;
    }

    public void mostrarVehiculosFiltrados(String tipo, String marca, Integer año, String color) {
        List<Vehiculo> resultados = filtrarVehiculos(tipo, marca, año, color);
        if (resultados.isEmpty()) {
            System.out.println("No existen coincidencias");
            return;
        }
        for (Vehiculo a : resultados) {
            System.out.println(a.toString());
        }
    }

    public void mostrarHistorialCliente(Cliente i) {
        i.mostrarHistorial();
    }

    public void mostrarEstadisticasSistema(LocalDate a, LocalDate b) {
        if (ventas.isEmpty()) {
            System.out.println("No hay registro en el sistema");
        }
        for (int i = 0; i < ventas.size(); i++) {
            if (rangoFechas(a, b, ventas.get(i))) {
                System.out.println(ventas.get(i).toString());
            }
        }
        System.out.println("Total de autos vendidos: " + ventas.size());
        System.out.println("Total de dinero facturado: " + valorFacturado());
    }

    public void mostrarInterasados(String tipo) {
        if (intereses.isEmpty()) {
            System.out.println("No hay registro en el sistema");
            return;
        }
        System.out.printf("INTERASADOS\n| %-15s | %-20s | %-20s | %-15s | %-30s |\n","CEDULA", "NOMBRE","APELLIDO","TELEFONO","DIRECCION");
        for (int i = 0; i < intereses.size(); i++) {
            if (ultimaCompra(intereses.get(i).cliente) && (intereses.get(i).vehiculo.tipo.equalsIgnoreCase(tipo) || intereses.get(i).vehiculo.marca.equalsIgnoreCase(tipo))) {
                System.out.println(intereses.get(i).cliente.toString());
            }
        }

    }

    public boolean ultimaCompra(Cliente cliente) {
        if (cliente.historial.isEmpty()) {
            return false;
        }
        LocalDate ultima = cliente.ultimaCompra();
        LocalDate antes = LocalDate.now().minusYears(3);
        return ultima.isBefore(antes);
    }

    public float valorFacturado() {
        float total = 0;
        for (Venta a : ventas) {
            total += a.getPrecioVenta();
        }
        return total;
    }

    public boolean rangoFechas(LocalDate a, LocalDate b, Venta venta) {
        LocalDate fecha = venta.fechaVenta;
        if ((fecha.isEqual(a) || fecha.isAfter(a)) && (fecha.isEqual(b) || fecha.isBefore(b))) {
            return true;
        }
        return false;
    }

    public List<Vehiculo> filtrarPorTipo(String tipo) {
        List<Vehiculo> filtrados = new ArrayList<>();
        for (Vehiculo v : vehiculos) {
            if (v.getTipo().equalsIgnoreCase(tipo)) {
                filtrados.add(v);
            }
        }
        return filtrados;
    }

    public List<Vehiculo> filtrarPorMarca(String marca) {
        List<Vehiculo> filtrados = new ArrayList<>();
        for (Vehiculo v : vehiculos) {
            if (v.getMarca().equalsIgnoreCase(marca)) {
                filtrados.add(v);
            }
        }
        return filtrados;
    }

    public List<Vehiculo> filtrarPorAño(int año) {
        List<Vehiculo> filtrados = new ArrayList<>();
        for (Vehiculo v : vehiculos) {
            if (v.getAño() == año) {
                filtrados.add(v);
            }
        }
        return filtrados;
    }

    public List<Vehiculo> filtrarPorColor(String color) {
        List<Vehiculo> filtrados = new ArrayList<>();
        for (Vehiculo v : vehiculos) {
            if (v.getColor().equalsIgnoreCase(color)) {
                filtrados.add(v);
            }
        }
        return filtrados;
    }

    public Cliente buscarCliente(String cedula) {
        for (Cliente a : clientes) {
            if (a.getCedula().equalsIgnoreCase(cedula)) {
                return a;
            }
        }
        return null;
    }

    public Vehiculo buscarVehiculoPorPlaca(String placa) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getPlaca().equalsIgnoreCase(placa)) {
                return vehiculo;
            }
        }
        return null;
    }

    public void mostrarAutos() {
        if (vehiculos.isEmpty()) {
            System.out.println("No hay autos");
            return;
        }
        System.out.printf("| %-10s | %-10s | %-10s | %-10s | %-10s |\n", "Tipo", "Marca", "Placa", "Color", "Año");
        for (Vehiculo a : vehiculos) {
            if (a.getStock() > 0) {  
                System.out.println(a.toString());
            }
        }
    }

    private float calcularPrecio(Vehiculo vehiculo) {
        float precioBase = 10000;
        if (vehiculo.getAño() < 2015) {
            precioBase -= 2000;
        }
        if (vehiculo.getMarca().equalsIgnoreCase("marca de lujo")) {
            precioBase += 5000;
        }
        return precioBase;
    }

    private Cliente buscarClientePorCedula(String cedula) {
        for (Cliente cliente : clientes) {
            if (cliente.getCedula().equals(cedula)) {
                return cliente;
            }
        }
        return null;
    }

    public boolean hayAutos() {
        return vehiculos.isEmpty();
    }

    public void cargarDatos() throws IOException {
        gestorArchivos.cargarVehiculos("vehiculos.txt", vehiculos);
        gestorArchivos.cargarClientes("clientes.txt", clientes, vehiculos);
        gestorArchivos.cargarIntereses("intereses.txt", intereses, clientes, vehiculos);
        gestorArchivos.cargarVentas("ventas.txt", ventas, clientes, vehiculos);
    }

    public void guardarDatos() throws IOException {
        gestorArchivos.guardarClientes("clientes.txt", clientes);
        gestorArchivos.guardarVehiculos("vehiculos.txt", vehiculos);
        gestorArchivos.guardarVentas("ventas.txt", ventas);
        gestorArchivos.guardarIntereses("intereses.txt", intereses);
    }

}
