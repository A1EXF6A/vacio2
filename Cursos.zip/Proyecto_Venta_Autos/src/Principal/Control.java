package Principal;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Control {
    private static Scanner tec = new Scanner(System.in);

    //String con validación
    public static String leerString(String mensaje) {
        System.out.println(mensaje);
        return tec.nextLine().trim();
    }

    //leer un entero con validación
    public static int leerInt(String mensaje) {
        int numero = 0;
        boolean valido = false;
        while (!valido) {
            try {
                System.out.println(mensaje);
                numero = Integer.parseInt(tec.nextLine().trim());
                valido = true;
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número válido.");
            }
        }
        return numero;
    }

    //leer un booleano (s/n)
    public static boolean leerBoolean(String mensaje) {
        String respuesta;
        do {
            respuesta = leerString(mensaje).toLowerCase();
            if (respuesta.equals("s")) {
                return true;
            } else if (respuesta.equals("n")) {
                return false;
            } else {
                System.out.println("Respuesta inválida. Ingrese 's' para sí o 'n' para no.");
            }
        } while (true);
    }

    //fecha en formato YYYY-MM-DD
    public static LocalDate leerFecha(String mensaje) {
        LocalDate fecha = null;
        boolean valido = false;
        while (!valido) {
            try {
                String fechaStr = leerString(mensaje);
                if (!fechaStr.isEmpty()) {
                    fecha = LocalDate.parse(fechaStr);
                    valido = true;
                }
            } catch (DateTimeParseException e) {
                System.out.println("Fecha inválida. Por favor, ingrese una fecha en el formato correcto (YYYY-MM-DD).");
            }
        }
        return fecha;
    }
    
    public static boolean validarCedula(String cedula) {
        if (cedula == null || cedula.length() != 10) {
            return false;
        }
        int[] digitos = new int[10];
        for (int i = 0; i < 10; i++) {
            digitos[i] = Character.getNumericValue(cedula.charAt(i));
        }
        int suma = 0;
        for (int i = 0; i < 9; i++) {
            if (i % 2 == 0) {
                int doble = digitos[i] * 2;
                suma += (doble > 9) ? (doble - 9) : doble;
            } else {
                suma += digitos[i];
            }
        }
        int digitoVerificador = (10 - (suma % 10)) % 10;
        return digitoVerificador == digitos[9];
    }
    
    public static boolean esNumero(String input) {
        return input != null && input.matches("\\d{10}");
    }
    
    public static boolean esSoloLetras(String input) {
    return input != null && input.matches("[a-zA-Z]+");
}

}
