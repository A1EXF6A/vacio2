/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import java.time.LocalDate;

/**
 *
 * @author HOME
 */
public class Intereses {

    Cliente cliente;
    Vehiculo vehiculo;
    LocalDate fechaInteres;

    public Intereses(Cliente cliente, Vehiculo vehiculo) {
        this.cliente = cliente;
        this.vehiculo = vehiculo;
        this.fechaInteres = LocalDate.now();
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setFechaInteres(LocalDate fechaInteres) {
        this.fechaInteres = fechaInteres;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public LocalDate getFechaInteres() {
        return fechaInteres;
    }

    public LocalDate getFecha() {
        return fechaInteres;
    }

    @Override

    public String toString() {
        return String.format("Interés de %s en %s el %s", cliente.getNombre(), vehiculo.getMarca(), fechaInteres);
    }

}
