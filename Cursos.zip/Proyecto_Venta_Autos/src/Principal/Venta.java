/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import java.time.LocalDate;

/**
 *
 * @author HOME
 */
public class Venta {
    Cliente cliente;
    Vehiculo vehiculo;
    LocalDate fechaVenta;
    float precioVenta;

    public Venta(Cliente cliente,Vehiculo vehiculo, float prec_ven) {
        this.cliente = cliente;
        this.vehiculo = vehiculo;
        this.fechaVenta = LocalDate.now();
        this.precioVenta = prec_ven;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public LocalDate getFechaVenta() {
        return fechaVenta;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public LocalDate getFecheVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(LocalDate fech_nac) {
        this.fechaVenta = fech_nac;
    }

    public float getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(float prec_ven) {
        this.precioVenta = prec_ven;
    }

    @Override
    public String toString() {
        return "Vehiculo=" + vehiculo.toString() + ", fecha Venta=" + fechaVenta + ", precio Venta=" + precioVenta + '}';
    }

}
