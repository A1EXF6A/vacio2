package Principal;

import java.io.IOException;
import java.time.LocalDate;

public class Interfaz {

    Sistema sistema = new Sistema();
    String opcion;

    public void menu() throws IOException {
        sistema.cargarDatos();
        do {
            System.out.println("BIENVENIDO AL CONCESIONARIO XXXXXXX");
            System.out.println("Ingrese sus datos, por favor");
            Cliente nuevo = registro();

            if (sistema.registrarClientes(nuevo)) {
                System.out.println("Cliente registrado exitosamente.");
            } else {
                System.out.println("El cliente ya está registrado.");
            }

            boolean salir = false;
            while (!salir) {
                System.out.println("1. Autos disponibles / Comprar autos");
                System.out.println("2. Clientes interesados marca/tipo");
                System.out.println("3. Historial cliente");
                System.out.println("4. Estadísticas de la concesionaria");
                System.out.println("5. Salir");
                int op = Control.leerInt("Ingrese una opción:");

                switch (op) {
                    case 1:
                        mostrarYGestionarAutos(nuevo); 
                        break;
                    case 2:
                        mostrarClientesInteresados();
                        break;
                    case 3:
                        mostrarHistorialCliente(nuevo);
                        break;
                    case 4:
                        mostrarEstadisticas();
                        break;
                    case 5:
                        salir = true;
                        break;
                    default:
                        System.out.println("Error. OPCION INVALIDA");
                }
            }

            System.out.println("Desea repetir el proceso (s/n):");
            opcion = Control.leerString("");
        } while (opcion.equalsIgnoreCase("s"));
        sistema.guardarDatos();
    }

    private void mostrarYGestionarAutos(Cliente nuevo) {
        do {
            if (sistema.hayAutos()) {
                System.out.println("No hay autos disponibles en este momento.");
                return;
            }

            mostrarAutosDisponibles(); // Mostrar autos disponibles

            if (Control.leerBoolean("¿Desea filtrar los autos por algún criterio? (s/n)")) {
                filtrarYMostrarAutos();
            }

            if (Control.leerBoolean("¿Está interesado en algún auto? (s/n)")) {
                String placa = Control.leerString("Ingrese la placa del auto:");
                Vehiculo vehiculo = sistema.buscarVehiculoPorPlaca(placa);

                if (vehiculo != null) {
                    if (Control.leerBoolean("¿Desea comprar este auto? (s/n)")) {
                        comprarNuevoAuto(nuevo, vehiculo); 
                    } else {
                        añadirInteresEnAuto(nuevo, vehiculo); 
                    }
                } else {
                    System.out.println("No se encontró un vehículo con la placa ingresada.");
                }
            }

            opcion = Control.leerString("¿Desea ver más autos o comprar otro? (s/n):");
        } while (opcion.equalsIgnoreCase("s"));
    }

    private void comprarNuevoAuto(Cliente nuevo, Vehiculo vehiculo) {
        if (sistema.registrarVenta(nuevo, vehiculo)) {
            System.out.println("Compra registrada exitosamente.");
        } else {
            System.out.println("No se pudo registrar la compra.");
        }
    }

    private void añadirInteresEnAuto(Cliente nuevo, Vehiculo vehiculo) {
        if (sistema.añadirInteres(nuevo, vehiculo)) {
            System.out.println("Interés registrado exitosamente.");
        } else {
            System.out.println("No se pudo registrar el interés.");
        }
    }

    private Cliente registro() {
        String cedula;
        do {
            System.out.println("Ingrese su cédula: ");
            cedula = Control.leerString("").trim();
        } while (!Control.validarCedula(cedula)); 

        Cliente clienteExistente = sistema.buscarCliente(cedula);

        if (clienteExistente != null) {
            return clienteExistente; 
        }

        String nombre, apellido, direccion, telefono;

        do {
            nombre = Control.leerString("Ingrese su nombre: ");
        } while (nombre.isEmpty() || !Control.esSoloLetras(nombre)); 

        do {
            apellido = Control.leerString("Ingrese su apellido: ");
        } while (apellido.isEmpty() || !Control.esSoloLetras(apellido)); 

        do {
            direccion = Control.leerString("Ingrese su dirección: ");
        } while (direccion.isEmpty());

        do {
            telefono = Control.leerString("Ingrese su teléfono: ");
        } while (telefono.isEmpty() || !Control.esNumero(telefono)); 

        return new Cliente(cedula, nombre, apellido, telefono, direccion);
    }

    private void mostrarClientesInteresados() {
        String opc = Control.leerString("Ingrese el tipo/marca de auto");
        sistema.mostrarInterasados(opc);
    }

    private void mostrarHistorialCliente(Cliente i) {
        sistema.mostrarHistorialCliente(i);
    }

    private void mostrarEstadisticas() {
        LocalDate inicio = Control.leerFecha("Ingrese una fecha de inicio (formato YYYY-MM-DD):");
        LocalDate fin = Control.leerFecha("Ingrese una fecha de fin (formato YYYY-MM-DD):");
        sistema.mostrarEstadisticasSistema(inicio, fin);
    }

    private void mostrarAutosDisponibles() {
        sistema.mostrarAutos();
    }

    private void filtrarYMostrarAutos() {
        System.out.println("Ingrese el tipo de auto (o deje en blanco para omitir):");
        String tipo = Control.leerString("").trim();

        System.out.println("Ingrese la marca de auto (o deje en blanco para omitir):");
        String marca = Control.leerString("").trim();

        System.out.println("Ingrese el año del auto (o deje en blanco para omitir):");
        String añoStr = Control.leerString("").trim();
        Integer año = null;
        if (!añoStr.isEmpty()) {
            try {
                año = Integer.parseInt(añoStr);
            } catch (NumberFormatException e) {
                System.out.println("Año inválido, no se aplicará filtro de año.");
            }
        }

        System.out.println("Ingrese el color del auto (o deje en blanco para omitir):");
        String color = Control.leerString("").trim();
        sistema.mostrarVehiculosFiltrados(
                tipo.isEmpty() ? null : tipo,
                marca.isEmpty() ? null : marca,
                año,
                color.isEmpty() ? null : color
        );
    }

    
}
