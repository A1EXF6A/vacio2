package Principal;

import java.io.*;
import java.time.LocalDate;
import java.util.LinkedList;

public class GestorDatos {

    public void cargarVehiculos(String archivo, LinkedList<Vehiculo> vehiculos) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(archivo));
        String line;
        
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            
            String[] data = line.split("\\|");
            if (data.length != 6) {
                System.out.println("Formato incorrecto en la línea: " + line);
                continue;
            }
            
            try {
                Vehiculo vehiculo = new Vehiculo(
                    data[0],  // tipo
                    data[1],  // marca
                    data[2],  // placa
                    data[3],  // color
                    Integer.parseInt(data[4]),
                    Integer.parseInt(data[5])// año
                );
                vehiculos.add(vehiculo);
            } catch (NumberFormatException e) {
                System.out.println("Error al convertir el año en la línea: " + line);
            }
        }
        reader.close();
    }

    public void cargarVentas(String archivo, LinkedList<Venta> ventas, LinkedList<Cliente> clientes, LinkedList<Vehiculo> vehiculos) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(archivo));
        String linea;
        while ((linea = reader.readLine()) != null) {
            String[] datos = linea.split("\\|");
            Cliente cliente = buscarClientePorCedula(datos[0], clientes);
            Vehiculo vehiculo = buscarVehiculoPorPlaca(datos[1], vehiculos);
            if (cliente != null && vehiculo != null) {
                Venta venta = new Venta(cliente, vehiculo, Float.parseFloat(datos[2]));
                ventas.add(venta);
            }
        }
        reader.close();
    }

    public void cargarIntereses(String archivo, LinkedList<Intereses> intereses, LinkedList<Cliente> clientes, LinkedList<Vehiculo> vehiculos) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(archivo));
        String linea;
        while ((linea = reader.readLine()) != null) {
            String[] datos = linea.split("\\|");
            Cliente cliente = buscarClientePorCedula(datos[0], clientes);
            Vehiculo vehiculo = buscarVehiculoPorPlaca(datos[1], vehiculos);
            if (cliente != null && vehiculo != null) {
                Intereses interes = new Intereses(cliente, vehiculo);
                intereses.add(interes);
            }
        }
        reader.close();
    }

    public void cargarClientes(String archivo, LinkedList<Cliente> clientes, LinkedList<Vehiculo> vehiculos) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(archivo));
        String linea;
        Cliente clienteActual = null;
        while ((linea = reader.readLine()) != null) {
            String[] datos = linea.split("\\|");

            if (datos[0].equals("COMPRA")) {
                Vehiculo vehiculo = buscarVehiculoPorPlaca(datos[1], vehiculos);
                if (vehiculo != null && clienteActual != null) {
                    Compra compra = new Compra(vehiculo, Float.parseFloat(datos[2]));
                    compra.fechaCompra = LocalDate.parse(datos[3]);
                    clienteActual.historial.add(compra);
                }
            } else {
                clienteActual = new Cliente(datos[0], datos[1], datos[2], datos[3], datos[4]);
                clientes.add(clienteActual);
            }
        }
        reader.close();
    }

    public void guardarClientes(String archivo, LinkedList<Cliente> clientes) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(archivo));
        for (Cliente cliente : clientes) {
            writer.write(cliente.getCedula() + "|" + cliente.getNombre() + "|" + cliente.getApellido() + "|" + cliente.getTelefono() + "|" + cliente.getDireccion());
            writer.newLine();

            for (Compra compra : cliente.historial) {
                writer.write("COMPRA|" + compra.vehiculo.getPlaca() + "|" + compra.precioCompra + "|" + compra.fechaCompra);
                writer.newLine();
            }
        }
        writer.close();
    }

    public void guardarVehiculos(String archivo, LinkedList<Vehiculo> vehiculos) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(archivo));
        for (Vehiculo vehiculo : vehiculos) {
            writer.write(vehiculo.getTipo() + "|" + vehiculo.getMarca() + "|" + vehiculo.getPlaca() + "|" + vehiculo.getColor() + "|" + vehiculo.getAño()+"|"+vehiculo.getStock());
            writer.newLine();
        }
        writer.close();
    }

    public void guardarVentas(String archivo, LinkedList<Venta> ventas) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(archivo));
        for (Venta venta : ventas) {
            writer.write(venta.getCliente().getCedula() + "|" + venta.getVehiculo().getPlaca() + "|" + venta.getPrecioVenta() + "|" + venta.getFechaVenta());
            writer.newLine();
        }
        writer.close();
    }

    public void guardarIntereses(String archivo, LinkedList<Intereses> intereses) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(archivo));
        for (Intereses interes : intereses) {
            writer.write(interes.getCliente().getCedula() + "|" + interes.getVehiculo().getPlaca() + "|" + interes.getFechaInteres());
            writer.newLine();
        }
        writer.close();
    }

    private Cliente buscarClientePorCedula(String cedula, LinkedList<Cliente> clientes) {
        for (Cliente cliente : clientes) {
            if (cliente.getCedula().equals(cedula)) {
                return cliente;
            }
        }
        return null;
    }

    private Vehiculo buscarVehiculoPorPlaca(String placa, LinkedList<Vehiculo> vehiculos) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getPlaca().equalsIgnoreCase(placa)) {
                return vehiculo;
            }
        }
        return null;
    }
}
