/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import java.io.IOException;

/**
 *
 * @author HOME
 */
public class Main {
    public static void main(String[] args) throws IOException {
        Interfaz inter = new Interfaz();
        inter.menu();
    }
}

