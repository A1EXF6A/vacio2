/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author HOME
 */
public class Compra {

    Vehiculo vehiculo;
    LocalDate fechaCompra;
    float precioCompra;

    public Compra(Vehiculo vehiculo, float precioCompra) {
        this.vehiculo = vehiculo;
        this.fechaCompra = LocalDate.now();
        this.precioCompra = precioCompra;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return String.format("| %-10s | %-10.2f  %s ",
                fechaCompra.format(formatter),
                precioCompra,
                vehiculo.toString());

    }}
