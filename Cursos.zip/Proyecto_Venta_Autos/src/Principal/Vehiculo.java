/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

/**
 *
 * @author HOME
 */
public class Vehiculo {
    String tipo;
    String marca;
    String placa;
    String color;
    int año;
    int stock;

    public Vehiculo(String tipo, String marca, String placa, String color, int año, int stock) {
        this.tipo = tipo;
        this.marca = marca;
        this.placa = placa;
        this.color = color;
        this.año = año;
        this.stock = stock;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPlaca() {
        return placa;
    }
    
    @Override
    public String toString() {
    return String.format("| %-10s | %-10s | %-10s | %-10s | %-10d |", tipo, marca, placa, color, año);
}

    public String getColor() {
        return color;
    }

    public int getAño() {
        return año;
    }
    
    public void reducirStock() {
        if (this.stock > 0) {
            this.stock--;
        }
        
    }

    public int getStock() {
        return stock;
    }
}
