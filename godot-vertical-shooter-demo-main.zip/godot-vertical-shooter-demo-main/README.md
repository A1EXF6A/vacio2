# Godot Vertical Shooter Demo

A basic demostration of a tactical shooter using Godot with C#

This is based on the great
tutorial ['How to make a Space Shooter Game in Godot'](https://www.youtube.com/watch?v=QoNukqpolS8) I recommend watching
that tutorial.

Sounds are from [Kenney.nl](https://kenney.nl/assets/space-shooter-redux)

You can access an updated list of differences between GDScript and
C# [here](https://docs.godotengine.org/en/stable/getting_started/scripting/c_sharp/c_sharp_differences.html)