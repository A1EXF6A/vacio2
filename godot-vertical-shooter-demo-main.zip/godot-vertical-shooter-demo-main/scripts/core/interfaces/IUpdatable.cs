using Godot;
public interface IUpdatable
{
	void UpdateLogic(double delta);
}
