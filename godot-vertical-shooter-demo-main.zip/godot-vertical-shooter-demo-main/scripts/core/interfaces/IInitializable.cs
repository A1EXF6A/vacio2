using Godot;
public interface IInitializable
{
	void Initialize();
}
