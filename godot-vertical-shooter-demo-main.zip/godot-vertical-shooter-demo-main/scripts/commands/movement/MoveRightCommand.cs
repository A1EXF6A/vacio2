using Godot;

public class MoveRightCommand : MoveCommand
{
	public MoveRightCommand(Player player) : base(player, Vector2.Right)
	{
	}
	
	public override void Execute()
	{
		base.Execute();
	}
}
