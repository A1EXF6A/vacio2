/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ed2424semana2lse;

/**
 *
 * @author Estudiante
 */
public class ED2424Semana2LSE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Estudiante e1 = new Estudiante("1843847567");
        e1.nombre = "Pedro";
        Lista estudiantes = new Lista();
        estudiantes.insertar(e1);
        estudiantes.insertar("1843847567");
        
        Estudiante e2 = new Estudiante("1843847567");
        
        Estudiante e = (Estudiante)estudiantes.buscar(e2);
        
        System.out.println(e.toString());
*/
        
        GestorCursos g = new GestorCursos();
        g.insertarCurso(new Curso("Estructura de Datos"));
        
    }
    
}
