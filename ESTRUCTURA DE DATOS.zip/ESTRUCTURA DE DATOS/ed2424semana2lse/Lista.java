/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ed2424semana2lse;

/**
 *
 * @author Estudiante
 */
public class Lista {

    Nodo primero;

    public Lista() {
        this.primero = null;
    }

    public boolean estáVacía() {
        return this.primero == null;
    }

    public boolean insertar(Object dato) {
        Nodo nuevo = null;
        try {
            nuevo = new Nodo(dato);
        } catch (Exception e) {
            return false; //No hay memoria para crear nuevo nodo.
        }
        if (this.estáVacía()) {
            this.primero = nuevo;
        } else {
            Nodo último = this.último();
            último.siguiente = nuevo;
        }
        return true;
    }

    public boolean insertarPorPrimero(Object dato) {
        Nodo nuevo = null;
        try {
            nuevo = new Nodo(dato);
        } catch (Exception e) {
            return false; //No hay memoria para crear nuevo nodo.
        }
        if (this.estáVacía())
            this.primero = nuevo;
        else{
            nuevo.siguiente = this.primero;
            this.primero = nuevo;
        }
        return true;
    }

    public boolean insertarPorPosición(Object dato, int pos){
        return false;
    }
    
    public boolean borrar(Object dato){
        if (this.estáVacía())
            return false;
        if (this.primero.dato.equals(dato)){
            this.primero = this.primero.siguiente;
            return true;
        }
        Nodo actual = this.primero;
        while (actual != null){
            if (actual.siguiente != null && actual.siguiente.dato.equals(dato)){
                actual.siguiente = actual.siguiente.siguiente;
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }
    
    private Nodo último() {
        if (this.estáVacía()) {
            return null;
        }
        Nodo último = this.primero;
        while (último.siguiente != null) {
            último = último.siguiente;
        }
        return último;
    }
    
    public Object buscar(Object o){
        if (this.estáVacía())
            return null;
        Nodo actual = this.primero;
        while (actual != null){
            if (actual.dato.equals(o))
                return actual.dato;
            actual = actual.siguiente;
        }
        return null;
    }
}
