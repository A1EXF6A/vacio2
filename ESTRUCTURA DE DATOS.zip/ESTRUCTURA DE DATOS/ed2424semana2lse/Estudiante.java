/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ed2424semana2lse;

/**
 *
 * @author Estudiante
 */
public class Estudiante {
    String ci;
    String nombre;
    
    public Estudiante(String ci){
        this.ci = ci;
    }
    
    /*
    @Override
    public boolean equals(Object o){
        if (o instanceof Estudiante)
            return this.ci.equals(((Estudiante)o).ci);
        return false;
    }
*/
    
    @Override
    public String toString(){
        return "Estudiante con ci: " + this.ci + " y nombre: " + this.nombre;
    }
}
