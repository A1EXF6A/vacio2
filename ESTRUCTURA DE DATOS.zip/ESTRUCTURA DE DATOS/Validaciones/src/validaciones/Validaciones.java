/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package validaciones;

/**
 *
 * @author User
 */
public class Validaciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Ejemplo de uso y validaciones
        String nombre = "ANTHONY";
        String apellido = "MENDEZ";
        String direccion = "AMBATO 123";
        String estado = "NO";
        String cedula = "1804985719"; 

        Validacion.validarNombreApellido(nombre);

        Validacion.validarNombreApellido(apellido);

        Validacion.validarDireccion(direccion);

        Validacion.validarEstado(estado);

        Validacion.validarCedula(cedula);

    }

}
