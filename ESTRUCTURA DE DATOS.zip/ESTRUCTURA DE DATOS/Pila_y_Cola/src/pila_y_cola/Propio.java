/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila_y_cola;

/**
 *
 * @author HOME
 */
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;

public class Propio {
    public static void main(String[] args) {
        
        Stack<Integer> pila = new Stack<>();

        
        pila.push(10);
        pila.push(20);
        pila.push(30);

        
        System.out.println("Elementos de la pila:");
        while (!pila.isEmpty()) {
            System.out.println(pila.pop());
        }

        
        Queue<String> cola = new LinkedList<>();

        
        cola.add("Uno");
        cola.add("Dos");
        cola.add("Tres");

        
        System.out.println("Elementos de la cola:");
        while (!cola.isEmpty()) {
            System.out.println(cola.poll());
        }
    }
}

