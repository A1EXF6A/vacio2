/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila_y_cola;

/**
 *
 * @author HOME
 */
public class NavegadorWeb {
    private Pila<String> historialAtras = new Pila<>(100);
    private Cola<String> historialAdelante = new Cola<>(100);
    private String paginaActual = "www.paginaInicial.com";

    public void navegar(String nuevaPagina) {
        historialAtras.push(paginaActual);
        paginaActual = nuevaPagina;
        historialAdelante.limpiar(); 
        System.out.println("Navegando a: " + paginaActual);
    }

    public void retroceder() {
        if (!historialAtras.estaVacia()) {
            historialAdelante.enqueue(paginaActual);
            paginaActual = historialAtras.pop();
            System.out.println("Retrocediendo a: " + paginaActual);
        } else {
            System.out.println("No hay más páginas para retroceder.");
        }
    }

    public void adelantar() {
        if (!historialAdelante.estaVacia()) {
            historialAtras.push(paginaActual);
            paginaActual = historialAdelante.dequeue();
            System.out.println("Adelantando a: " + paginaActual);
        } else {
            System.out.println("No hay más páginas para adelantar.");
        }
    }

    public String getPaginaActual() {
        return paginaActual;
    }
}