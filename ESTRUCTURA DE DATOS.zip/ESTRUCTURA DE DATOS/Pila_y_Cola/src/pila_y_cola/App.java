/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila_y_cola;

import java.util.Scanner;

/**
 *
 * @author HOME
 */
public class App {
   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        NavegadorWeb navegador = new NavegadorWeb();
        int opcion = 0;

        while (true) {
            System.out.println("\nMenú:");
            System.out.println("1. Navegar a una nueva página");
            System.out.println("2. Retroceder");
            System.out.println("3. Adelantar");
            System.out.println("4. Mostrar página actual");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            try{
                opcion = scanner.nextInt();
                scanner.nextLine();
            }catch(Exception e){
                
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese la URL de la nueva página: ");
                    String nuevaPagina = scanner.nextLine();
                    navegador.navegar(nuevaPagina);
                    break;
                case 2:
                    navegador.retroceder();
                    break;
                case 3:
                    navegador.adelantar();
                    break;
                case 4:
                    System.out.println("Página actual: " + navegador.getPaginaActual());
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
            }
        }
    }
} 
