/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila_y_cola;

/**
 *
 * @author User
 */
class Cola<T> {
    private Nodo<T> frente;
    private Nodo<T> fin;
    private int tamanoMaximo;
    private int tamanoActual;

    Cola(int tamanoMaximo) {
        this.tamanoMaximo = tamanoMaximo;
        this.tamanoActual = 0;
    }

    void enqueue(T dato) {
        if (!estaLlena()) {
            Nodo<T> nuevoNodo = new Nodo<>(dato);
            if (estaVacia()) {
                frente = nuevoNodo;
            } else {
                fin.siguiente = nuevoNodo;
            }
            fin = nuevoNodo;
            tamanoActual++;
        } else {
            System.out.println("La cola está llena.");
        }
    }

    T dequeue() {
        if (!estaVacia()) {
            T datoExtraido = frente.dato;
            frente = frente.siguiente;
            tamanoActual--;
            if (estaVacia()) {
                fin = null;
            }
            return datoExtraido;
        } else {
            System.out.println("La cola está vacía.");
            return null;
        }
    }

    boolean estaVacia() {
        return frente == null;
    }

    boolean estaLlena() {
        return tamanoActual == tamanoMaximo;
    }

    T frente() {
        if (!estaVacia()) {
            return frente.dato;
        } else {
            System.out.println("La cola está vacía.");
            return null;
        }
    }

    int tamano() {
        return tamanoActual;
    }

    int tamanoMaximo() {
        return tamanoMaximo;
    }
    void limpiar() {
        frente = null;
        fin = null;
        tamanoActual = 0;
    }
}