/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pila_y_cola;

/**
 *
 * @author User
 */
public class main {

   


    public static void main(String[] args) {
        Pila<Integer> pila = new Pila<>(5);

        pila.push(1);
        pila.push(2);
        pila.push(3);
        pila.push(4);
        pila.push(5);

        System.out.println("Tamaño máximo de la pila: " + pila.tamanoMaximo());

        System.out.println("Elementos extraídos de la pila:");
        while (!pila.estaVacia()) {
            System.out.println(pila.pop());
        }

        System.out.println("La pila está vacía: " + pila.estaVacia());

        Cola<Integer> cola = new Cola<>(5);

        cola.enqueue(1);
        cola.enqueue(2);
        cola.enqueue(3);
        cola.enqueue(4);
        cola.enqueue(5);

        System.out.println("Tamaño máximo de la cola: " + cola.tamanoMaximo());

        System.out.println("Elementos extraídos de la cola:");
        while (!cola.estaVacia()) {
            System.out.println(cola.dequeue());
        }

        System.out.println("La cola está vacía: " + cola.estaVacia());
    }
}
