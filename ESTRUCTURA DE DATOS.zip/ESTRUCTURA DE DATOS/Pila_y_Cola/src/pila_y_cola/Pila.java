/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila_y_cola;

/**
 *
 * @author User
 */
// Clase Pila que utiliza nodos enlazados
class Pila<T> {
    private Nodo<T> cima;
    private int tamanoMaximo;
    private int tamanoActual;

    Pila(int tamanoMaximo) {
        this.tamanoMaximo = tamanoMaximo;
        this.tamanoActual = 0;
    }

    void push(T dato) {
        if (!estaLlena()) {
            Nodo<T> nuevoNodo = new Nodo<>(dato);
            nuevoNodo.siguiente = cima;
            cima = nuevoNodo;
            tamanoActual++;
        } else {
            System.out.println("La pila está llena.");
        }
    }

    T pop() {
        if (!estaVacia()) {
            T datoExtraido = cima.dato;
            cima = cima.siguiente;
            tamanoActual--;
            return datoExtraido;
        } else {
            System.out.println("La pila está vacía.");
            return null;
        }
    }

    boolean estaVacia() {
        return cima == null;
    }

    boolean estaLlena() {
        return tamanoActual == tamanoMaximo;
    }

    void limpiar() {
        cima = null;
        tamanoActual = 0;
    }

    T cima() {
        if (!estaVacia()) {
            return cima.dato;
        } else {
            System.out.println("La pila está vacía.");
            return null;
        }
    }

    int tamano() {
        return tamanoActual;
    }

    int tamanoMaximo() {
        return tamanoMaximo;
    }
}
