
import java.text.ParseException;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.text.ParseException;
import java.util.Scanner;

public class Menu {

    GestorUnidadEducativa gue;
    Insertar insert;
    int opcion = 0;
    Scanner tecla = new Scanner(System.in);

    public Menu() {
        this.gue = new GestorUnidadEducativa();
        this.insert = new Insertar();
    }

    public GestorUnidadEducativa getGestorUnidadEducativa() {
        return this.gue;
    }

    public void Mostrar() throws ParseException {
        caratula();
        do {
            System.out.println("\n\t\t                 MENU DE OPCIONES");
            System.out.println("1. Registrar Estudiante");
            System.out.println("2. Inscribir estudiante a un curso");
            System.out.println("3. Registrar Docente");
            System.out.println("4. Crear un Curso");
            System.out.println("5. Reporte de Estudiantes y Profesores del Centro Educativo");
            System.out.println("6. Reporte de Estudiantes de un curso");
            System.out.println("7. Ordenar Curso por numero de inscritos");
            System.out.println("8. Salir");
            
            System.out.println("\nIngrese una opción:");
        // Aquí puedes agregar tu lógica para manejar la opción adicional después del menú
            opcion = tecla.nextInt();

            switch (opcion) {
                case 1:
                    this.gue.insertarObjeto(this.insert.insertarDatosEstudiante(this.gue.getEstudiantes()), this.gue.getEstudiantes());
                    break;
                case 2:
                    this.insert.insertarDatosMatrucEstu(gue);
                    break;
                case 3:
                    this.gue.insertarObjeto(this.insert.insertarDatosProfesor(this.gue.getProfesores()),
                            this.gue.getProfesores());
                    break;
                case 4:
                    this.gue.insertarObjeto(this.insert.insertarDatosCurso(this.gue), this.gue.getCursos());
                    break;
                case 5:
                    this.gue.mostrarEstudiantes();
                    this.gue.mostrarProfesores();
                    break;
                case 6:
                    this.gue.mostrarCursos();
                    break;
                case 7:
                    gue.ImprimirCursosOrdenados();
                    break;
                case 8:
                    System.out.println("GRACIAS POR USAR EL PROGRAMA");
                    break;
            }
        } while (opcion != 8);

        
    }

    public void caratula() {
        System.out.println("**************************************************************************");
        System.out.println("\t\t            Cento Educativo Gotitas del Saber");
        System.out.println("\t Sistemas de Registro y Matriculacion de Personal Educativo");
        System.out.println("**************************************************************************");

    }

}
