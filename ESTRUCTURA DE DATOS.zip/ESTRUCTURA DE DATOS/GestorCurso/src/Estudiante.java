
import java.time.LocalDate;


public class Estudiante extends Persona {
    
    private float promedioCalificaciones;
    private String direccion;
    private Curso cursos[];
    private final static int cantCursos = 5;

    public Estudiante(float promedioCalificaciones, String direccion, String cedula, String nombre1, String nombre2, String apellido1, String apellido2, LocalDate fechaNacimiento) {
        super(cedula, nombre1, nombre2, apellido1, apellido2, fechaNacimiento);
        this.promedioCalificaciones = promedioCalificaciones;
        this.direccion = direccion;
        this.cursos = new Curso[cantCursos];
    }

    public float getPromedioCalificaciones() {
        return promedioCalificaciones;
    }

    public void setPromedioCalificaciones(float promedioCalificaciones) {
        this.promedioCalificaciones = promedioCalificaciones;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Curso[] getCursos() {
        return cursos;
    }

    public void setCursos(Curso[] cursos) {
        this.cursos = cursos;
    }
    
    public boolean asignarCursoEstudiante (Curso c){
        for (int j = 0; j < getCursos().length; j++) {
            if (getCursos()[j] == null){
                getCursos()[j] = c;
                return true;
            }
            
        }
        return false;
    }
    @Override
    public String toString(){
        return super.toString() + "\nPromedio de Calificaciones = " + promedioCalificaciones + "\nDireccion = " + direccion;
    }
}
