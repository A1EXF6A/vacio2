
import java.text.ParseException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Principal {
    public static void main(String[] args) {
        try{
        new Menu().Mostrar();
        
    }catch (ParseException e){
            //System.out.println("Error al ejecutar el menu " + e.getMessage());
    }
}
}