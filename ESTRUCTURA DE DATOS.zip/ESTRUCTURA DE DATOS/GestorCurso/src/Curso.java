/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.util.Arrays;

class Curso implements Comparable<Curso> {

    private String nombre;
    private int cantHoras;
    private Estudiante estudiantes[];
    private Profesor profesor;
    private int codigo;

    public Curso(String nombre, int cantHoras, Profesor profesor, int codigo, int cupo) {
        this.nombre = nombre;
        this.cantHoras = cantHoras;
        this.profesor = profesor;
        this.codigo = codigo;
        this.estudiantes = new Estudiante[cupo];
    }

    public int getCodigo() {
        return this.codigo;
    }

    public int getCupo() {
        return this.estudiantes.length;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return " Codigo de Curso = " + this.codigo + "\n Nombre del Curso = " + this.nombre + "\n Cantidad de horas = " + this.cantHoras
                + "\n Profesor = " + this.profesor.nombreCompleto();
    }

    public int cantidadCuposDisponibles() {
        int cupolibre = 0;
        for (int i = 0; i < this.estudiantes.length; i++) {
            if (this.estudiantes[i] == null) {
                cupolibre++;
            }
        }
        return cupolibre;
    }

    @Override
    public int compareTo(Curso c) {
        if (c == null) {
            return 1;
        }
        return Integer.compare(this.cantidadCuposDisponibles(), c.cantidadCuposDisponibles());
    }

    public int escojercupo(boolean op) {
        int cupolibre = 0;
        for (int i = 0; i < this.estudiantes.length; i++) {
            if (this.estudiantes[i] == null) {
                cupolibre++;
            }
        }
        if (op) {
            return cupolibre;
        } else {
            return this.estudiantes.length - cupolibre;
        }
    }

    public int getCantHoras() {
        return this.cantHoras;
    }

    public void setCantHoras(int cantHoras) {
        this.cantHoras = cantHoras;
    }

    public Profesor getProfesor() {
        return this.profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Estudiante[] getEstudiantes() {
        return this.estudiantes;
    }

    public boolean matricularEstudianteCurso(Estudiante e) {
        if (e != null) {
            for (int i = 0; i < getEstudiantes().length; i++) {
                if (getEstudiantes()[i] == null) {
                    getEstudiantes()[i] = e;
                    return true;
                }
            }
        }
        return false;
    }
}

