/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Control_Validacion {
 public Persona buscarPorCedula(String cedula, Persona[] personas){
     for (Persona persona : personas){
     if (persona != null && persona.getCedula().equalsIgnoreCase(cedula)) {
         return persona;
     }
     }
     return null;
 }    
 public Profesor validarProf(String cedula, Profesor[] profesores){
     return (Profesor) buscarPorCedula(cedula, profesores);
 }
 
 public Estudiante validarEstud(String cedula, Estudiante[] estudiantes){
     return (Estudiante) buscarPorCedula(cedula, estudiantes);
     
 }
 public boolean comprobarEstudiante (String ced, Estudiante[] estudents){
     for (int i = 0; i < estudents.length; i++) {
         if (estudents[i] != null) {
             if (estudents[i].getCedula().equalsIgnoreCase(ced)) {
                 System.out.println("Ya existe un estudiante con esta cedula");
                 return false;
                 
             }
             
         }
         
     }
 return true;
 }
 
 public <T> boolean existeElemento(T[] elementos){
     for( T elemento : elementos){
         if (elemento != null) {
             return true;
             
         }
     }
     return false;
 }
 
 public boolean comprobarProfesor (String ced, Profesor[] profesores){
     for (int i = 0; i < profesores.length; i++) {
         if (profesores[i] != null) {
             if (profesores[i].getCedula().equalsIgnoreCase(ced)) {
                 System.out.println("Ya existe un profesor con esta cedula");
             return false;
             }
             
         }
     }
     return true;
 }
 
 public boolean existeCupos(Curso c){
     for (int i = 0; i < c.getEstudiantes().length; i++) {
         if (c.getEstudiantes()[i] == null) {
             return true;
             
         }
         
     }
     return false;
 }
 
}

