
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author User
 */
public class GestorUnidadEducativa {

    private static final int MAX_CANTIDAD = 100;
    private Estudiante[] estudiantes;
    private Profesor[] profesores;
    private Curso[] cursos;
    private Control_Validacion cv;

    public GestorUnidadEducativa() {
        this.estudiantes = new Estudiante[MAX_CANTIDAD];
        this.profesores = new Profesor[MAX_CANTIDAD];
        this.cursos = new Curso[MAX_CANTIDAD];
        this.cv = new Control_Validacion();
    }

    public Estudiante[] getEstudiantes() {
        return estudiantes;
    }

    public Profesor[] getProfesores() {
        return profesores;
    }

    public Curso[] getCursos() {
        return cursos;
    }

    public void mostrarEstudiantes() {
        if (cv.existeElemento(this.estudiantes)) {
            System.out.println("------------ESTUDIANTES-----------");
            for (Estudiante estudiante : this.estudiantes) {
                if (estudiante != null) {
                    System.out.println(estudiante.toString() + "\n");

                }
            }

        } else {
            System.out.println("NO EXISTEN ESTUDIANTES");
        }
    }

    public boolean exisProfesor() {
        for (int i = 0; i < this.profesores.length; i++) {
            if (this.profesores[i] != null) {
                return true;
            }

        }
        return false;
    }

    public void mostrarProfesores() {
        if (exisProfesor()) {
            System.out.println("---------------DOCENTES---------------");
            for (Profesor profesor : this.profesores) {
                if (profesor != null) {
                    System.out.println(profesor.toString() + "\n");
                }
            }
        } else {
            System.out.println("NO EXISTEN PROFESORES");
        }

    }

    public void mostrarCursos() {
        int posicion = this.cursosDisponibles();
        if ((posicion) >= 0) {
            if (this.cursos[posicion] != null) {
                System.out.println(this.cursos[posicion].toString());
                System.out.println(" Cupos Disponibles: " + this.cursos[posicion].escojercupo(true));
                System.out.println("Estudiantes registrados:");

                for (int i = 0; i < this.cursos[posicion].getEstudiantes().length; i++) {
                    if (this.cursos[posicion].getEstudiantes()[i] != null) {
                        System.out.println(i + "." + this.cursos[posicion].getEstudiantes()[i].nombreCompleto());

                    }

                }

            } else {
                System.out.println("CURSO NO ENCONTRADO");
            }

        } else {
            System.out.println("NO HAY CURSOS DISPONIBLES");
        }
    }

    public void ImprimirCursosOrdenados() {
        Arrays.sort(this.cursos, Comparator.nullsLast(Comparator.reverseOrder()));
        for (int i = 0; i < this.cursos.length; i++) {
            if (this.cursos[i] != null) {
                System.out.println(cursos[i].getNombre() + ": " + this.cursos[i].escojercupo(false));

            }

        }
    }

    public boolean insertarObjeto(Object objeto, Object[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] == null) {
                arreglo[i] = objeto;
                return true;

            }

        }
        return false;
    }

    public int cursosDisponibles() {
        Scanner tec = new Scanner(System.in);
        int opcion = -1;
        int conta = 0;
        Arrays.sort(this.cursos, Comparator.nullsLast(Comparator.naturalOrder()));
        for (int i = 0; i < this.cursos.length; i++) {
            if (this.cursos[i] != null) {
                conta++;

            }

        }
        if (conta > 0) {
            System.out.println("Escoja el codigo de los cursos disponibles");
            for (int i = 0; i < this.cursos.length; i++) {
                if (this.cursos[i] != null) {
                    System.out.println(this.cursos[i].getCodigo() + ". " + this.cursos[i].getNombre());
                }

            }
            opcion = tec.nextInt();
        }
        return opcion;
    }
    public boolean ingresoEstudiante (Curso c, Estudiante e){
        if (c != null && e != null) {
            for (int i = 0; i < c.getEstudiantes().length; i++) {
                if (c.getEstudiantes()[i] == null) {
                    for (int j = 0; j < e.getCursos().length; j++) {
                        if (e.getCursos()[j] == null) {
                            c.matricularEstudianteCurso(e);
                            e.asignarCursoEstudiante(c);
                            return true;
                            
                        }
                        
                    }
                    
                }
                
            }
            
        }
        return false;
    }
    public boolean asignarCursoProfesor (String ced, Curso c){
        for (int i = 0; i < this.profesores.length; i++) {
            if (profesores[i] != null) {
                if (profesores[i].getCedula().equalsIgnoreCase(ced)) {
                    for (int j = 0; j < profesores[i].getCursos().length; j++) {
                        
                        if (profesores[i].getCursos()[j] == null) {
                            profesores[i].asignarCurso(c);
                            return true;
                            
                        }else{
                            System.out.println("ESTE PROFESOR NO TIENE DISPONIBLE MAS CURSOS");
                        }
                    }
                    
                }
                
            }
            
            
        }
        return false;
    }
    public void ordenarCursoporInscrito(Curso cursos[]){
        Arrays.sort(cursos);
    }
}
