
import java.time.LocalDate;
import java.time.Period;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Persona {
    
    protected String cedula, nombre1, nombre2, apellido1, apellido2;
    protected LocalDate fechaNacimiento;

    public Persona(String cedula, String nombre1, String nombre2, String apellido1, String apellido2, LocalDate fechaNacimiento) {
        this.cedula = cedula;
        this.nombre1 = nombre1;
        this.nombre2 = nombre2;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    public String nombreCompleto(){
        return String.format("%s %s %s %s", nombre1, nombre2, apellido1, apellido2);
    }
    public int edad(){
        LocalDate fechaActual = LocalDate.now();
        Period periodo = Period.between(fechaNacimiento, fechaActual);
        return periodo.getYears();
    }
    @Override
    public String toString(){
        return String.format("cedula = %s\nNombre: %s\nEdad = %s", cedula, nombreCompleto(),edad());
    }
    
}
