
import java.time.LocalDate;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author User
 */
public class Profesor extends Trabajador {

    private int añosExperiencia;
    private Curso cursos[];
    private static final int CantidadMaxCursos = 4;

    public Curso[] getCursos() {
        return cursos;
    }

    public Profesor(int añosExperiencia, float salario, String cedula, String nombre1, String nombre2, String apellido1, String apellido2, LocalDate fechaNacimiento) {
        super(salario, cedula, nombre1, nombre2, apellido1, apellido2, fechaNacimiento);
        this.añosExperiencia = añosExperiencia;
        this.cursos = new Curso[CantidadMaxCursos];
    }

    public boolean asignarCurso(Curso c) {
        for (int j = 0; j < getCursos().length; j++) {
            if (getCursos()[j] == null) {
                getCursos()[j] = c;
                c.setProfesor(this);
                return true;

            }

        }
        return false;
    }

    @Override
    public String toString() {
        //return String.format("%Años de Experiencia: %d", super.toString(), añosExperiencia);
    return "hola";
    }

}
