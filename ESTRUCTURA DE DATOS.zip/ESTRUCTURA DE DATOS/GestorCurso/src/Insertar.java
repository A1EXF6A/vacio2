
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author User
 */
public class Insertar {

    private DateTimeFormatter formatoFecha;
    private Scanner tec;
    private Control_Validacion cv;
    private int cont;

    public Insertar() {
        this.formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        this.tec = new Scanner(System.in);
        this.cv = new Control_Validacion();
        this.cont = 0;
    }

    public Estudiante insertarDatosEstudiante(Estudiante estudiantes[]) {
        System.out.println("Ingrese cedula del estudiante");
        String cedula = tec.next();
        if (this.cv.comprobarEstudiante(cedula, estudiantes)) {
            System.out.println("Ingrese el primer nombre del Estudiante");
            String nombre1 = tec.next();
            System.out.println("Ingrese el segundo nombre del Estudiante");
            String nombre2 = tec.next();
            System.out.println("Ingrese el primer apellido del Estudiante");
            String apellido1 = tec.next();
            System.out.println("Ingrese el segundo apellido del Estudiante");
            String apellido2 = tec.next();
            System.out.println("Ingrese direccion");
            String direccion = tec.next();
            System.out.println("Ingrese la fecha de nacimiento (formato: 31/12/1999)");
            String fechaNacimiento = tec.next();
            LocalDate fecha = LocalDate.parse(fechaNacimiento, formatoFecha);
            float promedioAcademico = 0.0f;
            System.out.println("ESTUDIANTE REGISTRADO CON EXITO");
            return new Estudiante(promedioAcademico, direccion, cedula, nombre1, nombre2, apellido1, apellido2, fecha);

        } else {
            return null;
        }
    }

    public Curso insertarDatosCurso(GestorUnidadEducativa gue) {
        if (cv.existeElemento(gue.getProfesores())) {
            System.out.println("Ingrese el nombre del curso");
            String nombreCurso = tec.next();
            System.out.println("Ingrese cantidad total de horas del curso");
            int horasTotales = tec.nextInt();
            System.out.println("Cuantos cupos disponibles existen");
            int cupos = tec.nextInt();
            System.out.println("Ingrese cedula del profesor a cargo del curso");
            String cedulaProfesor = tec.next();
            Profesor profesor = cv.validarProf(cedulaProfesor, gue.getProfesores());
            if (profesor == null) {
                System.out.println("HUBO UN ERROR, VERIFICA LOS DATOS");
                return null;

            } else {
                Curso c = new Curso(nombreCurso, horasTotales, profesor, this.cont, cupos);
                if (gue.asignarCursoProfesor(cedulaProfesor, c)) {
                    this.cont++;
                    System.out.println("CURSO CREADO CON EXITO");
                    return c;

                } else {
                    return null;
                }
            }

        } else {
            System.out.println("NO EXISTEN PROFESORES PARA CREAR UN CURSO");
        }
        return null;
    }

    public Profesor insertarDatosProfesor(Profesor profesores[]){
        System.out.println("Ingrese su cedula");
        String cedulaProfesor = tec.next();
        if (this.cv.comprobarProfesor(cedulaProfesor, profesores)) {
            System.out.println("Ingrese el primer nombre");
            String nombre1 = tec.next();
            System.out.println("Ingrese el segundo nombre");
            String nombre2 = tec.next();
            System.out.println("Ingrese el primer apellido");
            String apellido1 = tec.next();
            System.out.println("Ingrese el segundo apellido");
            String apellido2 = tec.next();
            System.out.println("Ingrese la fecha de nacimiento (formato: 31/12/1999)");
            String fechaNacimiento = tec.next();
            LocalDate fecha = LocalDate.parse(fechaNacimiento, formatoFecha);
            System.out.println("Ingrese años de experiencia");
            int añosdeExperiencia = tec.nextInt();
            System.out.println("Ingrese el Salario");
            float salario = tec.nextInt();
            System.out.println("PROFESOR REGISTRADO CON EXITO");
            return new Profesor(añosdeExperiencia, salario, cedulaProfesor, nombre1, nombre2, apellido1, apellido2, fecha);

        } else {
            return null;
        }

    }

    public void insertarDatosMatrucEstu(GestorUnidadEducativa gue) {
        if (cv.existeElemento(gue.getEstudiantes())) {
            if (cv.existeElemento(gue.getCursos())) {
                int codCurso = gue.cursosDisponibles();
                for (Curso curso : gue.getCursos()) {
                    if (curso != null && curso.getCodigo() == codCurso) {
                        if (cv.existeCupos(curso)) {
                            System.out.println("Ingrese la cedula del estudiante");
                            String cedEstudiante = tec.next();
                            Estudiante estudiante = cv.validarEstud(cedEstudiante, gue.getEstudiantes());
                            if (estudiante != null && cv.comprobarEstudiante(cedEstudiante, curso.getEstudiantes())) {
                                if (gue.ingresoEstudiante(curso, estudiante)) {
                                    System.out.println("MATRICULADO CON EXITO");

                                } else {
                                    
                                        System.out.println("HUBO UN ERROR AL MATRICULAR");
                                        System.out.println("VERIFICA QUE TENGAS CUPOS PARA MATRICULA");
                                    }
                                   
                                }
                            }

                            break; //no es necesario mas iteraciones despues de que se encontro el curso
                        }

                    }

                } else {
                    System.out.println("NO EXISTEN CURSOS DISPONIBLES");
                    }

            } else {
                System.out.println("NO EXISTEN ALUMNOS DISPONIBLES");
            }

        }
    }
