
import java.time.LocalDate;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Trabajador extends Persona{
    
    protected float salario;

    public Trabajador(float salario, String cedula, String nombre1, String nombre2, String apellido1, String apellido2, LocalDate fechaNacimiento) {
        super(cedula, nombre1, nombre2, apellido1, apellido2, fechaNacimiento);
        this.salario = salario;
    }
    
    @Override
    public String toString(){
        return String.format("%s\nSalario = %.2f\n", super.toString(), salario);
    }
}
