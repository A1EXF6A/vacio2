package Clases;

import Proyecto.Estado;
import java.util.LinkedList;
import java.util.Scanner;

public class Consola {

    private CentroReparaciones centro;

    public Consola(CentroReparaciones centro) {
        this.centro = centro;
    }

    public void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("----- Menú de Centro de Reparaciones -----");
            System.out.println("1. Realizar una solicitud de reparación");
            System.out.println("2. Ver estado de todas las reparaciones");
            System.out.println("3. Ver el mejor cliente");
            System.out.println("4. Ver tiempo promedio de reparaciones");
            System.out.println("0. Salir");
            System.out.print("Ingrese su opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea después de leer el entero

            switch (opcion) {
                case 1:
                    realizarSolicitudReparacion();
                    break;
                case 2:
                    verEstadoReparaciones();
                    break;
                case 3:
                    verMejorCliente();
                    break;
                case 4:
                    verTiempoPromedioReparaciones();
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    System.exit(0);
                    break;
                case 5:
                    String cedula;
                    do {
                        cedula = ingreso("Cedula");
                    } while (!Validacion.validarCedula(cedula));
                    centro.ver(cedula);
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, elija una opción válida.");
            }
        } while (opcion != 0);
    }

    private void realizarSolicitudReparacion() {
        System.out.println("Bienvenido al centro xxxx\nIngrese sus datos personales:");
        String nombre, apellido, direccion, cedula, telefono;
        do {
            nombre = ingreso("nombre");
        } while (!Validacion.validarNombreApellido(nombre));
        do {
            apellido = ingreso("apellido");
        } while (!Validacion.validarNombreApellido(apellido));
        do {
            direccion = ingreso("direccion");
        } while (!Validacion.validarDireccion(direccion));
        do {
            cedula = ingreso("cedula");
        } while (!Validacion.validarCedula(cedula));
        do {
            telefono = ingreso("telefono");
        } while (!Validacion.validarTelefonoCelularEcuador(telefono));

        Cliente a = new Cliente(nombre, apellido, direccion, telefono, cedula);
        System.out.println("Ingrese los datos de su reparacion:");
        String reparacion = ingreso("reparacion");
        String estado = ingreso("estado");
        EstadoReparacion actual = new EstadoReparacion(estado);
        Reparacion b = new Reparacion(reparacion, actual, a);
        SolicitudReparaciones nueva = new SolicitudReparaciones(a, b);
        centro.agregarSolicitud(nueva);
        Thread estadoThread = new Thread(actual);
        estadoThread.start();
        centro.agregarCliente(a);
        centro.agregarReparacion(b);
    }

    private void verEstadoReparaciones() {
        System.out.println("Lista de todas las reparaciones del centro: ");
        for (int i = 0; i < centro.getReparaciones().size(); i++) {
            System.out.printf("%-10s %5s\n", centro.getReparaciones().get(i).nombre, centro.getReparaciones().get(i).getEstado().actual);
            centro.getReparaciones().get(i).terminada();
        }
    }

    private void verMejorCliente() {
        CentroReparaciones centroReparaciones = new CentroReparaciones();
        LinkedList<String> mejoresClientes = centro.obtenerMejoresClientes();
        centro.obtenerMejoresClientes();
        // Imprimir los nombres de los mejores clientes
        System.out.println("Los mejores clientes son: ");
        for (String nombre : mejoresClientes) {
            System.out.println("Nombre: " + nombre);
        }
    }

    private void verTiempoPromedioReparaciones() {

        long tiempoPromedio = centro.tiempoPromedioReparaciones();
        System.out.println("El tiempo promedio de reparaciones es: " + tiempoPromedio + " segundos");
    }

    public static void main(String[] args) {
        CentroReparaciones centro = new CentroReparaciones();
        Consola interfaz = new Consola(centro);
        interfaz.mostrarMenu();
    }

    public String ingreso(String a) {
        Scanner tec = new Scanner(System.in);
        System.out.printf("Ingrese su %s:", a);
        return tec.nextLine();
    }
}
