
package Clases;

/**
 *
 * @author ASUS
 */
import java.time.Duration;
import java.util.LinkedList;

public class CentroReparaciones {
    private LinkedList<Cliente> clientes;
    private LinkedList<Reparacion> reparaciones;

    public CentroReparaciones() {
        this.clientes = new LinkedList<>();
        this.reparaciones = new LinkedList<>();
    }

    public void agregarCliente(Cliente cliente) {
        if (cliente != null) {
            clientes.add(cliente);
        } else {
            System.out.println("Error: Intentando agregar un cliente nulo.");
        }
    }

    public void agregarReparacion(Reparacion reparacion) {
        reparaciones.add(reparacion);
    }

    // Método para marcar una reparación como completada
    public void reparacionCompletada(Reparacion reparacion) {
    reparacion.terminada(); // Esto marca la reparación como completada
    Cliente cliente = reparacion.getCliente();
    if (cliente != null) {
        cliente.solicitudTerminada(); // Esto incrementa el contador de reparaciones completadas para el cliente
    }
}


    public Cliente obtenerMejorCliente() {
    if (clientes.isEmpty()) {
        System.out.println("La lista de clientes está vacía.");
        return null;
    }

    Cliente mejorCliente = null;
    int maxReparaciones = 0;

    for (Cliente cliente : clientes) {
        int numReparaciones = cliente.getNumReparaciones();
        if (numReparaciones > maxReparaciones) {
            maxReparaciones = numReparaciones;
            mejorCliente = cliente;
        }
    }

    if (mejorCliente == null) {
        System.out.println("No se encontró ningún cliente con reparaciones.");
    } else {
        System.out.println("El mejor cliente encontrado es: " + mejorCliente.getNombre());
    }

    return mejorCliente;
}


    public int cantidadSolicitudesEstado(String estado) {
        int cantidad = 0;
        for (Reparacion reparacion : reparaciones) {
            if (reparacion.getEstado().getActual().equalsIgnoreCase(estado)) {
                cantidad++;
            }
        }
        return cantidad;
    }

    public long tiempoPromedioReparaciones() {
        long tiempoTotal = 0;
        int cantidad = 0;
        for (Reparacion reparacion : reparaciones) {
            if (reparacion.getFin() != null) {
                tiempoTotal += Duration.between(reparacion.getInicio(), reparacion.getFin()).getSeconds();
                cantidad++;
            }
        }
        return cantidad > 0 ? tiempoTotal / cantidad : 0;
    }

    public LinkedList<Cliente> getClientes() {
        return clientes;
    }

    public LinkedList<Reparacion> getReparaciones() {
        return reparaciones;
    }
}
