
package Clases;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Main {
    public static void main(String[] args) {
        // Crear el centro de reparaciones
        Scanner tec = new Scanner(System.in);
        CentroReparaciones centro = new CentroReparaciones();

        // Crear clientes
        Cliente cliente1 = new Cliente("Juan", "Pérez", "Calle 123", "123456789", "1234567890");
        Cliente cliente2 = new Cliente("María", "García", "Calle 456", "987654321", "0987654321");

        // Agregar clientes al centro de reparaciones
        centro.agregarCliente(cliente1);
        centro.agregarCliente(cliente2);

        // Crear reparaciones y solicitudes de reparación
        EstadoReparacion estado1 = new EstadoReparacion("mojado");
        EstadoReparacion estado2 = new EstadoReparacion("destruido");
        Reparacion reparacion1 = new Reparacion("Reparacion 1", estado1, cliente1);
        Reparacion reparacion2 = new Reparacion("Reparacion 2", estado2, cliente2);
        Reparacion reparacion3 = new Reparacion("Reparacion 3", estado1, cliente1); 
        SolicitudReparaciones solicitud1 = new SolicitudReparaciones(cliente1, reparacion1);
        SolicitudReparaciones solicitud2 = new SolicitudReparaciones(cliente2, reparacion2);
        SolicitudReparaciones solicitud3 = new SolicitudReparaciones(cliente1, reparacion3); 

        // Agregar reparaciones al centro de reparaciones
        centro.agregarReparacion(reparacion1);
        centro.agregarReparacion(reparacion2);
        centro.agregarReparacion(reparacion3); 
        Thread estadoThread = new Thread(estado1);
                    estadoThread.start();
                    Thread estadoThrea = new Thread(estado2);
                    estadoThrea.start();
        String g = "";
                    do {
                        
                        System.out.println(centro.getReparaciones().get(0).estado.actual);
                        System.out.println(centro.getReparaciones().get(1).estado.actual);
                        System.out.println(centro.getReparaciones().get(2).estado.actual);
                        System.out.println("Desea ver el estado de la reaparaciones");
                        g = tec.nextLine();
        } while (g.equals("s"));
        // Marcar reparaciones como completadas
        centro.reparacionCompletada(reparacion1);
        centro.reparacionCompletada(reparacion2);
        centro.reparacionCompletada(reparacion3); 

        // Calcular precio y tiempo de las solicitudes de reparación
        solicitud1.calcularPrecio();
        solicitud2.calcularPrecio();
        solicitud3.calcularPrecio();

        // Imprimir información
        System.out.println("Mejor cliente: ");
        centro.obtenerMejorCliente();
        System.out.println("Cantidad de solicitudes en estado 'solucionada': " + centro.cantidadSolicitudesEstado("solucionada"));
        System.out.println("Tiempo promedio de reparaciones: " + centro.tiempoPromedioReparaciones() + " segundos");
    }
}

