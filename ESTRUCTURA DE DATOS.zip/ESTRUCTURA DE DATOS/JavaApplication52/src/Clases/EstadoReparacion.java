
package Clases;

/**
 *
 * @author Anthony
 */
class EstadoReparacion implements Runnable {
    public String actual;
    public volatile boolean running;

    public EstadoReparacion(String actual) {
        this.actual = actual;
        this.running = true;
    }

    @Override
    public void run() {
        String[] posiblesEstados = {"mojado", "quemado", "roto"};
        String temp = actual;

        try {
            while (running) {
                actual = "ingresada";
                Thread.sleep(60000); // 1 minuto
                actual = "en revision";
                Thread.sleep(60000); // 1 minuto
                for (String posible : posiblesEstados) {
                    if (posible.equals(temp)) {
                        actual = "solucionada";
                        running = false;
                        return;
                    }
                }
                actual = "sin solucion";
                running = false;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getActual() {
        return actual;
    }
}
