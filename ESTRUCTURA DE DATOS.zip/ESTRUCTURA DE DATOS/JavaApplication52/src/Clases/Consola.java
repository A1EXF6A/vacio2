/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
import java.util.Scanner;

public class Consola {
    private CentroReparaciones centro;

    public Consola(CentroReparaciones centro) {
        this.centro = centro;
    }

    public void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("----- Menú de Centro de Reparaciones -----");
            System.out.println("1. Realizar una solicitud de reparación");
            System.out.println("2. Ver estado de todas las reparaciones");
            System.out.println("3. Ver el mejor cliente");
            System.out.println("4. Ver tiempo promedio de reparaciones");
            System.out.println("0. Salir");
            System.out.print("Ingrese su opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea después de leer el entero

            switch (opcion) {
                case 1:
                    realizarSolicitudReparacion();
                    break;
                case 2:
                    verEstadoReparaciones();
                    break;
                case 3:
                    verMejorCliente();
                    break;
                case 4:
                    verTiempoPromedioReparaciones();
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, elija una opción válida.");
            }
        } while (opcion != 0);
    }

    private void realizarSolicitudReparacion() {
        // Aquí puedes implementar la lógica para permitir al usuario ingresar los detalles de la solicitud
        // y luego agregarla al centro de reparaciones
    }

    private void verEstadoReparaciones() {
        // Aquí puedes obtener la lista de reparaciones del centro de reparaciones y mostrar su estado
    }

    private void verMejorCliente() {
        Cliente mejorCliente = centro.obtenerMejorCliente();
        if (mejorCliente != null) {
            System.out.println("El mejor cliente es: " + mejorCliente.getNombre() + " " + mejorCliente.getApellido());
        }
    }

    private void verTiempoPromedioReparaciones() {
        long tiempoPromedio = centro.tiempoPromedioReparaciones();
        System.out.println("El tiempo promedio de reparaciones es: " + tiempoPromedio + " segundos");
    }

    public static void main(String[] args) {
        CentroReparaciones centro = new CentroReparaciones();
        Consola interfaz = new Consola(centro);
        interfaz.mostrarMenu();
    }
}

