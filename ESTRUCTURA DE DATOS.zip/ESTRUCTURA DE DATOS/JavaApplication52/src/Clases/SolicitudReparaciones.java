
package Clases;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 *
 * @author Anthony
 */
class SolicitudReparaciones {
    private Cliente cliente;
    private LocalDateTime fechaIngreso;
    private LocalDateTime fechaFin;
    private Reparacion reparacion;
    private double precio;
    private long tiempo;

    public SolicitudReparaciones(Cliente cliente, Reparacion reparacion) {
        this.cliente = cliente;
        this.reparacion = reparacion;
        this.fechaIngreso = LocalDateTime.now();
        this.precio = 0;
        this.tiempo = 0;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public LocalDateTime getFechaIngreso() {
        return fechaIngreso;
    }

    public LocalDateTime getFechaFin() {
        return fechaFin;
    }

    public Reparacion getReparacion() {
        return reparacion;
    }

    public double getPrecio() {
        return precio;
    }

    public long getTiempo() {
        return tiempo;
    }

    public void calcularPrecio() {
        if (fechaIngreso != null && (reparacion.estado.getActual().equalsIgnoreCase("solucionada") || reparacion.estado.getActual().equalsIgnoreCase("sin solucion"))) {
            // Llama al método de reparacionCompletada desde la instancia de CentroReparaciones
            CentroReparaciones centroReparaciones = new CentroReparaciones();
            centroReparaciones.reparacionCompletada(reparacion); // Marcar la reparación como completada
            fechaFin = reparacion.getFin();
            Duration duracion = Duration.between(fechaIngreso, fechaFin);
            long minutos = duracion.toMinutes();
            precio = minutos * 0.5;
        }
    }
}
