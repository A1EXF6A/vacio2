package modelo;

import clases.Conexion;
import clases.Jugador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class jugadorDAO extends Conexion {

    private Connection con = getConexion();
    private PreparedStatement ps;
    private ResultSet rs;

    public boolean agregarJugador(String c) {
        String sql = "INSERT INTO jugador (ID, NOMBRE) VALUES (?, ?)";
        try {

            try ( PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, this.ultimoID());
                ps.setString(2, c);

                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return false;
    }

    public boolean modificarJugador(String nombre, int id) {

        String sql = "UPDATE jugador SET NOMBRE=? WHERE ID=?";
        try {

            ps = con.prepareStatement(sql);

            ps.setString(1, nombre);
            ps.setInt(2, id);
            if (ps.executeUpdate() > 0) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public List listarJugador() {

        String sql = "SELECT * FROM jugador";
        List<Jugador> lista = new ArrayList<>();

        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Jugador pro = new Jugador();
                pro.setId(rs.getInt(1));
                pro.setNombre(rs.getString(2));
                pro.setTiempo(rs.getDouble(3));
                pro.setAciertos(rs.getDouble(4));
                pro.setDesaciertos(rs.getDouble(5));
                pro.setPuntosAcierto(rs.getDouble(6));
                pro.setPuntosDesacierto(rs.getDouble(7));
                pro.setPuntosTiempo(rs.getDouble(8));
                pro.setPuntuacion(rs.getDouble(9));
                lista.add(pro);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return lista;
    }

    public int existeUsuario(String cedula) {

        String consulta = "SELECT COUNT(ID) FROM jugador WHERE NOMBRE=?";
        try {
            ps = con.prepareStatement(consulta);

            ps.setString(1, cedula);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }
            return 1;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return 1;
        }
    }

    public int cantidadJugadores() {

        String consulta = "SELECT COUNT(ID) FROM jugador";
        try {
            ps = con.prepareStatement(consulta);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }
            return -1;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return -1;
        }

    }

    public int ultimoID() {

        String consulta = "SELECT MAX(ID) FROM jugador";
        try {
            ps = con.prepareStatement(consulta);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) + 1;
            }
            return -1;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return -1;
        }
    }

    public boolean actualizarTiempo(int id, double tiempo, double puntoTiempo) {
        String sql = "UPDATE jugador SET TIEMPO=?, PUNTOS_TIEMPO=? WHERE ID=?";
        try {

            ps = con.prepareStatement(sql);
            ps.setDouble(1, tiempo);
            ps.setDouble(2, puntoTiempo);
            ps.setInt(3, id);
            if (ps.executeUpdate() > 0) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public boolean actualizarAciertoDesacierto(int id, double acierto, double desacierto) {
        String sql = "UPDATE jugador SET ACIERTOS=?, DESACIERTOS=? WHERE ID=?";
        try {

            ps = con.prepareStatement(sql);
            ps.setDouble(1, acierto);
            ps.setDouble(2, desacierto);
            ps.setInt(3, id);
            if (ps.executeUpdate() > 0) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public List listarJugadorPodio() {

        String sql = "SELECT ROW_NUMBER() OVER (ORDER BY PUNTUACION DESC), NOMBRE, TIEMPO, ACIERTOS, DESACIERTOS, "
                + "PUNTOS_ACI, PUNTOS_DES, PUNTOS_TIEMPO, PUNTUACION FROM jugador ORDER BY PUNTUACION DESC";
        List<Jugador> lista = new ArrayList<>();

        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Jugador pro = new Jugador();
                pro.setId(rs.getInt(1));
                pro.setNombre(rs.getString(2));
                pro.setTiempo(rs.getDouble(3));
                pro.setAciertos(rs.getDouble(4));
                pro.setDesaciertos(rs.getDouble(5));
                pro.setPuntosAcierto(rs.getDouble(6));
                pro.setPuntosDesacierto(rs.getDouble(7));
                pro.setPuntosTiempo(rs.getDouble(8));
                pro.setPuntuacion(rs.getDouble(9));
                lista.add(pro);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return lista;
    }

    public boolean resetearJugadores() {
        String sql = "DELETE FROM jugador WHERE ID>2";
        try {
            ps = con.prepareStatement(sql);
            if (ps.executeUpdate() > 0) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public boolean jugarDeNuevo() {
        String sql = "UPDATE jugador SET ACIERTOS=0, DESACIERTOS=0, TIEMPO=0, PUNTOS_ACI=0, PUNTOS_DES=0, PUNTOS_TIEMPO=0, PUNTUACION=0";
        try {

            ps = con.prepareStatement(sql);
            if (ps.executeUpdate() > 0) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

}
