
package clases;

import java.util.ArrayList;

public class Juego {
    
    private ArrayList<Jugador> jugadores;
    private int dificultad;
    private String palabra;
}
