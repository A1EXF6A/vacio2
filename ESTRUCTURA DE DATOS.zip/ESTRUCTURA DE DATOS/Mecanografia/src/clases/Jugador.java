
package clases;


public class Jugador {
    
    private int id;
    private String nombre;
    private double tiempo;
    private double aciertos;
    private double desaciertos;
    private double puntosAcierto;
    private double puntosDesacierto;
    private double puntosTiempo;
    private double puntuacion;

    public Jugador() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(double puntuacion) {
        this.puntuacion = puntuacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public double getTiempo() {
        return tiempo;
    }

    public void setTiempo(double tiempo) {
        this.tiempo = tiempo;
    }

    public double getAciertos() {
        return aciertos;
    }

    public void setAciertos(double aciertos) {
        this.aciertos = aciertos;
    }

    public double getDesaciertos() {
        return desaciertos;
    }

    public void setDesaciertos(double desaciertos) {
        this.desaciertos = desaciertos;
    }

    public double getPuntosAcierto() {
        return puntosAcierto;
    }

    public void setPuntosAcierto(double puntosAcierto) {
        this.puntosAcierto = puntosAcierto;
    }

    public double getPuntosDesacierto() {
        return puntosDesacierto;
    }

    public void setPuntosDesacierto(double puntosDesacierto) {
        this.puntosDesacierto = puntosDesacierto;
    }

    public double getPuntosTiempo() {
        return puntosTiempo;
    }

    public void setPuntosTiempo(double puntosTiempo) {
        this.puntosTiempo = puntosTiempo;
    }


    
    
}
