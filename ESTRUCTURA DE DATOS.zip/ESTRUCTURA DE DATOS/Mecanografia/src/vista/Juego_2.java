package vista;

import clases.Jugador;
import java.awt.Color;
import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JPanel;
import modelo.jugadorDAO;

/**
 *
 * @author PC
 */
public class Juego_2 extends javax.swing.JFrame {

    private final String combinacion1 = "qwertasdfzxcv";
    private final String combinacion2 = "yuiopghjklbnm";
    Random random = new Random();

    private int aciertos;
    private int desaciertos;
    private int posicion = 0;
    private int contadorTurno;

    private int cantidadJugadores;

    private jugadorDAO jd = new jugadorDAO();
    private List<Jugador> lr;

    private long tiempoAnterior = 0;

    private String texto = "";

    public Juego_2() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setFocusable(true);
        //puntuacion = 1;
        aciertos = 0;
        desaciertos = 0;
        contadorTurno = 1;
        cantidadJugadores = jd.cantidadJugadores();
        lr = jd.listarJugador();
        this.lblPLayer.setText(lr.get(0).getNombre());
        this.lblTurno.setVisible(false);
    }

    private static String generarCombinacionAleatoria(String cadena, Random random) {

        StringBuilder combinacion = new StringBuilder();
        for (int j = 0; j < Dificultad_.dificultad + 1; j++) {
            int indiceAleatorio = random.nextInt(cadena.length());
            char letraAleatoria = cadena.charAt(indiceAleatorio);
            combinacion.append(letraAleatoria);
        }
        return combinacion.toString();
    }

    private String fraseAMostrar(String comb) {
        String palabra = "";
        for (int i = 0; i < 8; i++) {
            String combinacion = generarCombinacionAleatoria(comb, random);
            palabra += combinacion + " ";
        }
        return palabra.substring(0, palabra.length() - 1).toUpperCase();

    }

    private void configuracionColoresAzul() {
        lblPLayer.setText(lr.get(contadorTurno).getNombre());
        panelPlayer.setBackground(new Color(51, 51, 255));
        lblPLayer.setBackground(new Color(51, 51, 255));
        lblOutPutText.setBackground(new Color(0, 0, 255));
    }

    private void configuracionColoresMorado() {
        lblPLayer.setText(lr.get(contadorTurno).getNombre());
        panelPlayer.setBackground(new Color(204, 0, 255));
        lblPLayer.setBackground(new Color(153, 0, 153));
        lblOutPutText.setBackground(new Color(204, 0, 255));
    }

    private void enviarTiempos(double tiempo) {
        switch (Dificultad_.dificultad) {
            case 1 -> {
                double puntoTiempo = (12 - tiempo) * 5;
                calcularTiempo(tiempo, puntoTiempo);
            }
            case 2 -> {
                double puntoTiempo = (15 - tiempo) * 5;
                calcularTiempo(tiempo, puntoTiempo);
            }
            case 3 -> {
                double puntoTiempo = (20 - tiempo) * 5;
                calcularTiempo(tiempo, puntoTiempo);
            }

            default ->
                System.out.println("algun error :V");
        }
    }

    private void calcularTiempo(double tiempo, double puntoTiempo) {

        if (puntoTiempo > 0) {
            jd.actualizarTiempo(contadorTurno - 1, tiempo, puntoTiempo);
        } else {
            jd.actualizarTiempo(contadorTurno - 1, tiempo, 0);
        }
    }

    private void reiniciar() {

        if (contadorTurno == cantidadJugadores) {
            contadorTurno += 1;
            this.botonEmpezar.setText("FINALIZAR");
            this.botonEmpezar.setVisible(true);
            System.out.println("aciertos: " + aciertos);
            System.out.println("desaciertos: " + desaciertos);
            jd.actualizarAciertoDesacierto(contadorTurno - 1, aciertos, desaciertos);// actualiza el score
            texto = "";
        } else {
            this.botonEmpezar.setVisible(true);
            if (Integer.parseInt(this.lblTurno.getText()) % 2 == 0) {
                configuracionColoresMorado();
            } else {
                configuracionColoresAzul();
            }
            System.out.println("aciertos: " + aciertos);
            System.out.println("desaciertos: " + desaciertos);
            posicion = 0;
            this.lblOutPutText.setText("");
            this.lblTexto.setText("");
            jd.actualizarAciertoDesacierto(contadorTurno, aciertos, desaciertos);
            contadorTurno += 1;
            this.lblTurno.setText(String.valueOf(contadorTurno));
            aciertos = 0;
            desaciertos = 0;
            texto = "";
            this.lblScore.setText("00");
            this.lblDesaciertos.setText("00");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel49 = new javax.swing.JPanel();
        panelPlayer = new javax.swing.JPanel();
        lblPLayer = new javax.swing.JLabel();
        lblOutPutText = new javax.swing.JLabel();
        lblScore = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        lblDesaciertos = new javax.swing.JLabel();
        lblTexto = new javax.swing.JLabel();
        botonEmpezar = new javax.swing.JButton();
        lblTurno = new javax.swing.JLabel();
        botonRegresar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));
        setName("frame"); // NOI18N
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });

        jPanel49.setBackground(new java.awt.Color(255, 255, 255));
        jPanel49.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelPlayer.setBackground(new java.awt.Color(204, 0, 255));
        panelPlayer.setForeground(new java.awt.Color(255, 255, 255));

        lblPLayer.setBackground(new java.awt.Color(153, 0, 153));
        lblPLayer.setFont(new java.awt.Font("Consolas", 1, 20)); // NOI18N
        lblPLayer.setForeground(new java.awt.Color(255, 255, 255));
        lblPLayer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPLayer.setText("PLAYER 1");
        lblPLayer.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout panelPlayerLayout = new javax.swing.GroupLayout(panelPlayer);
        panelPlayer.setLayout(panelPlayerLayout);
        panelPlayerLayout.setHorizontalGroup(
            panelPlayerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblPLayer, javax.swing.GroupLayout.DEFAULT_SIZE, 710, Short.MAX_VALUE)
        );
        panelPlayerLayout.setVerticalGroup(
            panelPlayerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblPLayer, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel49.add(panelPlayer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        lblOutPutText.setBackground(new java.awt.Color(153, 0, 153));
        lblOutPutText.setFont(new java.awt.Font("Corbel", 1, 20)); // NOI18N
        lblOutPutText.setForeground(new java.awt.Color(0, 0, 0));
        lblOutPutText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOutPutText.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel49.add(lblOutPutText, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 690, 41));

        lblScore.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        lblScore.setForeground(new java.awt.Color(0, 0, 0));
        lblScore.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblScore.setText("00");
        jPanel49.add(lblScore, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, 80, 30));

        jLabel32.setFont(new java.awt.Font("Corbel", 1, 16)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(0, 0, 0));
        jLabel32.setText("ACIERTOS :");
        jPanel49.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 90, 30));

        jLabel35.setFont(new java.awt.Font("Corbel", 1, 16)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(0, 0, 0));
        jLabel35.setText("DESACIERTOS :");
        jPanel49.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 120, 30));

        jLabel36.setFont(new java.awt.Font("Corbel", 1, 16)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 0, 0));
        jLabel36.setText("ESCRIBE! :");
        jPanel49.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 100, 30));

        lblDesaciertos.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        lblDesaciertos.setForeground(new java.awt.Color(0, 0, 0));
        lblDesaciertos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDesaciertos.setText("00");
        jPanel49.add(lblDesaciertos, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 150, 80, 30));

        lblTexto.setBackground(new java.awt.Color(0, 0, 0));
        lblTexto.setFont(new java.awt.Font("Corbel", 1, 20)); // NOI18N
        lblTexto.setForeground(new java.awt.Color(0, 0, 0));
        lblTexto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTexto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel49.add(lblTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 690, 41));

        botonEmpezar.setBackground(new java.awt.Color(204, 255, 255));
        botonEmpezar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        botonEmpezar.setForeground(new java.awt.Color(0, 0, 0));
        botonEmpezar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/play_48_azul.png"))); // NOI18N
        botonEmpezar.setText("EMPEZAR");
        botonEmpezar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonEmpezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEmpezarActionPerformed(evt);
            }
        });

        lblTurno.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        lblTurno.setForeground(new java.awt.Color(204, 0, 255));
        lblTurno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurno.setText("1");

        botonRegresar.setBackground(new java.awt.Color(204, 255, 255));
        botonRegresar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        botonRegresar.setForeground(new java.awt.Color(0, 0, 0));
        botonRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/inicio_48.png"))); // NOI18N
        botonRegresar.setText("REGRESAR");
        botonRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(botonRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(169, 169, 169)
                .addComponent(botonEmpezar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(179, 179, 179))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addComponent(lblTurno, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jPanel49, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel49, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTurno, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonEmpezar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonEmpezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEmpezarActionPerformed

        this.botonRegresar.setVisible(false);
        long tiempoActual = System.currentTimeMillis();
        if (tiempoAnterior != 0) {
            long tiempoTranscurrido = tiempoActual - tiempoAnterior;
            double segundosTranscurridos = tiempoTranscurrido / 1000.0;
            System.out.println(segundosTranscurridos);
            enviarTiempos(segundosTranscurridos);
        }
        tiempoAnterior = tiempoActual;

        if (!this.botonEmpezar.getText().equals("FINALIZAR")) {
            if (Integer.parseInt(this.lblTurno.getText()) % 2 == 0) {
                this.lblOutPutText.setText(fraseAMostrar(combinacion2));
            } else {
                this.lblOutPutText.setText(fraseAMostrar(combinacion1));
            }
            this.botonEmpezar.setVisible(false);

        } else {
            Podio i = new Podio();
            i.setVisible(true);
            this.dispose();
        }

    }//GEN-LAST:event_botonEmpezarActionPerformed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed

        char ch = evt.getKeyChar();
        if (!this.botonEmpezar.getText().equals("FINALIZAR")) {
            if ((Character.toLowerCase(ch) >= 'a' && Character.toLowerCase(ch) <= 'z') || ch == ' ') {
                texto += ch;
                if (!this.lblOutPutText.getText().isEmpty()) {
                    if (posicion < lblOutPutText.getText().length()
                            && String.valueOf(ch).toLowerCase().equals(String.valueOf(lblOutPutText.getText().charAt(posicion)).toLowerCase())) {
                        this.lblTexto.setText(texto.toUpperCase());
                        aciertos += 1;
                        posicion++;
                        this.lblScore.setText(String.valueOf(aciertos));
                        if (posicion == lblOutPutText.getText().length()) {
                            reiniciar();
                        }
                    } else {
                        this.lblTexto.setText(texto.toUpperCase());
                        posicion++;
                        desaciertos += 1;
                        this.lblDesaciertos.setText("" + desaciertos);
                        if (posicion == (lblOutPutText.getText().length() - 1)) {
                            reiniciar();
                        }

                    }
                }
            }
        }


    }//GEN-LAST:event_formKeyPressed

    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_formKeyReleased

    private void botonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegresarActionPerformed
        Dificultad_ d = new Dificultad_();
        d.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonRegresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Juego_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Juego_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Juego_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Juego_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Juego_2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonEmpezar;
    private javax.swing.JButton botonRegresar;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JLabel lblDesaciertos;
    private javax.swing.JLabel lblOutPutText;
    private javax.swing.JLabel lblPLayer;
    private javax.swing.JLabel lblScore;
    private javax.swing.JLabel lblTexto;
    private javax.swing.JLabel lblTurno;
    private javax.swing.JPanel panelPlayer;
    // End of variables declaration//GEN-END:variables
}
