/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana12;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author HOME
 */
public class Vertice {
  

    public Object ponderacion;
    ArrayList<Arco> arcoSaliente;

    public Vertice(Object ponderacion) {
        this.ponderacion = ponderacion;
        this.arcoSaliente = new ArrayList<>();

    }

    public Vertice(Object ponderacion, ArrayList<Arco> arcoSaliente) {
        this.ponderacion = ponderacion;
        this.arcoSaliente = arcoSaliente;

    }

    @Override
    public boolean equals(Object dato) {
        if (!(dato instanceof Vertice)) {
            return false;
        }
        Vertice vertice = (Vertice) dato;
        return this.ponderacion.equals(vertice.ponderacion);

    }

    public boolean buscarAdyacente(Vertice b) {
        for (Arco arco : this.arcoSaliente) {
            if (arco.destino.equals(b)) {
                return true;
            }
        }
        return false;
    }
      public void borrarArcoSalida(Vertice b) {
        this.arcoSaliente.remove(b);
    }
      ///////////
    LinkedList<Vertice> adyacentes() {
        LinkedList<Vertice> adyacentes = new LinkedList<>();
        for(Arco a: this.arcoSaliente) {
            if(adyacentes.contains(a.destino))
                adyacentes.add(a.destino);
        }
        return adyacentes;
    }

}