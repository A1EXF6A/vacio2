/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana12;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author HOME
 */
public class Grafo {
  

    ArrayList<Vertice> vertice;
    ArrayList<Arco> arco;

    public Grafo() {
        this.vertice = new ArrayList();
        this.arco = new ArrayList();
    }
    
    public boolean arcoVacio() {
        return this.arco.isEmpty();

    }
    public boolean sonAdyacentes(Vertice v1, Vertice v2) {
        if(v1==null||v2==null)
            return false;
        for (Arco arco : v1.arcoSaliente) {
            if (arco.destino.equals(v2)) {
                return true;
            }
        }
        for (Arco arc : v2.arcoSaliente) {
            if (arc.destino.equals(v1)) {
                return true;
            }
        }

        return false;

    }

    
    
    public LinkedList<Vertice> adyacentes(Object p){
        Vertice v = this.buscarVertice(p);
        if(v==null){
            return null;
        }
        return v.adyacentes();
    }
    
    public Vertice buscarVertice(Object ponderacion) {
        for (Vertice vertice : vertice) {
            if (vertice.ponderacion.equals(ponderacion)) {
                return vertice;
            }
        }
        return null;
    }
    
    public boolean determinarAdyacente(Object origen, Object destino) {
        Vertice v1 = this.buscarVertice(origen);
        Vertice v2 = this.buscarVertice(destino);
        
        boolean sonAyacentes = sonAdyacentes(v1,v2);
        if(!sonAyacentes)
            return sonAdyacentes(v2,v1);
        return true;
    }
 
    public boolean añadirVertice(Object p){
        if(this.buscarVertice(p)!=null)
            return false;
        return this.vertice.add(new Vertice(p));
    }
    
    public boolean añadirVertice(Object pO,Object pD,Object p){
        Vertice origen = this.buscarVertice(pO);
        Vertice destino = this.buscarVertice(pO);
        if(origen==null||destino==null)
            return false;
        this.arco.add(new Arco(origen,destino,p));
        return true;
        
    }
    public boolean borrarArco(Object pond, Object pondOrigen, Object pondDestino) {
        Vertice origen = this.buscarVertice(pondOrigen);
        Vertice destino = this.buscarVertice(pondDestino);
        if (origen == null || destino == null)
            return false;
        Arco arcoAEliminar = null;
        for (Arco arco : arco) {
            if (arco.ponderacion.equals(pond) && arco.origen.equals(origen) && arco.destino.equals(destino)) {
                arcoAEliminar = arco;
                break;
            }
        }
        if (arcoAEliminar != null) {
            arco.remove(arcoAEliminar);
            origen.arcoSaliente.remove(arcoAEliminar);
            return true;
        }
        return false;
    }
    /*
    public boolean borrarVertice(Object p){
        Vertice a = buscarVertice(p);
        
        if(vertice.contains(a)){
           vertice.remove(a);
        }
        LinkedList<Arco> c = new LinkedList<>();
        for(Arco b: arco){
            if(b.destino.arcoSaliente.contains()){
                b.destino = null;
            }
            if(b.origen.equals(v))
        }
        
        
        return false;
    }*/
    
    
}
