package Semana14;

import java.util.LinkedList;

public class Grafo {

    Object[] vertices;
    Object[][] arcos;
    int cantidadVertices;

    public Grafo(int dim) {
        this.vertices = new Object[dim];
        this.arcos = new Object[dim][dim];
        this.cantidadVertices = 0;
    }

    public boolean estaVacio() {
        return this.cantidadVertices == 0;
    }

    public boolean insertarVertice(Object ponderacion) {
        if (cantidadVertices >= vertices.length) {
            return false; // No se pueden insertar más vértices
        }
        if (buscarVertice(ponderacion)) {
            return false; // El vértice ya existe
        }
        vertices[cantidadVertices] = ponderacion;
        cantidadVertices++;
        return true;
    }

    public boolean buscarVertice(Object a) {
        if (estaVacio()) {
            return false;
        }
        for (Object b : vertices) {
            if (b != null && b.equals(a)) {
                return true;
            }
        }
        return false;
    }

    public boolean insertarArco(Object origen, Object destino, Object ponderacion) {
        int origenIndex = -1, destinoIndex = -1;
        for (int i = 0; i < cantidadVertices; i++) {
            if (vertices[i].equals(origen)) {
                origenIndex = i;
            }
            if (vertices[i].equals(destino)) {
                destinoIndex = i;
            }
        }

        if (origenIndex == -1 || destinoIndex == -1) {
            return false; // No se encontró el origen o destino
        }

        arcos[origenIndex][destinoIndex] = ponderacion;
        return true;
    }

    public boolean eliminarArco(Object origen, Object destino) {
        int origenIndex = -1, destinoIndex = -1;
        for (int i = 0; i < cantidadVertices; i++) {
            if (vertices[i].equals(origen)) {
                origenIndex = i;
            }
            if (vertices[i].equals(destino)) {
                destinoIndex = i;
            }
        }

        if (origenIndex == -1 || destinoIndex == -1) {
            return false; // No se encontró el origen o destino
        }

        arcos[origenIndex][destinoIndex] = null;
        return true;
    }
    
    public boolean eliminarVertice(Object p) {
        if (estaVacio()) {
            return false;
        }
        for (int i = 0; i < cantidadVertices; i++) {
            if (vertices[i].equals(p)) {
                vertices[i] = null;
                for (int j = 0; j < cantidadVertices; j++) {
                    arcos[i][j] = null; 
                    arcos[j][i] = null;
                }
                for (int j = i; j < cantidadVertices - 1; j++) {
                    vertices[j] = vertices[j + 1];
                }
                vertices[cantidadVertices - 1] = null;
                cantidadVertices--;
                return true;
            }
        }
        return false;
    }

    public boolean VerticesAdyacentes(Object a, Object b) {
        int indexA = -1, indexB = -1;
        for (int i = 0; i < cantidadVertices; i++) {
            if (vertices[i].equals(a)) {
                indexA = i;
            }
            if (vertices[i].equals(b)) {
                indexB = i;
            }
        }

        if (indexA == -1 || indexB == -1) {
            return false; 
        }

        return arcos[indexA][indexB] != null;
    }
    
    public LinkedList<Object> adyacentesVertices(Object a) {
        LinkedList<Object> adyacentes = new LinkedList<>();
        if (a == null) return null;

        int indexA = -1;
        for (int i = 0; i < cantidadVertices; i++) {
            if (vertices[i]==a) {
                indexA = i;
                break;
            }
        }

        if (indexA == -1) {
            return null; 
        }

        for (int j = 0; j < cantidadVertices; j++) {
            if (arcos[indexA][j] != null) {
                adyacentes.add(vertices[j]);
            }
        }

        return adyacentes;
    }
}
