/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana14;

/**
 *
 * @author HOME
 */
public class Main {
    public static void main(String[] args) {
        Grafo a = new Grafo(10);
        //a.insertarVertice("10");
        String d = "10";
        System.out.println(a.insertarVertice(d));
        System.out.println(a.insertarVertice(d));
        System.out.println(a.insertarVertice(d));
        
        System.out.println("//////////");
        System.out.println(a.buscarVertice(d));
        
    }
}
