/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana5;

/**
 *
 * @author HOME
 */
public class NodoDoble<T extends Comparable<T>> implements Comparable<NodoDoble<T>> {
    public T dato;
    public NodoDoble<T> siguiente;
    public NodoDoble<T> anterior;

    public NodoDoble(T dato, NodoDoble<T> siguiente, NodoDoble<T> anterior) {
        this.dato = dato;
        this.siguiente = siguiente;
        this.anterior = anterior;
    }

    @Override
    public int compareTo(NodoDoble<T> otroNodo) {
        // Comparar los datos de los nodos
        return this.dato.compareTo(otroNodo.dato);
    }
}


