/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana5;

/**
 *
 * @author HOME
 */
class List {
    Node first;

    public void add(Object newData) {
        Node newNode = new Node();
        newNode.dato = newData;

        if (first == null) {
            first = newNode;
            return;
        }

        Node current = first;
        while (true) {
            if (current.up == null) {
                current.up = newNode;
                newNode.down = current;
                return;
            } else if (current.right == null) {
                current.right = newNode;
                newNode.left = current;
                return;
            } else if (current.down == null) {
                current.down = newNode;
                newNode.up = current;
                return;
            } else if (current.left == null) {
                current.left = newNode;
                newNode.right = current;
                return;
            } else {
                // Si no hay espacio en este nodo, mover al siguiente nodo en sentido horario
                current = current.right;
            }
        }
    }
}
