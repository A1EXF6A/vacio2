/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana2Ejercicios;

import Semana2.Estudiante;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
       Estudiante a = new Estudiante("1000");
       Estudiante b = new Estudiante("1000");
       Estudiante d = new Estudiante("1000");
       
       Lista<Estudiante> f = new Lista<>();
       f.insertar(a, 0);
    
    
    }
    
    
    
}
