/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana2;

import Semana1.Curso;

/**
 *
 * @author HOME
 */
public class GestorCursos {
    ListaE cursos;

    public GestorCursos() {
        cursos = new ListaE();
    }
    public void añadirCursos(Curso a){
        cursos.añadir(a);
        System.out.println("Se añadio");
        
    }
    
    public void imprimir(){
        for (int i = 0; i < cursos.size(); i++) {
            
        }
    }
    
    
}
