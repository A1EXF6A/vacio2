/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana2;

/**
 *
 * @author HOME
 */
public class ListaE {
    Nodo primero;
    int size;

    public ListaE() {
        size = 0;
        primero = null;
    }

    public boolean vacia() {
        return this.primero == null;
    }

    public int size() {
        return this.size;
    }

    public boolean añadir(Object a) {
        Nodo nuevo = null;
        try {
            nuevo = new Nodo(a);
        } catch (Exception e) {
            return false;
        }
        if (vacia()) {
            primero = nuevo;
            size++;
            return true;
        }
        Nodo ultimo = this.ultimo();
        ultimo.siguiente = nuevo;
        size++;
        return true;
    }

    public boolean insertarPrimero(Object a) {
        Nodo nuevo = null;
        try {
            nuevo = new Nodo(a);
        } catch (Exception e) {
            return false;
        }
        if (vacia())
            this.primero = nuevo;
        else {
            nuevo.siguiente = this.primero;
            this.primero = nuevo;
        }
        size++;
        return true;
    }

    public boolean borrar(Object a) {
        if (vacia())
            return false;
        if (this.primero.dato.equals(a)) {
            this.primero = this.primero.siguiente();
            size--;
            return true;
        }
        Nodo actual = this.primero;
        while (actual != null) {
            if (actual.siguiente != null && actual.siguiente.dato.equals(a)) {
                actual.siguiente = actual.siguiente.siguiente;
                size--;
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    private Nodo ultimo() {
        if (vacia())
            return null;
        Nodo ultimo = this.primero;
        while (ultimo.siguiente != null)
            ultimo = ultimo.siguiente;
        return ultimo;
    }

    public Object buscar(Object a) {
        if (this.vacia())
            return null;
        Nodo actual = this.primero;
        while (actual != null) {
            if (actual.dato.equals(a))
                return actual.dato;
            actual = actual.siguiente;
        }
        return null;
    }

    public void insertarPosicion(int posicion, Object dato) {
        if (posicion < 0 || posicion > size)
            throw new IndexOutOfBoundsException("Posición fuera de rango");
        Nodo nuevo = new Nodo(dato);
        if (posicion == 0) {
            nuevo.siguiente = primero;
            primero = nuevo;
        } else {
            Nodo anterior = obtenerNodoEnPosicion(posicion - 1);
            nuevo.siguiente = anterior.siguiente;
            anterior.siguiente = nuevo;
        }

        size++;
    }

    private Nodo obtenerNodoEnPosicion(int posicion) {
        Nodo actual = primero;
        for (int i = 0; i < posicion; i++) {
            actual = actual.siguiente;
        }
        return actual;
    }

    public void eliminarPosicion(int posicion) {
        if (vacia())
            throw new IllegalStateException("La lista está vacía");
        if (posicion < 0 || posicion >= size)
            throw new IndexOutOfBoundsException("Posición fuera de rango");
        if (posicion == 0) {
            primero = primero.siguiente;
        } else {
            Nodo anterior = obtenerNodoEnPosicion(posicion - 1);
            anterior.siguiente = anterior.siguiente.siguiente;
        }

        size--;
    }

    public boolean eliminarDato(Object a){
        boolean borra = false;
        while(primero!=null & primero.dato.equals(a)){
            primero = primero.siguiente;
            borra = true;
        }
        
        Nodo actual = primero;
        while(actual!=null){
            if(actual.siguiente!=null&&actual.siguiente.dato.equals(a)){
                actual.siguiente = actual.siguiente.siguiente;
                borra = true;
            }else{
                actual = actual.siguiente;
            }
        }
        return borra;
        
    }


}
