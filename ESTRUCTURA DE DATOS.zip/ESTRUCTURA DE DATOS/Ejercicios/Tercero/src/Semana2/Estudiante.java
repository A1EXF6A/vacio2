/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana2;

/**
 *
 * @author HOME
 */
public class Estudiante {
    String ced;
    String name;

    public Estudiante(String ced) {
        this.ced = ced;
    }
    @Override
    public boolean equals(Object a){
        if(a instanceof Estudiante)
            return this.ced.equals(((Estudiante)a).ced);
        return false;
    }
    
    public String toString(){
        return "Nmobre: "+this.name+" cedula: "+this.ced;
    }
}
