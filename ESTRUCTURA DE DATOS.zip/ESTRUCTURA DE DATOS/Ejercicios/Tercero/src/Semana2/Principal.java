/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana2;

import Semana1.Curso;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
        /*Curso a = new Curso("Historia");
        Curso b = new Curso("quimica");
        Curso c = new Curso("ciencia");
        Curso d = new Curso("mate");
        
        GestorCursos f = new GestorCursos();
        f.añadirCursos(a);
        f.añadirCursos(b);
        f.añadirCursos(c);
        f.añadirCursos(d);
        
        System.out.println(f.cursos.buscar(0));
        System.out.println(f.cursos.buscar(1));
        System.out.println(f.cursos.buscar(2));
        System.out.println(f.cursos.buscar(3));*/
        Estudiante a = new Estudiante("123"); a.name = "luisa";
        Estudiante c = new Estudiante("1235"); c.name = "luis";
        Estudiante h = new Estudiante("1235"); h.name = "Madelaine";
        Estudiante g = new Estudiante("1235"); g.name="Maria";
        Estudiante y = new Estudiante("1235"); y.name="Camilo";
        ListaE b = new ListaE();
        b.añadir(a);
        b.añadir(c);
        b.añadir(a);
        b.añadir(a);
        b.añadir(y);
        b.añadir(a);
        
        //System.out.println(b.size());
        
        b.insertarPosicion(1, g);
        //Estudiante f = (Estudiante)b.buscar(c);
        
        //System.out.println(f.toString());
        Nodo actual = b.primero;
        while (actual != null) {
            Estudiante estudiante = (Estudiante) actual.dato();
            System.out.println(estudiante.toString());
            actual = actual.siguiente();
        }

        
        b.eliminarDato(a);
        //b.eliminarPosicion(2);
        //b.eliminarDato(g);
        System.out.println("");
        System.out.println("");
        Nodo actual1 = b.primero;
        while (actual1 != null) {
            Estudiante estudiante = (Estudiante) actual1.dato();
            System.out.println(estudiante.toString());
            actual1 = actual1.siguiente();
        }
    }
}
