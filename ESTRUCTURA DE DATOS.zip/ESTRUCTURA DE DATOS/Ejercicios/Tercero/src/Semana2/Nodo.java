/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana2;

/**
 *
 * @author HOME
 */
public class Nodo {
    Object dato;
    Nodo siguiente;

    public Nodo(Object dato,Nodo siguiente) {
        this.dato = dato;
        this.siguiente = siguiente;
    }

    public Nodo(Object dato) {
        this.dato = dato;
    }
    
    public void enlaze(Nodo a){
        this.siguiente = a;
    }
    
    public Nodo siguiente(){
        return siguiente;
    }
    
    public Object dato(){
        return dato;
    }
}
