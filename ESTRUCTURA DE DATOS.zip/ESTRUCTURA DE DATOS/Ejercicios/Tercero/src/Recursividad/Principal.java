/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Recursividad;

import java.util.Scanner;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {/*
        Scanner scanner = new Scanner(System.in);
        System.out.println(factorial(5));
        System.out.println(fibonacci(3));
        System.out.println(suma(10));
        System.out.println(sumaPares(10));
        int [] a = {1,5,6,2,3};
        int[] b = ordenar(a);
        for (int i = 0; i < b.length; i++) {
            System.out.println(b[i]);
        }
        //MCD
        System.out.print("Ingrese el valor de M: ");
        int m = scanner.nextInt();
        System.out.print("Ingrese el valor de N: ");
        int n = scanner.nextInt();
        
        // Si m es menor que n, intercambiamos los valores
        if (m < n) {
            int temp = m;
            m = n;
            n = temp;
        }
        
        int mcd = calcularMCD(m, n);
        
        System.out.println("El MCD de " + m + " y " + n + " es: " + mcd);
        */
        System.out.println(convertirABinario(10));
        System.out.println(convertirAEntero("1010"));
        int[] a = {1,2,10,4};
        System.out.println(sumaArreglo(a));
        System.out.println(f(65));
        
        String palabra = "hola"; // Puedes cambiar la cadena aquí
        
        if (esPalindromo(palabra)) {
            System.out.println("'" + palabra + "' es un palíndromo.");
        } else {
            System.out.println("'" + palabra + "' no es un palíndromo.");
        }
  }
   
  private static int factorial(int n){
      if(n<0)
          return -1;
      if(n==0||n==1)
          return 1;
      return n*factorial(n-1);
  

  }
  
  public static int fibonacci(int n) {
    if(n<0)
          return -1;
    if(n==0||n==1)
          return 1;
      return fibonacci(n - 1) + fibonacci(n - 2);
    
  }
  
  static int suma(int n){
      if(n<0)
          return -1;
      if(n==0||n==1)
          return n;
      return n+suma(n-1);
  }
  
  static int sumaPares(int n){
      if(n<=2)
          return 0;
      return n+suma(n-2);
  }
  
  static int verParImpar(int n){
      if(n%2!=0){
          System.out.println("Impar");
          return -1;
      }
      return sumaPares(n);
  }
  
  static int[] cambiarOrden(int []n,int m){
      int menor = 0;
      int a = 0;
      for (int i = 0; i < n.length; i++) {
          if(n[i]<menor){
              menor=n[i];
              n[m] = n[i];
              n[i]=menor;
          }
          
      }
      return ordenar(n);   
  }
  
  static int[] ordenar(int []n){
      return cambiarOrden(n, n.length-1);
  }
  
  // Función recursiva para calcular el MCD
    public static int calcularMCD(int m, int n) {
        if (n == 0) {
            return m;
        } else {
            return calcularMCD(n, m % n);
        }
    }
    
    static String convertirABinario(int numero) {
        if (numero == 0) {
            return "0";
        } else if (numero == 1) {
            return "1";
        } else {
            return convertirABinario(numero / 2) + numero % 2;
        }
    }
    
    static int convertirAEntero(String binario) {
        if (binario.isEmpty()) {
            return 0;
        } else {
            char ultimoDigito = binario.charAt(binario.length() - 1);
            int digito = Character.getNumericValue(ultimoDigito);
            String binarioRestante = binario.substring(0, binario.length() - 1);
            return convertirAEntero(binarioRestante) * 2 + digito;
        }
    }
    
    public static int sumaArreglo(int[] arreglo) {
        return calcularSumaRecursiva(arreglo, 0);
    }
    
    private static int calcularSumaRecursiva(int[] arreglo, int indice) {
        if (indice == arreglo.length) {
            return 0;
        } else {
            return arreglo[indice] + calcularSumaRecursiva(arreglo, indice + 1);
        }
    }
    
    public static void invertirArreglo(int[] arreglo) {
        invertirArregloRecursivo(arreglo, 0, arreglo.length - 1);
    }
    
    
    private static void invertirArregloRecursivo(int[] arreglo, int inicio, int fin) {
        if (inicio >= fin) {
            return;
        } else {
            int temp = arreglo[inicio];
            arreglo[inicio] = arreglo[fin];
            arreglo[fin] = temp;
            invertirArregloRecursivo(arreglo, inicio + 1, fin - 1);
        }
    }
    
    static int f(int x){
        {
        if (x >100)
        {
        return (x-10);
        }
        else
        {
        return(f(f(x+11)));
        }
        }
    }
    
    public static boolean esPalindromo(String cadena) {
        cadena = cadena.toLowerCase().replaceAll("\\s+", "");
        return esPalindromoRecursivo(cadena, 0, cadena.length() - 1);
    }
    
    private static boolean esPalindromoRecursivo(String cadena, int inicio, int fin) {
        if (inicio >= fin) {
            return true;
        } else {
            
            if (cadena.charAt(inicio) != cadena.charAt(fin)) {
                return false; 
            } else {
                return esPalindromoRecursivo(cadena, inicio + 1, fin - 1);
            }
        }
    }
    
}
