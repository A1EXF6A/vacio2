/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana1;

/**
 *
 * @author HOME
 */
public class Curso {
    String nombre;
    Estudiante primero;

    public Curso(String nombre) {
        this.nombre = nombre;
    }
    void insertarEst(Estudiante estudiante){
        Estudiante ultimo = this.ultimo();
        if(ultimo==null){
            this.primero = estudiante;
        }else
            ultimo.siguiente = estudiante;
    }
    
    private Estudiante ultimo(){
        if(this.primero==null)
            return null;
        Estudiante actual = this.primero;
        while(actual.siguiente!=null)
            actual = actual.siguiente;
        return actual;
    }
    
    void imprimer(){
        Estudiante actual = this.primero;
        while(actual!=null){
            System.out.println(actual.toString());
            actual = actual.siguiente;
        }
    }
    
    public String toString(){
        return this.nombre;
    }
    
        
    
}

