/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana1;

/**
 *
 * @author HOME
 */
public class Estudiante {
 String cedula;
 Estudiante siguiente;

    public Estudiante(String cedula, Estudiante siguiente) {
        this.cedula = cedula;
        this.siguiente = siguiente;
    }
    public String toString(){
        return this.cedula;
    }
}
