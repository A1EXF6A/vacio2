/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana4;

/**
 *
 * @author HOME
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listadec;

/**
 *
 * @author ASUS
 */
public class ListaDoble<T>{

    NodoD<T> primero;
    int cantidad;

    public ListaDoble() {
        this.primero = null;
        this.cantidad = 0;
    }

    public boolean insertarPorPrimero(T dato) {
        NodoD<T> nuevo = new NodoD<>(dato, null, null);
        if (this.primero == null) {
            this.primero = nuevo;
        } else {
            nuevo.siguiente = this.primero;
            this.primero.anterior = nuevo;
            this.primero = nuevo;
        }
        this.cantidad++;
        return true;
    }

    public boolean insertarPorUltimo(T dato) {
        NodoD<T> nuevo = new NodoD<>(dato, null, null);
        if (this.primero == null) {
            this.primero = nuevo;
        } else {
            NodoD<T> actual = this.primero;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
            nuevo.anterior = actual;
        }
        this.cantidad++;
        return true;
    }
    
    public boolean borrar(int pos) {
        if (pos < 0 || pos >= this.cantidad) {
            return false;
        }
        if (pos == 0) {
            this.primero = this.primero.siguiente;
            if (this.primero != null) {
                this.primero.anterior = null;
            }
        } else {
            NodoD<T> anterior = buscar(pos - 1);
            anterior.siguiente = anterior.siguiente.siguiente;
            if (anterior.siguiente != null) {
                anterior.siguiente.anterior = anterior;
            }
        }
        this.cantidad--;
        return true;
    }
    
    public NodoD<T> buscar(int pos) {
        if (pos < 0 || pos >= this.cantidad)
            return null;
        int posActual = 0;
        NodoD<T> actual = this.primero;
        while (posActual != pos) {
            actual = actual.siguiente;
            posActual++;
        }
        return actual;
    }
    
    public boolean borrarDato(T dato) {
        boolean borrado = false;
        while (this.primero != null && this.primero.dato.equals(dato)) {
            this.primero = this.primero.siguiente;
            if (this.primero != null)
                this.primero.anterior = null;
            this.cantidad--;
            borrado = true;
        }
        NodoD<T> actual = this.primero;
        while (actual != null && actual.siguiente != null) {
            if (actual.siguiente.dato.equals(dato)) {
                actual.siguiente = actual.siguiente.siguiente;
                if (actual.siguiente != null)
                    actual.siguiente.anterior = actual;
                this.cantidad--;
                borrado = true;
            } else
                actual = actual.siguiente;
        }
        return borrado;
    }
    
    public boolean insertarPosicion(T dato, int pos) {
        if (pos < 0 || pos > this.cantidad || dato == null)
            return false;
        if (pos == 0)
            return insertarPorPrimero(dato);
        if (pos == this.cantidad)
            return insertarPorUltimo(dato);
        NodoD<T> nuevo = new NodoD<>(dato, null, null);
        NodoD<T> anterior = buscar(pos - 1);
        nuevo.siguiente = anterior.siguiente;
        if (anterior.siguiente != null) {
            anterior.siguiente.anterior = nuevo;
        }
        anterior.siguiente = nuevo;
        nuevo.anterior = anterior;
        this.cantidad++;
        return true;
    }
   
}

