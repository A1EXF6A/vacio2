/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana4;

/**
 *
 * @author HOME
 */
public class ListaCircularDoble<T> {

    NodoD<T> primero;
    int cantidad;

    public ListaCircularDoble() {
        this.primero = null;
        this.cantidad = 0;
    }

    public boolean insertarPorPrimero(T dato) {
        NodoD<T> nuevo = new NodoD<>(dato, null, null);
        if (this.primero == null) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero;
            this.primero.anterior = this.primero;
        } else {
            nuevo.siguiente = this.primero;
            nuevo.anterior = this.primero.anterior;
            this.primero.anterior.siguiente = nuevo;
            this.primero.anterior = nuevo;
            this.primero = nuevo;
        }
        this.cantidad++;
        return true;
    }

    public boolean insertarPorUltimo(T dato) {
        NodoD<T> nuevo = new NodoD<>(dato, null, null);
        if (this.primero == null) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero;
            this.primero.anterior = this.primero;
        } else {
            nuevo.siguiente = this.primero;
            nuevo.anterior = this.primero.anterior;
            this.primero.anterior.siguiente = nuevo;
            this.primero.anterior = nuevo;
        }
        this.cantidad++;
        return true;
    }

    public boolean insertarPosicion(T dato, int pos) {
        if (pos < 0 || pos > this.cantidad || dato == null)
            return false;
        if (pos == 0)
            return insertarPorPrimero(dato);
        if (pos == this.cantidad)
            return insertarPorUltimo(dato);
        NodoD<T> nuevo = new NodoD<>(dato, null, null);
        NodoD<T> anterior = buscar(pos - 1);
        nuevo.siguiente = anterior.siguiente;
        nuevo.anterior = anterior;
        anterior.siguiente.anterior = nuevo;
        anterior.siguiente = nuevo;
        this.cantidad++;
        return true;
    }

    public boolean borrar(int pos) {
        if (pos < 0 || pos >= this.cantidad)
            return false;
        if (pos == 0) {
            if (this.cantidad == 1) {
                this.primero = null;
            } else {
                this.primero.anterior.siguiente = this.primero.siguiente;
                this.primero.siguiente.anterior = this.primero.anterior;
                this.primero = this.primero.siguiente;
            }
        } else {
            NodoD<T> anterior = buscar(pos - 1);
            anterior.siguiente = anterior.siguiente.siguiente;
            if (anterior.siguiente != null)
                anterior.siguiente.anterior = anterior;
        }
        this.cantidad--;
        return true;
    }

    public NodoD<T> buscar(int pos) {
        if (pos < 0 || pos >= this.cantidad)
            return null;
        int posActual = 0;
        NodoD<T> actual = this.primero;
        while (posActual != pos) {
            actual = actual.siguiente;
            posActual++;
        }
        return actual;
    }
    public boolean eliminarIntermedios(Object a, int pos){
        boolean borra = false;
        NodoD temp = buscar(pos);
        NodoD b;
        if(temp!=null){
            b = buscarDato(a);
            temp.siguiente = b;
            b.anterior=temp;
            borra = true;
        }else{
            borra=false;
        }
        return borra; 
    }
    
    public NodoD<T> buscarDato(Object a){
        if(a==null)
            return null;
        NodoD<T> temp = this.primero;
        while(!temp.dato.equals(a)){
            temp = temp.siguiente;
        }
        return temp;
    }
    
    /*
    public boolean eliminarIntermedios(Object dato, int pos) {
    if (pos < 0 || pos >= this.cantidad || dato == null)
        return false;

    NodoD<T> nodoActual = buscar(pos);
    if (nodoActual == null)
        return false;

    NodoD<T> nodoDato = buscarDato(dato);
    if (nodoDato == null)
        return false;

    // Verificar si la posición dada es igual a la posición del nodo con el dato
    if (pos >= this.cantidad || nodoDato == nodoActual.siguiente)
        return false;

    // Eliminar los nodos intermedios
    nodoActual.siguiente = nodoDato;
    nodoDato.anterior = nodoActual;

    // Actualizar la cantidad de elementos
    this.cantidad = pos + 1;
    return true;
}

    */
}



