/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana4;

import Semana2.Estudiante;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
        Estudiante a = new Estudiante("100");
        Estudiante b = new Estudiante("200");
        Estudiante c = new Estudiante("300");
        Estudiante d = new Estudiante("400");
        Estudiante e = new Estudiante("500");
        Lista<Estudiante> n = new Lista<>();
        n.insertarPorPrimero(a);
        n.insertarPorPrimero(b);
        n.insertarPorPrimero(c);n.insertarPorPrimero(d);
        
        
        Nodo<Estudiante> i = n.primero;
        
        /*do {
            i.dato.toString();
        } while (i.siguiente!=n.primero);*/
        
        //n.pares(5);
        n.imprimirpares();
    }
}
