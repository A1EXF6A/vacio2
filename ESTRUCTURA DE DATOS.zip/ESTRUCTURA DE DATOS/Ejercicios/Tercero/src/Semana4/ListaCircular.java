/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana4;

/**
 *
 * @author HOME
 */
public class ListaCircular<T> {
    Nodo<T> primero;
    int cantidad;

    public ListaCircular() {
        this.primero = null;
        this.cantidad = 0;
    }

    

    public boolean insertarPorPrimero(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato, null);
        if (this.primero == null) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero;
            this.cantidad = 1;
        } else {
            nuevo.siguiente = this.primero;
            this.primero = nuevo;
            Nodo<T> actual = this.primero;
            while (actual.siguiente != this.primero) {
                actual = actual.siguiente;
            }
            actual.siguiente = this.primero;
            this.cantidad++;
        }
        return true;
    }
    public boolean insertarPorUltimo(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato, null);
        if (this.primero == null) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero;
            this.cantidad = 1;
        } else {
            Nodo<T> ultimo = this.buscar(this.cantidad - 1);
            ultimo.siguiente = nuevo;
            nuevo.siguiente = this.primero;
            this.cantidad++;
        }
        return true;
    }
    
    public boolean insertar(T dato, int pos) {
        if (pos < 0 || pos > this.cantidad || dato == null)
            return false;
        if (pos == 0)
            return insertarPorPrimero(dato);
        if (pos == this.cantidad)
            return insertarPorUltimo(dato);
        Nodo<T> anterior = this.buscar(pos - 1);
        anterior.siguiente = new Nodo<>(dato, anterior.siguiente);
        this.cantidad++;
        return true;
    }

    private Nodo<T> buscar(int pos) {
        if (pos < 0 || pos >= this.cantidad)
            return null;
        int posActual = 0;
        Nodo<T> actual = this.primero;
        while (posActual != pos) {
            actual = actual.siguiente;
            posActual++;
        }
        return actual;
    }

    public boolean borrar(int pos) {
        Nodo<T> anterior = this.buscar(pos - 1);
        if (anterior == null || anterior.siguiente == null)
            return false;
        anterior.siguiente = anterior.siguiente.siguiente;
        this.cantidad--;
        return true;
    }

    public boolean borrar(T dato) {
        boolean borrado = false;
        while (this.primero != null && this.primero.dato.equals(dato)) {
            this.primero = this.primero.siguiente;
            this.cantidad--;
            borrado = true;
        }
        Nodo<T> actual = this.primero;
        while (actual != null) {
            if (actual.siguiente != null && actual.siguiente.dato.equals(dato)) {
                actual.siguiente = actual.siguiente.siguiente;
                this.cantidad--;
                borrado = true;
            } else
                actual = actual.siguiente;
        }
        return borrado;
    }
    
    public void pares(float a){
        if(a%2==0){
                for (int i = 0; i < this.cantidad; i++) {
                    if(i%2==0&&primero.siguiente!=null){
                        System.out.println(primero.dato);
                    }
                    this.primero = primero.siguiente;
            }
        }else{
            for (int i = 0; i < this.cantidad; i++) {
                if(i%2!=0&&primero.siguiente!=null){
                    System.out.println(primero.dato);
                }
                this.primero = primero.siguiente;
        }
        }
    }
    
    public void imprimirpares(){
        if(this.primero==null||this.primero.siguiente==null)
            return;
        Nodo actual = this.primero;
        this.imprimirSaltandoNodos(actual);
    }
    public void imprimirImpares(){
        if(this.primero==null)
            return;
        Nodo actual = this.primero;
        this.imprimirSaltandoNodos(actual);
        
    }
    private void imprimirSaltandoNodos(Nodo nodo){
        if(nodo==null){
            return;
        }
        do {
            if(nodo.dato!=null)System.out.println(nodo.dato);
            nodo=nodo.siguiente.siguiente;
                
        } while (nodo!=this.primero&&nodo!=this.primero.siguiente);
    }
}
