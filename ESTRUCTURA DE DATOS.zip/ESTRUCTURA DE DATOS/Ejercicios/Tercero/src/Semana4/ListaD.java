/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana4;

/**
 *
 * @author HOME
 *//*
public class ListaD<T> {

    NodoD<T> primero;
    int cantidad;

    public ListaD() {
        this.primero = null;
        this.cantidad = 0;
    }

    public boolean insertarPorPrimero(T dato) {
        NodoD<T> nuevo = new NodoD<>(dato, null,null);
        if (this.primero == null) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero.anterior = this.primero;
            this.cantidad = 1;
        } else {
            nuevo.siguiente = this.primero;
            nuevo.anterior = this.primero.anterior;
            this.primero.anterior.siguiente = nuevo;
            this.primero.anterior = nuevo;
            this.cantidad++;
        }
        return true;
    }

    public boolean insertarPorÚltimo(T dato) {
        NodoD<T> nuevo = new NodoD<>(dato, null,null);
        if (this.primero == null) {
            this.primero = nuevo;
            this.primero.siguiente = this.primero.anterior = this.primero;
            this.cantidad = 1;
        } else {
            
        }
        return true;
    }

    public boolean insertar(T dato, int pos) {
        if (pos < 0 || pos > this.cantidad || dato == null)
            return false;
        if (pos == 0)
            return insertarPorPrimero(dato);
        if (pos == this.cantidad)
            return insertarPorÚltimo(dato);
        Nodo<T> anterior = this.buscar(pos - 1);
        anterior.siguiente = new Nodo<>(dato, anterior.siguiente);
        this.cantidad++;
        return true;
    }

    private Nodo<T> buscar(int pos) {
        if(pos<0)
            return null;
        if(pos>=this.cantidad){
            pos+=1;
            pos%=this.cantidad;
            pos--;
        }
        int actual = 0;
        NodoD a = this.primero;
        while(actual!=pos){
            a = a.siguiente;
            actual++;
        }
        return a;
    }

    public boolean borrar(int pos) {
        
    }

    public boolean borrar(T dato) {
        if(this.primero==null){
            return false;
        }
        boolean borra = false;
        while(this.primero.dato.equals(dato)){
            if(this.)
        }
    }

}*/