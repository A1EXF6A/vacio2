/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana4;

/**
 *
 * @author HOME
 */
public class NodoD <T>{
    public T dato;
    public NodoD<T> siguiente;
    public NodoD<T> anterior;
    
    public NodoD( T dato, NodoD<T> siguiente,NodoD<T> anterior ){
        this.dato = dato;
        this.siguiente = siguiente;
        this.anterior = anterior;
    }
    
    public NodoD(T dato) {
        this.dato = dato;
    }
}
