/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista;

/**
 *
 * @author HOME
 */
public class ListaE<T> {
    Nodo<T> primero;
    int size;

    public ListaE() {
        size = 0;
        primero = null;
    }

    public boolean vacia() {
        return this.primero == null;
    }

    public int size() {
        return this.size;
    }

    public boolean añadir(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (vacia()) {
            primero = nuevo;
            size++;
            return true;
        }
        Nodo<T> ultimo = this.ultimo();
        ultimo.siguiente = nuevo;
        size++;
        return true;
    }

    public boolean insertarPrimero(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (vacia())
            this.primero = nuevo;
        else {
            nuevo.siguiente = this.primero;
            this.primero = nuevo;
        }
        size++;
        return true;
    }

    public boolean borrar(T dato) {
        if (vacia())
            return false;
        if (this.primero.dato.equals(dato)) {
            this.primero = this.primero.siguiente;
            size--;
            return true;
        }
        Nodo<T> actual = this.primero;
        while (actual != null) {
            if (actual.siguiente != null && actual.siguiente.dato.equals(dato)) {
                actual.siguiente = actual.siguiente.siguiente;
                size--;
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    private Nodo<T> ultimo() {
        if (vacia())
            return null;
        Nodo<T> ultimo = this.primero;
        while (ultimo.siguiente != null)
            ultimo = ultimo.siguiente;
        return ultimo;
    }

    public T buscar(T dato) {
        if (this.vacia())
            return null;
        Nodo<T> actual = this.primero;
        while (actual != null) {
            if (actual.dato.equals(dato))
                return actual.dato;
            actual = actual.siguiente;
        }
        return null;
    }

    public void insertarPosicion(int posicion, T dato) {
        if (posicion < 0 || posicion > size)
            throw new IndexOutOfBoundsException("Posición fuera de rango");
        Nodo<T> nuevo = new Nodo<>(dato);
        if (posicion == 0) {
            nuevo.siguiente = primero;
            primero = nuevo;
    
        } else {
            Nodo<T> anterior = obtenerNodoEnPosicion(posicion - 1);
            nuevo.siguiente = anterior.siguiente;
            anterior.siguiente = nuevo;
        }

        size++;
    }

    private Nodo<T> obtenerNodoEnPosicion(int posicion) {
        Nodo<T> actual = primero;
        for (int i = 0; i < posicion; i++) {
            actual = actual.siguiente;
        }
        return actual;
    }

    public void eliminarPosicion(int posicion) {
        if (vacia())
            throw new IllegalStateException("La lista está vacía");
        if (posicion < 0 || posicion >= size)
            throw new IndexOutOfBoundsException("Posición fuera de rango");
        if (posicion == 0) {
            primero = primero.siguiente;
        } else {
            Nodo<T> anterior = obtenerNodoEnPosicion(posicion - 1);
            anterior.siguiente = anterior.siguiente.siguiente;
        }

        size--;
    }

    public boolean eliminarDato(T dato) {
        boolean borra = false;
        while (primero != null && primero.dato.equals(dato)) {
            primero = primero.siguiente;
            borra = true;
        }

        Nodo<T> actual = primero;
        while (actual != null) {
            if (actual.siguiente != null && actual.siguiente.dato.equals(dato)) {
                actual.siguiente = actual.siguiente.siguiente;
                borra = true;
            } else {
                actual = actual.siguiente;
            }
        }
        return borra;
    }
}
