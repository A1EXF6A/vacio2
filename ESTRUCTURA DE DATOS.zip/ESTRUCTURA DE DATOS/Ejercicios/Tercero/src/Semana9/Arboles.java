/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana9;

/**
 *
 * @author HOME
 */
public class Arboles {
    NodoABin raiz;
    public Arboles(){
        this.raiz = null;
    }
    
    public boolean insertarLexicográfico(int valor){
        if (this.raiz != null)
            return this.raiz.insertarLexicográfico(valor);
        try{
            this.raiz = new NodoABin(valor, null, null);
            return true;
        } catch (Exception e){
            return false;
        }
        
    }
    
    void imprimir(){
        if(raiz==null)
            System.out.println("El arbol esta vacio");
        else{
            raiz.imprimirSimetrico();
        }
    }
    
    void imprimirPosorden(){
        if(raiz==null)
            System.out.println("El arbol esta vacio");
        else{
            raiz.imprimirPosorden();
        }
    }
    
    void imprimirPreorden(){
        if(raiz==null)
            System.out.println("El arbol esta vacio");
        else{
            raiz.imprimirPreorden();
        }
    }
}
