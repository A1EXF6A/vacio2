/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana9;

import java.util.LinkedList;

/**
 *
 * @author HOME
 */
public class NodoGeneral {
    int dato;
    LinkedList<NodoGeneral> hijos;

    public NodoGeneral(int dato) {
        this.dato = dato;
        this.hijos = new LinkedList<>();
    }
    
    
    
    
    
    


    void derecha(NodoABin t,NodoABin y){
        if(t.der==null){
            t.der = y;
        }else{
            derecha(t.der,y);
        }
    }
    
    
    void alimenta(NodoABin a) {
            if(!hijos.isEmpty()) {
                NodoGeneral primerHijo = hijos.getFirst();
                NodoABin hijoIzq = new NodoABin(primerHijo.dato);
                a.agregarHijoIzquierdo(hijoIzq);
                primerHijo.alimenta(hijoIzq);

                NodoABin actual = hijoIzq;
                for(int i = 1; i < hijos.size(); i++) {
                    NodoGeneral hermano = hijos.get(i);
                    NodoABin hermanoBin = new NodoABin(hermano.dato);
                    actual.der = hermanoBin;
                    hermano.alimenta(hermanoBin);
                    actual = hermanoBin;
                }
            }
        }
    
    void alimentar(NodoABin n){
        if(n==null)
            return;
        
        if(!this.hijos.isEmpty()){
            NodoGeneral primero = this.hijos.getFirst();
            n.izq = new NodoABin(primero.dato,null,null,n);
            primero.alimentar(n.izq);
            
            NodoABin actual = n.izq;
            for (int i = 0; i < this.hijos.size(); i++) {
                NodoGeneral hijogeneral = this.hijos.get(i);
                actual.der = new NodoABin(hijogeneral.dato,null,null,n);
                hijogeneral.alimentar(actual.der);
                actual = actual.der;
            }
        }
    }
    
    
    }

    


    

