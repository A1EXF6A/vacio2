/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana9;

/**
 *
 * @author HOME
 */
public class ArbolGeneral {
    NodoGeneral raiz;
    public ArbolGeneral(){
        this.raiz = null;
    }
    
    public NodoGeneral buscar(int dato){
        return buscarR(raiz,dato);
    }
    
    public NodoGeneral buscarR(NodoGeneral a, int b){
        if(a==null)
            return null;
        
        
        if(a==raiz)
            return raiz;
        
        
        for(NodoGeneral c: a.hijos){
            NodoGeneral t = buscarR(c, b);
            if(c!=null)
                return c;
            
        }
        return null;
    }
    
    public Arboles equivalente1(){{
        Arboles a = new Arboles();
        if(raiz!=null)
            a.raiz = new NodoABin(this.raiz.dato);
            raiz.alimenta(a.raiz);
        return a;
    }
    
    
    
    
    
}
    public Arboles equivalente(){
        Arboles a = new Arboles();
        if(raiz != null) {
            a.raiz = new NodoABin(this.raiz.dato);
            raiz.alimenta(a.raiz);
        }
        return a;
    }
    
    
}