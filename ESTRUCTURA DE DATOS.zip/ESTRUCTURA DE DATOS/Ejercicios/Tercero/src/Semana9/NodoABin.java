/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana9;

import java.util.LinkedList;

/**
 *
 * @author HOME
 */
public class NodoABin {
    int dato;
    NodoABin izq, der;
    NodoABin padre;
    
    public NodoABin(int dato){
        this.dato=dato;
    }
    
    public NodoABin(int dato, NodoABin izq, NodoABin der){
        this.dato = dato;
        this.izq = izq;
        this.der = der;
    }

    NodoABin(int dato, NodoABin izq, NodoABin der, NodoABin padre) {
        this.dato = dato;
        this.izq = izq;
        this.der = der;
        this.padre = padre;
    }

    boolean insertarLexicográfico(int valor) {
        if (this.dato == valor)
            return false;
        if (this.dato < valor)
            if (this.der == null)
                try{
                    this.der = new NodoABin(valor, null, null);
                    return true;
                } catch (Exception e){
                    return false;
                }
            else 
                return this.der.insertarLexicográfico(valor);
        if(this.izq==null)
                try{
                    this.izq = new NodoABin(valor, null, null);
                    return true;
                } catch (Exception e){
                    return false;
                }
            else
                return this.izq.insertarLexicográfico(valor);
            
    }
    
    void imprimirSimetrico(){
        if(izq!=null)
            this.izq.imprimirSimetrico();
        System.out.println(dato);
        if(der!=null)
            this.der.imprimirSimetrico();
    }
    
    void imprimirPreorden(){
        System.out.println(dato);
        if(izq!=null)
            this.izq.imprimirPreorden();
        
        if(der!=null)
            this.der.imprimirPreorden();
    }
    
    void imprimirPosorden(){
        if(izq!=null)
            this.izq.imprimirPosorden();
        
        if(der!=null)
            this.der.imprimirPosorden();
        
        System.out.println(dato);
    }
    
    int nivelArbol(){
        if(this.padre==null)
            return 0;
        return this.padre.nivelArbol()+1;
            
    }
    
    public void agregarHijoIzquierdo(NodoABin hijoIzquierdo) {
        this.izq = hijoIzquierdo;
        if (hijoIzquierdo != null) {
            hijoIzquierdo.padre = this;
        }
    }
    
    LinkedList<NodoABin> hermanos(NodoABin a){
        LinkedList<NodoABin> hermanos = new LinkedList<>();
        if(padre!=null){
            NodoABin hijo = this.padre.izq;
            while(hijo!=null){
                if(hijo!=this){
                    hermanos.add(hijo);
                }
                hijo = hijo.der;
            }
        }
        
        
        return hermanos;
        
    }
    LinkedList<NodoABin> hermanos() {
        LinkedList<NodoABin> hermanos = new LinkedList<>();

        
        if (this.padre == null) {
            return hermanos;
        }
        //hijo izq
        if (this.padre.izq != null && this.padre.izq != this) {
            hermanos.add(this.padre.izq);
        }
        //hijo der
        if (this.padre.der != null && this.padre.der != this) {
            hermanos.add(this.padre.der);
        }

        return hermanos;
    }
}