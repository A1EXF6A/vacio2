/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana9;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
       /* Arboles arbol = new Arboles();

       arbol.insertarLexicográfico(8);
       arbol.insertarLexicográfico(6);
       arbol.insertarLexicográfico(1);
       arbol.insertarLexicográfico(7);
       arbol.insertarLexicográfico(10);
       arbol.insertarLexicográfico(12);
       ///arbol.insertarLexicográfico(3);
       
       arbol.imprimir();
        System.out.println("");
       arbol.imprimirPreorden();
       System.out.println("");
       arbol.imprimirPosorden();
       
       arbol.insertarLexicográfico(1);
       arbol.insertarLexicográfico(6);
       arbol.insertarLexicográfico(7);
       arbol.insertarLexicográfico(8);
       arbol.insertarLexicográfico(10);
       arbol.insertarLexicográfico(12);
       
       arbol.insertarLexicográfico(8);
       arbol.insertarLexicográfico(1);
       arbol.insertarLexicográfico(6);
       arbol.insertarLexicográfico(7);
       arbol.insertarLexicográfico(10);
       arbol.insertarLexicográfico(12);*/
       NodoHilvanado  raiz = new NodoHilvanado(5,null,null,true,true);
       ArbolHilbanado a = new ArbolHilbanado();
       
       a.insertar5(3);
       a.insertar5(8);
       a.insertar5(7);
       a.insertar5(6);
       a.insertar5(4);
       
        a.imprimir();
    }
    
}
