/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana9;

/**
 *
 * @author HOME
 */
public class ArbolHilbanado {
    NodoHilvanado raíz;
    
    
    boolean insertar(int dato){
        if (this.raíz == null){
            this.raíz = new NodoHilvanado(dato, null, null, true, true);
            return true;
        }
        NodoHilvanado futuroPadre = this.buscarFuturoPadre(dato);
        if (futuroPadre == null)
            return false;
        if (futuroPadre.dato > dato){
            futuroPadre.izq = new NodoHilvanado(dato,futuroPadre.izq, futuroPadre, futuroPadre.realIzq, false);
            futuroPadre.realIzq = true;
        } else{
            futuroPadre.der = new NodoHilvanado(dato,futuroPadre, futuroPadre.der, false, futuroPadre.realDer);
            futuroPadre.realDer = true;  
        }
        return true;
}

    private NodoHilvanado buscarFuturoPadre(int dato) {
        if (this.raíz == null)
            return null;
        NodoHilvanado futuroPadre = this.raíz;
        while (true){
            if (futuroPadre.dato == dato)
                return null;
            if (futuroPadre.dato > dato){
                if (futuroPadre.izq == null || !futuroPadre.realIzq)
                    return futuroPadre;
                futuroPadre = futuroPadre.izq;
            }else{
                if (futuroPadre.der == null || !futuroPadre.realDer)
                        return futuroPadre;
                futuroPadre = futuroPadre.der;
            }
        }
    }

    void imprimir() {
        if (this.raíz == null)
            return;
        NodoHilvanado actual = this.raíz;
        while (actual.izq != null)
            actual = actual.izq;
        
        while (actual != null){
            System.out.println(actual.dato);
            if (!actual.realDer || actual.der == null)
                actual = actual.der;
            else{
                actual = actual.der;
                while (actual.realIzq)
                    actual = actual.izq;
            }
        }
    }
boolean insertar5(int dato) {
        // Si la raíz es nula, crea un nuevo nodo como raíz
        if (this.raíz == null) {
            this.raíz = new NodoHilvanado(dato, null, null, true, true);
            return true;
        }
        return insertarNodo(this.raíz, dato);
    }

    // Método para insertar el nodo en la posición correcta
    private boolean insertarNodo(NodoHilvanado actual, int dato) {
        while (true) {
            // Si el dato ya existe, no se puede insertar
            if (actual.dato == dato) {
                return false;
            }
            // Si el dato es menor, ve a la izquierda
            if (actual.dato > dato) {
                if (actual.izq == null || !actual.realIzq) {
                    actual.izq = new NodoHilvanado(dato, actual.izq, actual, actual.realIzq, false);
                    actual.realIzq = true;
                    return true;
                }
                actual = actual.izq;
            } else {
                // Si el dato es mayor, ve a la derecha
                if (actual.der == null || !actual.realDer) {
                    actual.der = new NodoHilvanado(dato, actual, actual.der, false, actual.realDer);
                    actual.realDer = true;
                    return true;
                }
                actual = actual.der;
            }
        }
    }
}
