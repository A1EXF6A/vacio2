/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana9;

/**
 *
 * @author HOME
 */
public class NodoHilvanado {
    int dato;
   NodoHilvanado izq, der;
   boolean realIzq, realDer;

    public NodoHilvanado(int dato, NodoHilvanado izq, NodoHilvanado der, boolean realIzq, boolean realDer) {
        this.dato = dato;
        this.izq = izq;
        this.der = der;
        this.realIzq = realIzq;
        this.realDer = realDer;
    }
    
    
    
    
}
