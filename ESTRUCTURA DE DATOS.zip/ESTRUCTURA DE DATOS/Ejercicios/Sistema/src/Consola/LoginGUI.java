/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Consola;

/**
 *
 * @author HOME
 */
import Proyecto.CentroReparacion;
import Proyecto.EstadoReparacion;
import Proyecto.Reparacion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginGUI extends JFrame {
    private CentroReparacion centro = new CentroReparacion();

    private JTextField usuarioField;
    private JPasswordField contraseñaField;
    private JButton iniciarSesionButton;
    private JComboBox<String> tipoCuentaComboBox;

    public LoginGUI() {
        setTitle("Inicio de Sesión");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelCentro = new JPanel(new GridLayout(4, 2));

        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioField = new JTextField();
        JLabel contraseñaLabel = new JLabel("Contraseña:");
        contraseñaField = new JPasswordField();
        JLabel tipoCuentaLabel = new JLabel("Tipo de Cuenta:");
        String[] tiposCuenta = {"Cliente", "Técnico"};
        tipoCuentaComboBox = new JComboBox<>(tiposCuenta);

        panelCentro.add(usuarioLabel);
        panelCentro.add(usuarioField);
        panelCentro.add(contraseñaLabel);
        panelCentro.add(contraseñaField);
        panelCentro.add(tipoCuentaLabel);
        panelCentro.add(tipoCuentaComboBox);

        iniciarSesionButton = new JButton("Iniciar Sesión");
        iniciarSesionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarSesion();
            }
        });

        panelCentro.add(iniciarSesionButton);
        add(panelCentro, BorderLayout.CENTER);
    }

    private void iniciarSesion() {
        String usuario = usuarioField.getText();
        String contraseña = new String(contraseñaField.getPassword());
        String tipoCuenta = (String) tipoCuentaComboBox.getSelectedItem();

        if (tipoCuenta.equals("Cliente")) {
            // Aquí podrías implementar la lógica para iniciar sesión como cliente
            // por ejemplo, llamando a un método del objeto CentroReparacion
            // para iniciar sesión como cliente.
            // centro.iniciarSesionCliente(usuario, contraseña);
            JOptionPane.showMessageDialog(this, "Iniciando sesión como cliente");
            mostrarOpcionesCliente(); // Llamada a la función para mostrar las opciones del cliente
        } else if (tipoCuenta.equals("Técnico")) {
            // Aquí podrías implementar la lógica para iniciar sesión como técnico
            // por ejemplo, llamando a un método del objeto CentroReparacion
            // para iniciar sesión como técnico.
            // centro.iniciarSesionTecnico(usuario, contraseña);
            JOptionPane.showMessageDialog(this, "Iniciando sesión como técnico");
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un tipo de cuenta válido");
        }
    }

    private void mostrarOpcionesCliente() {
        JFrame frameOpcionesCliente = new JFrame("Opciones Cliente");
        frameOpcionesCliente.setSize(400, 200);
        frameOpcionesCliente.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(2, 1));
        JButton ingresarReparacionButton = new JButton("Ingresar Reparación");
        JButton verReparacionesButton = new JButton("Ver Reparaciones");

        ingresarReparacionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ingresarReparacion();
            }
        });

        verReparacionesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                verReparaciones();
            }
        });

        panel.add(ingresarReparacionButton);
        panel.add(verReparacionesButton);
        frameOpcionesCliente.add(panel);
        frameOpcionesCliente.setVisible(true);
    }

    private void ingresarReparacion() {
        String nombre = JOptionPane.showInputDialog(this, "Nombre de la Reparación:");
        String estado = JOptionPane.showInputDialog(this, "Estado de la Reparación:");
        EstadoReparacion es = new EstadoReparacion(estado);
        Reparacion re = new Reparacion(nombre, es);
        // Aquí podrías llamar a un método del objeto CentroReparacion
        // para ingresar la reparación, por ejemplo:
        // centro.ingresarReparacion(re);
        JOptionPane.showMessageDialog(this, "Reparación ingresada exitosamente");
    }

    private void verReparaciones() {
        // Aquí podrías obtener las reparaciones del cliente desde el objeto CentroReparacion
        // y mostrarlas en una ventana de JOptionPane, por ejemplo:
        // JOptionPane.showMessageDialog(this, "Lista de Reparaciones: " + cliente.getReparaciones());
        JOptionPane.showMessageDialog(this, "Mostrar lista de reparaciones aquí");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                LoginGUI loginGUI = new LoginGUI();
                loginGUI.setVisible(true);
            }
        });
    }
}


