/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Consola;

import Proyecto.CentroReparacion;
import Proyecto.Cliente;
import Proyecto.EstadoReparacion;
import Proyecto.Reparacion;
import Proyecto.SolicitudReparaciones;
import Proyecto.Tecnico;
import java.util.Scanner;

/**
 *
 * @author HOME
 */
public class Login {
    CentroReparacion centro = new CentroReparacion();
    
    Scanner a = new Scanner(System.in);
    public void inicio(){
        int i;
        do {
            System.out.println("Seleccione la forma de inicio\n1. Cliente\n2. tecnico\n3. crear cuenta\n0. salir");
        
         i = a.nextInt();
        switch (i) {
            case 1:
                Cliente j = (Cliente) entrada(i);
                if(j==null){
                    System.out.println("Usuario no encontrado");
                    break;
                }
                opcionesCliente(j);
                
                break;
            case 2:
                Tecnico k = (Tecnico) entrada(i);
                if(k==null){
                    System.out.println("Usuario no encontrado");
                    break;
                }
                opcionesTecnico(k);
                break;
            case 3:
                crearCuenta();
                break;
            case 0:
                System.out.println("saliendo----");
                break;
            default:
                throw new AssertionError();
        }
        } while (i!=0);
    }
    
    public Object entrada(int k){
    String i,j;
    System.out.println("Ingrese su usuario"); 
    a.nextLine(); // Consumir la nueva línea en blanco
    i = a.nextLine();
    System.out.println("Ingrese su contraseña"); 
    j = a.nextLine();
    Object c = centro.buscarUsario(k, i, j);
    return c;
}

    
    public void crearCuenta(){
    System.out.println("Elija cómo quiere crear la cuenta\n1. Cliente\n2. Técnico");
    int i = a.nextInt();
    a.nextLine(); // Consumir la nueva línea en blanco
    String nombre, apellido, direccion, telefono, cedula, contraseña, usuario;
    switch (i) {
        case 1:
            System.out.println("Nombre"); 
            nombre = a.nextLine();
            System.out.println("Apellido"); 
            apellido = a.nextLine();
            System.out.println("Dirección"); 
            direccion = a.nextLine();
            System.out.println("Cédula"); 
            cedula = a.nextLine();
            System.out.println("Teléfono"); 
            telefono = a.nextLine();
            System.out.println("Usuario"); 
            usuario = a.nextLine();
            System.out.println("Contraseña"); 
            contraseña = a.nextLine();
            Cliente c = new Cliente(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
            centro.añadirCliente(c);
            break;
        case 2:
            System.out.println("Nombre"); 
            nombre = a.nextLine();
            System.out.println("Apellido"); 
            apellido = a.nextLine();
            System.out.println("Dirección"); 
            direccion = a.nextLine();
            System.out.println("Cédula"); 
            cedula = a.nextLine();
            System.out.println("Teléfono"); 
            telefono = a.nextLine();
            System.out.println("Usuario"); 
            usuario = a.nextLine();
            System.out.println("Contraseña"); 
            contraseña = a.nextLine();
            Tecnico o = new Tecnico(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
            centro.añadirTecnico(o);
            break;
        default:
            throw new AssertionError();
    }
}

    
    public void opcionesCliente(Cliente u){
        int i;
        do {
            System.out.println("Menu cliente\n1. Ingresar reparacion\n2. Ver reparaciones\n3. Eliminar reparacion\n0. Salir");
        
         i = a.nextInt();
        switch (i) {
            case 1:
                ingresarReparacion(u);
                break;
            case 2:
                centro.verReparaciones(u);
                break;
            case 3:
                centro.eliminarSolicitudReparacion(u);
                break;
            case 0:
                System.out.println("Saliendo del menu cliente");
                break;
            default:
                throw new AssertionError();
        }
        } while (i!=0);
    }
    
    void ingresarReparacion(Cliente i){
        String nombre,estado;
        System.out.println("Nombre"); 
        a.nextLine(); // Consumir la nueva línea en blanco
        nombre = a.nextLine();

        System.out.println("Estado"); 
        a.nextLine(); // Consumir la nueva línea en blanco
        estado = a.nextLine();

        EstadoReparacion es = new EstadoReparacion(estado);
        Reparacion re = new Reparacion(nombre, es);
        //i.realizarReparacion(re);
        SolicitudReparaciones sol = new SolicitudReparaciones(i, re);
        centro.recibirSolicitud(sol, i);  
    }
    

    
    
    
    public void opcionesTecnico(Tecnico b){
    int i;
    double pre;
    do {
        System.out.println("Menu técnico\n1. Recibir solicitud\n2. Reparar\n3. Asignar precio\n4. Ver mejores clientes\n5. Salir del menú técnico");
        String es;
        i = a.nextInt();
        switch (i) {
            case 1:
                centro.asignarReparacion(b);
                break;
            case 2:
                a.nextLine(); // Consumir la nueva línea en blanco
                System.out.println("Ingrese el nuevo estado");
                es = a.nextLine();
                b.reparar(es);
                break;
            case 3:
                if(b.reparacion.reparacion.estado.actual.equalsIgnoreCase("solucionada") || b.reparacion.reparacion.estado.actual.equalsIgnoreCase("sin solucion")){
                    System.out.println("Asignarle el precio a la reparación");
                    pre = a.nextDouble();
                    b.asignarPrecio(pre);
                }
                break;
            case 4:
                centro.mostrarMejoresClientes();
                break;
            case 5:
                System.out.println("Saliendo");
                break;
            default:
                throw new AssertionError();
        }
    } while (i != 5);
}

}
