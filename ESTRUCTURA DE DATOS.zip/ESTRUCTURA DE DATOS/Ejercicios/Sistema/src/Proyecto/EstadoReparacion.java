/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

/**
 *
 * @author HOME
 */
public class EstadoReparacion {
    public String actual;

    public EstadoReparacion(String actual) {
        this.actual = actual;
    }
    
    public void cambiar(String a){
        actual = a;
    }
}
