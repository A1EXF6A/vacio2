/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */
public class SolicitudReparaciones {
    public Cliente cliente;
    public Reparacion reparacion;
    public boolean reparando;
    public boolean terminado;

    public SolicitudReparaciones(Cliente cliente, Reparacion reparacion) {
        this.cliente = cliente;
        this.reparacion = reparacion;
        this.reparando = false;
        this.terminado = false;
    }
    
    
    
}

    
    

