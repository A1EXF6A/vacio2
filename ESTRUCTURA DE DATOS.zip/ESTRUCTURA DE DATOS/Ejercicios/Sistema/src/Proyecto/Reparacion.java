/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author HOME
 */
public class Reparacion {
    String nombre;
    public EstadoReparacion estado;
    LocalDateTime creacion;
    LocalDateTime fin;
    double precio;
    long tiempo;

    public Reparacion(String nombre, EstadoReparacion estado) {
        this.nombre = nombre;
        this.estado = estado;
        this.creacion = LocalDateTime.now();
        precio = 0;
        tiempo = 0;
    }
    
    
    public void cambiarEstado(String a){
        estado.cambiar(a);
    }
    
    public void precio(double a){
        if (this.precio!=0) {
        return;
        }
    
        precio = a;
    }

   
public String toString() {
    String precioString = (precio > 0) ? String.valueOf(precio) : "Precio no asignado";
    return String.format("| %-20s | %-20s | %-20s |%-20s |\n", nombre, estado.actual, creacion.format(DateTimeFormatter.ISO_DATE), precioString);
}

    
   
    
    
}
    


