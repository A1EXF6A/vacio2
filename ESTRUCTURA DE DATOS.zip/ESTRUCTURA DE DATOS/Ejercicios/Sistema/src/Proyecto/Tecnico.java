/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */
public class Tecnico extends  Persona{
    public SolicitudReparaciones reparacion = null;

    public Tecnico(String nombre, String apellido, String direccion, String telefono, String cedula, String contraseña, String usuario) {
        super(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
    }

    public void reparar(String a){
        reparacion.reparacion.cambiarEstado(a);
        reparacion.reparando = true;
    }
    
    public boolean recibirSolicitud(SolicitudReparaciones i){
        if(reparacion==null){
            reparacion = i;
            reparacion.reparando = true;
            return true;
        }
        return false;
    }
    
    public void asignarPrecio(double i){
        LocalDateTime a = LocalDateTime.now();
        reparacion.reparacion.fin = a;
        reparacion.reparacion.precio(i);
        reparacion.terminado = true;
        
    }
}
