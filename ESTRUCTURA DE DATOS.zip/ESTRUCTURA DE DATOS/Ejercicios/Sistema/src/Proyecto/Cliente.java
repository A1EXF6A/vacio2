
package Proyecto;


import java.util.LinkedList;

/**
 *
 * @author Anthony
 */
public class Cliente extends Persona {
    public LinkedList<Reparacion> reparaciones;

    public Cliente(String nombre, String apellido, String direccion, String telefono, String cedula, String contraseña, String usuario) {
        super(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
        this.reparaciones = new LinkedList<>();
        
    }
    
    public void realizarReparacion(Reparacion a){
        reparaciones.add(a);
    }
    
    public String toString(){
        return String.format("| %-20s | %-20s | %-20s |%-20d |\n",nombre,apellido,cedula,reparaciones.size());
    }
    
    public void eliminarReparacion(Reparacion reparacion) {
    reparaciones.remove(reparacion);
}

}
