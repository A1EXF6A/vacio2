/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


public class CentroReparacion {
    LinkedList<Cliente> clientes;
    LinkedList<Tecnico> tecnico;
    Queue<SolicitudReparaciones> solicitudes;
    
    public CentroReparacion(){
        clientes = new LinkedList<>();
        tecnico = new LinkedList<>();
        solicitudes = new LinkedList<>();
        
    }
    
    public void recibirSolicitud(SolicitudReparaciones i, Cliente a){
        solicitudes.offer(i);
        a.realizarReparacion(i.reparacion);
    }
    
    public void asignarSolicitudTecnico(){
        Tecnico tec = buscarTecnicoLibre();
        if(tec!=null){
            tec.recibirSolicitud(solicitudes.poll());
        }
    }
    
    public Tecnico buscarTecnicoLibre(){
        for(Tecnico a: tecnico){
            if(a.reparacion==null){
                return a;
            }
        }
        return null;
    }
    
    public void añadirCliente(Cliente i){
        clientes.add(i);
    }
    
    public void añadirTecnico(Tecnico I){
        tecnico.add(I);
    }
    
    public Object buscarUsario(int i,String j, String k){
        if(i==1){
            for(Cliente a: clientes){
                if(a.usuario.equalsIgnoreCase(j)&&a.contraseña.equalsIgnoreCase(k)){
                    return a;
                }
            }
        }else if(i==2){
            for(Tecnico a: tecnico){
                if(a.usuario.equalsIgnoreCase(j)&&a.contraseña.equalsIgnoreCase(k)){
                    return a;
                }
            }
        }else{
            System.out.println("Opcion incorrecta");
        }
        return null;
    }
    
    public void asignarReparacion(Tecnico i){
    if (!solicitudes.isEmpty()) { // Verifica si hay solicitudes pendientes
        SolicitudReparaciones solicitud = solicitudes.poll();
        if (solicitud != null && i.recibirSolicitud(solicitud)) {
            System.out.println("Reparación asignada a " + i.nombre);
        } else {
            System.out.println("El técnico está ocupado");
        }
    } else {
        System.out.println("No hay solicitudes pendientes para asignar");
    }
}

    
    public void mostrarMejoresClientes(){
        if(!verificarClientes()&&verificarMejoresClientes()){
            for(Cliente a: clientes){
                System.out.println(a.toString());
            }
        }
    }
    
    public boolean verificarClientes(){
        if(clientes.isEmpty()){
            System.out.println("No hay clientes");
            return true;
        }
        return false;
    }
    
    public boolean verificarMejoresClientes(){
        for(Cliente a: clientes){
            if(a.reparaciones.size()>=3){
                return true;
            }
        }
        return false;
    }
    public void verReparaciones(Cliente i){
        System.out.printf("| %-20s | %-20s | %-20s |%-20s |\n","NOMBRE","ESTADO","INGRESO","PRECIO");
        for(Reparacion a: i.reparaciones){
            System.out.println(a.toString());
        }
    }
    /*
    public void eliminarSolicitudReparacion(String nombreReparacion, Cliente cliente) {
    Iterator<SolicitudReparaciones> iterator = solicitudes.iterator();
    while (iterator.hasNext()) {
        SolicitudReparaciones solicitud = iterator.next();
        if (solicitud.reparacion.nombre.equalsIgnoreCase(nombreReparacion) && solicitud.cliente.equals(cliente)&&solicitud.terminado==false) {
            iterator.remove(); // Elimina la solicitud de la cola
            cliente.eliminarReparacion(solicitud.reparacion); // Elimina la reparación del cliente
            System.out.println("Solicitud de reparación eliminada con éxito.");
            return; // Sal del método después de eliminar la solicitud
        }
    }
    // Si no se encuentra la solicitud
    System.out.println("No se encontró ninguna solicitud de reparación con ese nombre para el cliente especificado.");
}*/
    public void eliminarSolicitudReparacion(Cliente cliente) {
    // Verificar si el cliente tiene reparaciones
    Scanner a = new Scanner(System.in);
    if (!cliente.reparaciones.isEmpty()) {
        // Mostrar las reparaciones del cliente enumeradas
        System.out.println("Reparaciones del cliente " + cliente.nombre + ":");
        for (int i = 0; i < cliente.reparaciones.size(); i++) {
            System.out.println((i + 1) + ". " + cliente.reparaciones.get(i).toString());
        }
        
        // Solicitar al usuario el número de la reparación que desea eliminar
        System.out.print("Ingrese el número de la reparación que desea eliminar: ");
        int opcion = a.nextInt();
        
        // Verificar si la opción ingresada es válida
        if (opcion >= 1 && opcion <= cliente.reparaciones.size()) {
            // Obtener la reparación seleccionada
            Reparacion reparacionSeleccionada = cliente.reparaciones.get(opcion - 1);
            
            // Eliminar la reparación del cliente
            cliente.eliminarReparacion(reparacionSeleccionada);
            
            // Eliminar la solicitud correspondiente del centro
            Iterator<SolicitudReparaciones> iterator = solicitudes.iterator();
            while (iterator.hasNext()) {
                SolicitudReparaciones solicitud = iterator.next();
                if (solicitud.reparacion.equals(reparacionSeleccionada) && solicitud.cliente.equals(cliente) && solicitud.terminado==false) {
                    iterator.remove(); // Elimina la solicitud de la cola
                    System.out.println("Solicitud de reparación eliminada con éxito.");
                    return; // Sal del método después de eliminar la solicitud
                }
            }
            // Si no se encuentra la solicitud
            System.out.println("No se encontró ninguna solicitud de reparación correspondiente para eliminar.");
        } else {
            System.out.println("Número de reparación no válido.");
        }
    } else {
        System.out.println("El cliente no tiene reparaciones pendientes.");
    }
}


    
    
}
