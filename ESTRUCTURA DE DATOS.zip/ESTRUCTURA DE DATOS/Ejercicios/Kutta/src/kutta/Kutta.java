/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kutta;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.BiFunction;

public class Kutta {

    public static List<Double> rungeKutta2ndOrder(BiFunction<Double, Double, Double> f, double y0, double x0, double xf, double h) {
        List<Double> xVals = new ArrayList<>();
        List<Double> yVals = new ArrayList<>();
        xVals.add(x0);
        yVals.add(y0);

        double x = x0;
        double y = y0;

        while (x < xf) {
            double k1 = h * f.apply(x, y);
            double k2 = h * f.apply(x + h, y + k1);
            y = y + 0.5 * (k1 + k2);
            x = x + h;
            xVals.add(x);
            yVals.add(y);
        }

        return yVals; // Assuming we want to return y values, we could also return xVals if needed
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar datos al usuario
        System.out.print("Ingrese la ecuación diferencial en términos de x y y (por ejemplo, (1/2)*(1 + x)*y^2): ");
        String equation = scanner.nextLine();

        System.out.print("Ingrese el valor inicial de y (y0): ");
        double y0 = scanner.nextDouble();

        System.out.print("Ingrese el valor inicial de x (x0): ");
        double x0 = scanner.nextDouble();

        System.out.print("Ingrese el valor final de x (xf): ");
        double xf = scanner.nextDouble();

        System.out.print("Ingrese el tamaño del paso (h): ");
        double h = scanner.nextDouble();

        // Definir la ecuación diferencial
        BiFunction<Double, Double, Double> f = (x, y) -> {
            String expression = equation.replaceAll("x", x.toString()).replaceAll("y", y.toString());
            return eval(expression);
        };

        // Resolver la ecuación diferencial
        List<Double> yVals = rungeKutta2ndOrder(f, y0, x0, xf, h);

        // Mostrar los resultados
        for (int i = 0; i < yVals.size(); i++) {
            double x = x0 + i * h;
            double y = yVals.get(i);
            System.out.printf("x = %.4f, y = %.4f%n", x, y);
        }
    }

    // Método para evaluar una expresión matemática (requiere Java 8 o superior)
    public static double eval(String expression) {
        try {
            return (double) new javax.script.ScriptEngineManager().getEngineByName("JavaScript").eval(expression);
        } catch (Exception e) {
            e.printStackTrace();
            return Double.NaN;
        }
    }
}

