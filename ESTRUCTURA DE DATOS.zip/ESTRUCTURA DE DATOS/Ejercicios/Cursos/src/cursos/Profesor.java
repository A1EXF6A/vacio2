/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cursos;

import java.time.LocalDate;
import java.time.Period;

/**
 *
 * @author HOME
 */
public class Profesor {
   
    String cedula;
    String nomApelli;
    LocalDate fechaIngreso; 
    Cursos[] lista;
    public Profesor(String cedula,String name){
        this.cedula=cedula;
        this.nomApelli = name;
        
    }
    
    public Profesor(){
        lista = new Cursos[3];
    }
    
    public boolean existe( Cursos i){
        for(Cursos a: lista){
            if(a.equals(i))
                return true;
        }
        return false;
    }
    
    public boolean lleno(){
        if(lista.length==3) return true;
        return false;
    }
    
    public boolean añadirCurso(Cursos i){
        if(existe(i)) return false;
        if(lleno()) return false;
        
        for (int j = 0; j < lista.length; j++) {
            if(lista[j]==null){
                lista[j]=i;
                return true;
            }
        }
        
        return false;
    }
    
    
}