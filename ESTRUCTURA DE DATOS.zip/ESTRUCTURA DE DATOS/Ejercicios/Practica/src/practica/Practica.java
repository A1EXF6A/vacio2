/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica;

/**
 *
 * @author HOME
 */
public class Practica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Nodo b = new Nodo("hola");
        Nodo n2 = new Nodo(147);
        Nodo n3 = new Nodo(false);
        
        b.enlazar(n2);
        b.siguiente().enlazar(n3);
        
        
        System.out.println(b.siguiente.siguiente.obtener().toString());
        
        
    }
    
}
