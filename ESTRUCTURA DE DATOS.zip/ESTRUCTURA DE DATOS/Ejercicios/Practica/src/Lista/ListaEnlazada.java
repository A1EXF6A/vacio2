/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista;

/**
 *
 * @author HOME
 */
public class ListaEnlazada {
    private Nodo cabeza = null;
    private int longitud = 0;
    private class Nodo{
        
        public Object libro;
        public Nodo siguiente = null;

        public Nodo(Object libro) {
            this.libro = libro;
        }
        
    }
    public void insertarPrincipio(Object libro){
        Nodo nodo = new Nodo(libro);
        nodo.siguiente = cabeza;
        cabeza = nodo;
        longitud++;
    }
    
    public void insertarFinal(Object l){
        Nodo nodo = new Nodo(l);
        if(cabeza == null){
            cabeza = nodo;
        }else{
            Nodo puntero = cabeza;
            while(puntero!=null){
                puntero = puntero.siguiente;
            }
            puntero.siguiente = nodo;
    }
        longitud++;
    }
    public void insertarDespues(int a, Object b){
        Nodo nodo = new Nodo(b);
        if(cabeza==null){
            cabeza = nodo;
        }else{
            Nodo puntero = cabeza;
            int cont = 0;
            while(cont<a&&puntero!=null){
                puntero = puntero.siguiente;
                cont++;
            }
            nodo.siguiente = puntero.siguiente;
            puntero.siguiente = nodo;
        }
        longitud++;
    }
    
    public Object obtener(int a){
        if(cabeza==null){
            return null;
        }else{
            Nodo puntero = cabeza;
            int cont = 0;
            while(cont<a&&puntero!=null){
                puntero = puntero.siguiente;
                cont++;
            }
            if(cont!=a){
                return null;
            }else{
                return puntero.libro;
            }
        }
    }
    public int contar(){
        return longitud;
    }
    
    public void eliminarPrimero(){
        
        if(cabeza!=null){
            Nodo a = cabeza;
            cabeza = cabeza.siguiente;
            a.siguiente = null;
            longitud--;
        }
    }
    public void eliminarUltimo(){
        if(cabeza!=null){
            if(cabeza.siguiente==null){
                cabeza =null;
            }else{
                Nodo puntero = cabeza;
                while(puntero.siguiente.siguiente!=null){
                    puntero = puntero.siguiente;
                }
                puntero.siguiente = null;
            }
        }
    }
    public void eliminarLibro(int n){
        if(cabeza==null){
           if(n==0){
               Nodo a = cabeza;
                cabeza = cabeza.siguiente;
                a.siguiente = null;
                longitud--;
           }else if(n<longitud){
               Nodo puntero = cabeza;
               int cont = 0;
               while(cont<(n-1)){
                   puntero = puntero.siguiente;
                   cont++;
               }
               Nodo temp = puntero.siguiente;
               puntero.siguiente = temp.siguiente;
               temp.siguiente = null;
               longitud--;
           }
        }
    }
}
