/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Nodos2;

import practica.Nodo;

/**
 *
 * @author HOME
 */
public class ListaEnlazada {
    Nodo cabeza;
    int size;
    
    public ListaEnlazada(){
        cabeza = null;
        size = 0;
    }
    
    public boolean vacia(){
        return (cabeza == null)?true:false;
    }
    
    public void addPrimero(Object o){
        if(cabeza==null){
            cabeza = new Nodo(o);
        }else{
            Nodo temporal = cabeza;
            Nodo nuevo = new Nodo(o);
            nuevo.enlazar(temporal);
            cabeza = nuevo;
        }
        size++;
    }
    public int size(){
        return size;
    }
    
    public Object obtener(int i){
        int cont = 0;
        Nodo n = cabeza;
        while (cont<i) {            
            n = n.siguiente();
            cont++;
        }
        return n.obtener();
    }
}
