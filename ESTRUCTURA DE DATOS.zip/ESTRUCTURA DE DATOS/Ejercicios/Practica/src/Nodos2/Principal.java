/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Nodos2;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
        int a = 5,b = 0;
        while(b<a){
            System.out.println(b);
            b++;
            
        }
         
         
    }
}
