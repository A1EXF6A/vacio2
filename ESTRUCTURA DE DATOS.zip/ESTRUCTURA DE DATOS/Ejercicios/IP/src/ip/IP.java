/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ip;

/**
 *
 * @author HOME
 */
import java.util.Scanner;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class IP {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String ipAddress;

        do {
            System.out.print("Ingrese una dirección IP (o 'salir' para terminar): ");
            ipAddress = scanner.nextLine();

            if (!ipAddress.equalsIgnoreCase("salir")) {
                try {
                    InetAddress inetAddress = InetAddress.getByName(ipAddress);
                    if (inetAddress.isAnyLocalAddress() || inetAddress.isLoopbackAddress()) {
                        System.out.println(ipAddress + " es una dirección IP reservada.");
                    } else if (inetAddress.isLinkLocalAddress() || inetAddress.isSiteLocalAddress()) {
                        System.out.println(ipAddress + " es una dirección IP privada.");
                    } else {
                        System.out.println(ipAddress + " es una dirección IP pública.");
                    }

                    char ipClass = getIPClass(ipAddress);
                    System.out.println("Pertenece a la clase " + ipClass);
                } catch (UnknownHostException e) {
                    System.out.println("No se pudo resolver la dirección IP: " + ipAddress);
                }
                System.out.println();
            }
        } while (!ipAddress.equalsIgnoreCase("salir"));

        scanner.close();
    }

    public static char getIPClass(String ipAddress) {
        String[] octets = ipAddress.split("\\.");
        int firstOctet = Integer.parseInt(octets[0]);

        if (firstOctet >= 1 && firstOctet <= 126) {
            return 'A';
        } else if (firstOctet >= 128 && firstOctet <= 191) {
            return 'B';
        } else if (firstOctet >= 192 && firstOctet <= 223) {
            return 'C';
        } else if (firstOctet >= 224 && firstOctet <= 239) {
            return 'D';
        } else {
            return 'E';
        }
    }
}