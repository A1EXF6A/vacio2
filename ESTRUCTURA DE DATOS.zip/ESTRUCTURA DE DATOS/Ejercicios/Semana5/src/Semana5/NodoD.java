/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana5;

/**
 *
 * @author HOME
 */
public class NodoD<T extends Comparable<T>> implements Comparable<NodoD<T>> {
    public T dato;
    public NodoD<T> siguiente;
    public NodoD<T> anterior;

    public NodoD(T dato, NodoD<T> siguiente, NodoD<T> anterior) {
        this.dato = dato;
        this.siguiente = siguiente;
        this.anterior = anterior;
    }

    @Override
    public int compareTo(NodoD<T> otroNodo) {
        // Comparar los datos de los nodos
        return this.dato.compareTo(otroNodo.dato);
    }
}
