/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validaciones;

/**
 *
 * @author User
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validacion {
    ////////////NOMBRE///////////////////////////////////////
    public static boolean letras(String texto) {
        if (!texto.matches("[a-zA-Z]+")) {
            //System.out.println("Error: El nombre o apellido debe contener solo letras.");
            return false;
        }
        return true;
    }

    ////////////DIRECCION///////////////////////////////////////
    public static boolean validarDireccion(String direccion) {
        if (!direccion.matches("[a-zA-Z0-9\\s]+")) {
            System.out.println("Error: La dirección debe contener solo letras, números y espacios.");
            return false;
        }
        return true;
    }

    

    ////////////CEDULA///////////////////////////////////////
    public static boolean validarCedula(String cedula) {
        // Verificar que la cédula tenga 10 dígitos
        if (cedula.length() != 10) {
            System.out.println("Error: La cédula debe tener 10 dígitos.");
            return false;
        }

        int provincia = Integer.parseInt(cedula.substring(0, 2));
        if (provincia < 1 || provincia > 24) {
            System.out.println("Error: El código de provincia en la cédula no es válido.");
            return false;
        }

        int tercerDigito = Integer.parseInt(cedula.substring(2, 3));
        if (tercerDigito >= 6) {
            System.out.println("Error: El tercer dígito de la cédula no es válido.");
            return false;
        }

        int[] coeficientes = {2, 1, 2, 1, 2, 1, 2, 1, 2};
        int suma = 0;
        int digitoVerificador = Integer.parseInt(cedula.substring(9));
        for (int i = 0; i < 9; i++) {
            int digito = Integer.parseInt(cedula.substring(i, i + 1));
            int producto = digito * coeficientes[i];
            suma += (producto >= 10) ? producto - 9 : producto;
        }
        int residuo = suma % 10;
        int resultado = (residuo == 0) ? 0 : 10 - residuo;
        if (resultado != digitoVerificador) {
            System.out.println("Error: El último dígito de la cédula no es válido.");
            return false;
        }

        return true;
    }
    public static boolean validarTelefonoCelularEcuador(String telefono) {
    // Verificar que el teléfono celular tenga un formato válido para Ecuador
    if (!telefono.matches("09\\d{8}")) {
        System.out.println("Error: El número de teléfono celular de Ecuador debe tener un formato válido.");
        return false;
    }
    return true;
}
}
