package Consola;

import Proyecto.CentroReparacion;
import Proyecto.Cliente;
import Proyecto.EstadoReparacion;
import Proyecto.Reparacion;
import Proyecto.SolicitudReparaciones;
import Proyecto.Tecnico;
import java.util.InputMismatchException;
import java.util.Scanner;
import validaciones.Validacion;

public class Login {
    CentroReparacion centro = new CentroReparacion();
    
    Scanner a = new Scanner(System.in);
    
    public void inicio(){
        int i;
        do {
            System.out.println("Seleccione la forma de inicio\n1. Cliente\n2. Técnico\n3. Crear cuenta\n0. Salir");
            try {
            i = a.nextInt();
            } catch (InputMismatchException e) {
            System.out.println("Ingreso inválido. Por favor, ingrese un número.");
            a.nextLine(); // Limpiar el buffer del Scanner
            i = -1; // Establecer i en un valor inválido para que el bucle continúe
        }
            switch (i) {
                case 1:
                    Cliente j = (Cliente) entrada(i);
                    if(j==null){
                        System.out.println("Usuario no encontrado");
                        break;
                    }
                    opcionesCliente(j);
                    break;
                case 2:
                    Tecnico k = (Tecnico) entrada(i);
                    if(k==null){
                        System.out.println("Usuario no encontrado");
                        break;
                    }
                    opcionesTecnico(k);
                    break;
                case 3:
                    crearCuenta();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (i != 0);
    }
    
    public Object entrada(int k){
        String i, j;
        System.out.println("Ingrese su usuario: ");
        a.nextLine(); // Consumir la nueva línea en blanco
        i = a.nextLine();
        System.out.println("Ingrese su contraseña: ");
        j = a.nextLine();
        Object c = centro.buscarUsario(k, i, j);
        return c;
    }
    
    public void crearCuenta(){
        
        int i;
        
        do {
            System.out.println("Elija cómo quiere crear la cuenta\n1. Cliente\n2. Técnico\n0. Salir");
            try {
            i = a.nextInt();
            } catch (InputMismatchException e) {
            System.out.println("Ingreso inválido. Por favor, ingrese un número.");
            a.nextLine(); // Limpiar el buffer del Scanner
            i = -1;} // Consumir la nueva línea en blanco
        String nombre, apellido, direccion = null, telefono = null, cedula = null, contraseña, usuario;
        switch (i) {
            case 1:
                System.out.println("Nombre: "); 
                nombre = a.nextLine();
                while (!Validacion.letras(nombre)) {
                    System.out.println("Error: El nombre debe contener solo letras.");
                    System.out.println("Nombre: "); 
                    nombre = a.nextLine();
                }
                System.out.println("Apellido: "); 
                apellido = a.nextLine();
                while (!Validacion.letras(apellido)) {
                    System.out.println("Error: El apellido debe contener solo letras.");
                    System.out.println("Apellido: "); 
                    apellido = a.nextLine();
                }
                System.out.println("Dirección: "); 
                direccion = a.nextLine();
                while (!Validacion.validarDireccion(direccion)) {
                    System.out.println("Error: La dirección debe contener solo letras, números y espacios.");
                    System.out.println("Dirección: "); 
                    direccion = a.nextLine();
                }
                System.out.println("Cédula: "); 
                cedula = a.nextLine();
                while (!Validacion.validarCedula(cedula)) {
                    System.out.println("Error: La cédula no es válida.");
                    System.out.println("Cédula: "); 
                    cedula = a.nextLine();
                }
                System.out.println("Teléfono: "); 
                telefono = a.nextLine();
                while (!Validacion.validarTelefonoCelularEcuador(telefono)) {
                    System.out.println("Error: El número de teléfono celular de Ecuador debe tener un formato válido.");
                    System.out.println("Teléfono: "); 
                    telefono = a.nextLine();
                }
                System.out.println("Usuario: "); 
                usuario = a.nextLine();
                System.out.println("Contraseña: "); 
                contraseña = a.nextLine();
                Cliente c = new Cliente(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
                centro.añadirCliente(c);
                break;
            case 2:
                System.out.println("Nombre: "); 
                nombre = a.nextLine();
                while (!Validacion.letras(nombre)) {
                    System.out.println("Error: El nombre debe contener solo letras.");
                    System.out.println("Nombre: "); 
                    nombre = a.nextLine();
                }
                System.out.println("Apellido: "); 
                apellido = a.nextLine();
                while (!Validacion.letras(apellido)) {
                    System.out.println("Error: El apellido debe contener solo letras.");
                    System.out.println("Apellido: "); 
                    apellido = a.nextLine();
                }
                System.out.println("Usuario: "); 
                usuario = a.nextLine();
                System.out.println("Contraseña: "); 
                contraseña = a.nextLine();
                Tecnico t = new Tecnico(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
                centro.añadirTecnico(t);
                break;
            default:
                //System.out.println("Opción no válida. Intente de nuevo.");
                break;
        }
        } while (i!=0);
    }

    
    public void opcionesCliente(Cliente u){
        int i;
        do {
            System.out.println("Menu cliente\n1. Ingresar reparacion\n2. Ver reparaciones\n3. Eliminar reparacion\n0. Salir");
        
            try {
            i = a.nextInt();
            } catch (InputMismatchException e) {
            System.out.println("Ingreso inválido. Por favor, ingrese un número.");
            a.nextLine(); // Limpiar el buffer del Scanner
            i = -1;
            }
            switch (i) {
                case 1:
                    ingresarReparacion(u);
                    break;
                case 2:
                    centro.verReparaciones(u);
                    break;
                case 3:
                    centro.eliminarSolicitudReparacion(u);
                    break;
                case 0:
                    System.out.println("Saliendo del menu cliente");
                    break;
                default:
                //System.out.println("Opción no válida. Intente de nuevo.");
                break;
            }
        } while (i!=0);
    }
    
    void ingresarReparacion(Cliente i){
        String nombre;
        System.out.println("Nombre: "); 
        a.nextLine(); // Consumir la nueva línea en blanco
        nombre = a.nextLine();

        // Por defecto, el estado es "Ingresada"
        String estado = EstadoReparacion.INGRESADA;
        EstadoReparacion es = new EstadoReparacion(estado);
        Reparacion re = new Reparacion(nombre, es);
        //i.realizarReparacion(re);
        SolicitudReparaciones sol = new SolicitudReparaciones(i, re);
        centro.recibirSolicitud(sol, i);  
    }
    

    
    
    
  public void opcionesTecnico(Tecnico b) {
    int i;
    double pre;
    do {
        System.out.println("Menu técnico\n1. Recibir solicitud\n2. Reparar\n3. Asignar precio\n4. Ver mejores clientes\n5. Mostrar información y editar cliente\n6. Salir del menú técnico");
        String es;
        try {
            i = a.nextInt();
            } catch (InputMismatchException e) {
            System.out.println("Ingreso inválido. Por favor, ingrese un número.");
            a.nextLine(); // Limpiar el buffer del Scanner
            i = -1;}
        switch (i) {
            case 1:
                // Recibir solicitud
                if (b.getReparacion() != null) {
                    System.out.println("Ya tienes una solicitud de reparación asignada.");
                } else {
                    centro.asignarReparacion(b);
                    System.out.println("¿Desea recibir otra solicitud? (si/no)");
                    a.nextLine(); // Consumir la nueva línea en blanco
                    String respuesta = a.nextLine();
                    if (respuesta.equalsIgnoreCase("no")) {
                        break;
                    }
                }
                break;
            case 2:
                // Reparar
                int opcionEstado;
                if (b.getReparacion() == null) {
                    System.out.println("No tienes ninguna solicitud de reparación asignada.");
                } else {
                    a.nextLine(); // Consumir la nueva línea en blanco
                    System.out.println("Seleccione el nuevo estado:");
                    System.out.println("1. Ingresada");
                    System.out.println("2. En proceso");
                    System.out.println("3. Solucionada");
                    System.out.println("4. Sin solución");
                    try {
                        opcionEstado = a.nextInt();
                        } catch (InputMismatchException e) {
                        System.out.println("Ingreso inválido. Por favor, ingrese un número.");
                        a.nextLine(); // Limpiar el buffer del Scanner
                        opcionEstado = -1;}
                    switch (opcionEstado) {
                        case 1:
                            es = EstadoReparacion.INGRESADA;
                            break;
                        case 2:
                            es = EstadoReparacion.EN_REVISION;
                            break;
                        case 3:
                            es = EstadoReparacion.SOLUCIONADA;
                            break;
                        case 4:
                            es = EstadoReparacion.SIN_SOLUCION;
                            break;
                        default:
                            //System.out.println("Opción no válida. Intente de nuevo.");
                            continue; // Volver al inicio del bucle do-while
                    }
                    b.reparar(es);
                }
                break;
            case 3:
                // Asignar precio
                System.out.println("Asignar precio a la reparación:");
                pre = a.nextDouble();
                b.asignarPrecio(pre);
                break;
            case 4:
                // Ver mejores clientes
                centro.mostrarMejoresClientes();
                break;
            case 5:
                // Mostrar información y editar cliente
                mostrarInformacionYEditarCliente();
                break;
            case 6:
                System.out.println("Saliendo del menú técnico");
                break;
            default:
                //System.out.println("Opción no válida. Intente de nuevo.");
                break;
        }
    } while (i != 6);
}




private void mostrarInformacionYEditarCliente() {
    System.out.println("Ingrese el usuario del cliente del que desea ver y editar la información:");
    a.nextLine(); // Consumir la nueva línea en blanco
    String usuarioCliente = a.nextLine();
    Cliente cliente = centro.buscarClientePorUsuario(usuarioCliente);
    int opcion;
    if (cliente != null) {
        // Mostrar información del cliente
        System.out.println("Información del cliente:");
        System.out.println("1. Nombre: " + cliente.getNombre());
        System.out.println("2. Apellido: " + cliente.getApellido());
        System.out.println("3. Dirección: " + cliente.getDireccion());
        System.out.println("4. Teléfono: " + cliente.getTelefono());
        System.out.println("5. Cédula: " + cliente.getCedula());
        // Proporcionar opciones para editar la información
        System.out.println("Seleccione el número del campo que desea editar (1-5) o ingrese 0 para salir:");
        try {
            opcion = a.nextInt();
            } catch (InputMismatchException e) {
            System.out.println("Ingreso inválido. Por favor, ingrese un número.");
            a.nextLine(); // Limpiar el buffer del Scanner
            opcion = -1;}
        a.nextLine(); // Consumir el salto de línea
        switch (opcion) {
            case 1:
                System.out.println("Ingrese el nuevo nombre:");
                String nuevoNombre = a.nextLine();
                cliente.setNombre(nuevoNombre);
                System.out.println("Nombre actualizado con éxito.");
                break;
            case 2:
                System.out.println("Ingrese el nuevo apellido:");
                String nuevoApellido = a.nextLine();
                cliente.setApellido(nuevoApellido);
                System.out.println("Apellido actualizado con éxito.");
                break;
            case 3:
                System.out.println("Ingrese la nueva dirección:");
                String nuevaDireccion = a.nextLine();
                cliente.setDireccion(nuevaDireccion);
                System.out.println("Dirección actualizada con éxito.");
                break;
            case 4:
                System.out.println("Ingrese el nuevo teléfono:");
                String nuevoTelefono = a.nextLine();
                cliente.setTelefono(nuevoTelefono);
                System.out.println("Teléfono actualizado con éxito.");
                break;
            case 5:
                System.out.println("Ingrese la nueva cédula:");
                String nuevaCedula = a.nextLine();
                cliente.setCedula(nuevaCedula);
                System.out.println("Cédula actualizada con éxito.");
                break;
            case 0:
                System.out.println("Saliendo...");
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    } else {
        System.out.println("No se encontró ningún cliente con ese usuario.");
    }
}

}
