import Proyecto.CentroReparacion;
import Proyecto.Cliente;
import Proyecto.Tecnico;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginGUI extends JFrame {
    private CentroReparacion centro = new CentroReparacion();

    private JTextField usuarioField;
    private JPasswordField contraseñaField;
    private JButton iniciarSesionButton;
    private JComboBox<String> tipoCuentaComboBox;

    public LoginGUI() {
        setTitle("Inicio de Sesión");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelCentro = new JPanel(new GridLayout(4, 2));

        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioField = new JTextField();
        JLabel contraseñaLabel = new JLabel("Contraseña:");
        contraseñaField = new JPasswordField();
        JLabel tipoCuentaLabel = new JLabel("Tipo de Cuenta:");
        String[] tiposCuenta = {"Cliente", "Técnico"};
        tipoCuentaComboBox = new JComboBox<>(tiposCuenta);

        panelCentro.add(usuarioLabel);
        panelCentro.add(usuarioField);
        panelCentro.add(contraseñaLabel);
        panelCentro.add(contraseñaField);
        panelCentro.add(tipoCuentaLabel);
        panelCentro.add(tipoCuentaComboBox);

        iniciarSesionButton = new JButton("Iniciar Sesión");
        iniciarSesionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarSesion();
            }
        });

        panelCentro.add(iniciarSesionButton);
        add(panelCentro, BorderLayout.CENTER);
    }
    

    private void iniciarSesion() {
        String usuario = usuarioField.getText();
        String contraseña = new String(contraseñaField.getPassword());
        String tipoCuenta = (String) tipoCuentaComboBox.getSelectedItem();

        // Verificar si los campos de usuario y contraseña están vacíos
        if (usuario.isEmpty() || contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        if (tipoCuenta.equals("Cliente")) {
            if (!validarUsuarioCliente(usuario, contraseña)) {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos");
                return;
            }
            JOptionPane.showMessageDialog(this, "Iniciando sesión como cliente");
            mostrarOpcionesCliente();
        } else if (tipoCuenta.equals("Técnico")) {
            if (!validarUsuarioTecnico(usuario, contraseña)) {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos");
                return;
            }
            JOptionPane.showMessageDialog(this, "Iniciando sesión como técnico");
            // Aquí podrías implementar la lógica para iniciar sesión como técnico
            // por ejemplo, llamando a un método del objeto CentroReparacion
            // para iniciar sesión como técnico.
            // centro.iniciarSesionTecnico(usuario, contraseña);
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un tipo de cuenta válido");
        }
    }

    private boolean validarUsuarioCliente(String usuario, String contraseña) {
        Cliente cliente = centro.buscarClientePorUsuario(usuario);
        return cliente != null && cliente.getContraseña().equals(contraseña);
    }

    private boolean validarUsuarioTecnico(String usuario, String contraseña) {
        Tecnico tecnico = centro.buscarTecnicoPorUsuario(usuario);
        return tecnico != null && tecnico.getContraseña().equals(contraseña);
    }

    private void mostrarOpcionesCliente() {
        // Implementa aquí la lógica para mostrar las opciones del cliente
        // Por ejemplo, abre una nueva ventana con las opciones disponibles para el cliente.
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                LoginGUI loginGUI = new LoginGUI();
                loginGUI.setVisible(true);
            }
        });
    }
}
