
package Proyecto;


import java.util.LinkedList;

/**
 *
 * @author Anthony
 */
public class Cliente extends Persona {
    public LinkedList<Reparacion> reparaciones;

    public Cliente(String nombre, String apellido, String direccion, String telefono, String cedula, String contraseña, String usuario) {
        super(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
        this.reparaciones = new LinkedList<>();
        
    }
    
    public void realizarReparacion(Reparacion a){
        reparaciones.add(a);
    }
    
    public String toString(){
        return String.format("| %-20s | %-20s | %-20s |%-20d |\n",nombre,apellido,cedula,reparaciones.size());
    }
    
    public void eliminarReparacion(Reparacion reparacion) {
    reparaciones.remove(reparacion);
}

    public LinkedList<Reparacion> getReparaciones() {
        return reparaciones;
    }

    public void setReparaciones(LinkedList<Reparacion> reparaciones) {
        this.reparaciones = reparaciones;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

}
