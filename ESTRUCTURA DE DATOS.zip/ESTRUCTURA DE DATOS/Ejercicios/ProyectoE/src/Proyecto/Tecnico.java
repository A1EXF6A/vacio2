/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */
public class Tecnico extends  Persona{
    public SolicitudReparaciones reparacion = null;
public Tecnico(String nombre, String apellido, String direccion, String telefono, String cedula, String contraseña, String usuario) {
    super(nombre, apellido, direccion, telefono, cedula, contraseña, usuario);
}


   

    public void reparar(String a){
    if (reparacion != null) {
        reparacion.reparacion.cambiarEstado(a);
        reparacion.reparando = true;
    } else {
        System.out.println("No hay solicitud de reparación asignada al técnico.");
    }
}

    
    public boolean recibirSolicitud(SolicitudReparaciones i){
        if(reparacion==null){
            reparacion = i;
            reparacion.reparando = true;
            return true;
        }
        return false;
    }
    
   public void asignarPrecio(double precio) {
    if (reparacion != null && (reparacion.getReparacion().getEstado().equals(EstadoReparacion.SOLUCIONADA) || reparacion.getReparacion().getEstado().equals(EstadoReparacion.SIN_SOLUCION))) {
        reparacion.getReparacion().setPrecio(precio);
        System.out.println("Precio asignado correctamente: " + precio);
    } else {
        System.out.println("No tienes una reparación solucionada o sin solución asignada.");
    }
}


    public SolicitudReparaciones getReparacion() {
        return reparacion;
    }

    public void setReparacion(SolicitudReparaciones reparacion) {
        this.reparacion = reparacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
}
