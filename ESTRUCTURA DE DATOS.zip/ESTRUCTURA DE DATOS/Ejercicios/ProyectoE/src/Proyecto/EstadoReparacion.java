package Proyecto;

public class EstadoReparacion {
    public static final String INGRESADA = "Ingresada";
    public static final String EN_REVISION = "En revisión";
    public static final String SOLUCIONADA = "Solucionada";
    public static final String SIN_SOLUCION = "Sin solución";

    public String actual;

    public EstadoReparacion(String actual) {
        this.actual = actual;
    }

    public String getActual() {
        return actual;
    }

    public void setActual(String actual) {
        this.actual = actual;
    }
    
    public void cambiar(String nuevoEstado) {
        this.actual = nuevoEstado;
    }

    public static String getINGRESADA() {
        return INGRESADA;
    }

    public static String getEN_REVISION() {
        return EN_REVISION;
    }

    public static String getSOLUCIONADA() {
        return SOLUCIONADA;
    }

    public static String getSIN_SOLUCION() {
        return SIN_SOLUCION;
    }
    
}

