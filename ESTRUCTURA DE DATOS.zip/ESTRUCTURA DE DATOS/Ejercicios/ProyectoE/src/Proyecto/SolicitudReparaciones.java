/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

/**
 *
 * @author HOME
 */
public class SolicitudReparaciones {
    public Cliente cliente;
    public Reparacion reparacion;
    public boolean reparando;
    public boolean terminado;

    public SolicitudReparaciones(Cliente cliente, Reparacion reparacion) {
        this.cliente = cliente;
        this.reparacion = reparacion;
        this.reparando = false;
        this.terminado = false;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Reparacion getReparacion() {
        return reparacion;
    }

    public void setReparacion(Reparacion reparacion) {
        this.reparacion = reparacion;
    }

    public boolean isReparando() {
        return reparando;
    }

    public void setReparando(boolean reparando) {
        this.reparando = reparando;
    }

    public boolean isTerminado() {
        return terminado;
    }

    public void setTerminado(boolean terminado) {
        this.terminado = terminado;
    }
    
    
    
}

    
    

