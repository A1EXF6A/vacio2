package Proyecto;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class CentroReparacion {
    LinkedList<Cliente> clientes;
    LinkedList<Tecnico> tecnicos;
    Queue<SolicitudReparaciones> solicitudes;

    public CentroReparacion() {
        clientes = new LinkedList<>();
        tecnicos = new LinkedList<>();
        solicitudes = new LinkedList<>();
    }

    public Cliente buscarClientePorUsuario(String usuario) {
        for (Cliente cliente : clientes) {
            if (cliente.getUsuario().equals(usuario)) {
                return cliente;
            }
        }
        return null;
    }

    public Tecnico buscarTecnicoPorUsuario(String usuario) {
        for (Tecnico tecnico : tecnicos) {
            if (tecnico.getUsuario().equals(usuario)) {
                return tecnico;
            }
        }
        return null;
    }

    public void eliminarSolicitudReparacion(Cliente cliente) {
        Scanner scanner = new Scanner(System.in);
        if (!cliente.reparaciones.isEmpty()) {
            System.out.println("Reparaciones del cliente " + cliente.getNombre() + ":");
            for (int i = 0; i < cliente.reparaciones.size(); i++) {
                System.out.println((i + 1) + ". " + cliente.reparaciones.get(i).toString());
            }

            System.out.print("Ingrese el número de la reparación que desea eliminar: ");
            int opcion = scanner.nextInt();

            if (opcion >= 1 && opcion <= cliente.reparaciones.size()) {
                Reparacion reparacionSeleccionada = cliente.reparaciones.get(opcion - 1);
                cliente.eliminarReparacion(reparacionSeleccionada);

                Iterator<SolicitudReparaciones> iterator = solicitudes.iterator();
                while (iterator.hasNext()) {
                    SolicitudReparaciones solicitud = iterator.next();
                    if (solicitud.reparacion.equals(reparacionSeleccionada) && solicitud.cliente.equals(cliente) && !solicitud.terminado) {
                        iterator.remove();
                        System.out.println("Solicitud de reparación eliminada con éxito.");
                        return;
                    }
                }
                System.out.println("No se encontró ninguna solicitud de reparación correspondiente para eliminar.");
            } else {
                System.out.println("Número de reparación no válido.");
            }
        } else {
            System.out.println("El cliente no tiene reparaciones pendientes.");
        }
    }

    
    
    public void recibirSolicitud(SolicitudReparaciones i, Cliente a){
        solicitudes.offer(i);
        a.realizarReparacion(i.reparacion);
    }
    
    public void asignarSolicitudTecnico(){
        Tecnico tec = buscarTecnicoLibre();
        if(tec!=null){
            tec.recibirSolicitud(solicitudes.poll());
        }
    }
    
    public Tecnico buscarTecnicoLibre(){
        for(Tecnico a: tecnicos){
            if(a.reparacion==null){
                return a;
            }
        }
        return null;
    }
    
    public void añadirCliente(Cliente i){
        clientes.add(i);
    }
    
    public void añadirTecnico(Tecnico I){
        tecnicos.add(I);
    }
    
    public Object buscarUsario(int i,String j, String k){
        if(i==1){
            for(Cliente a: clientes){
                if(a.usuario.equalsIgnoreCase(j)&&a.contraseña.equalsIgnoreCase(k)){
                    return a;
                }
            }
        }else if(i==2){
            for(Tecnico a: tecnicos){
                if(a.usuario.equalsIgnoreCase(j)&&a.contraseña.equalsIgnoreCase(k)){
                    return a;
                }
            }
        }else{
            System.out.println("Opcion incorrecta");
        }
        return null;
    }
    
    public void asignarReparacion(Tecnico i){
    if (!solicitudes.isEmpty()) { // Verifica si hay solicitudes pendientes
        SolicitudReparaciones solicitud = solicitudes.poll();
        if (solicitud != null && i.recibirSolicitud(solicitud)) {
            System.out.println("Reparación asignada a " + i.nombre);
        } else {
            System.out.println("El técnico está ocupado");
        }
    } else {
        System.out.println("No hay solicitudes pendientes para asignar");
    }
}

    
    public void mostrarMejoresClientes(){
    if (!verificarClientes() && verificarMejoresClientes()) {
        System.out.println("Lista de mejores clientes:");
        for (Cliente cliente : clientes) {
            if (cliente.reparaciones.size() >= 3) {
                System.out.println(cliente.toString());
            }
        }
    }
}

    
    public boolean verificarClientes(){
        if(clientes.isEmpty()){
            System.out.println("No hay clientes");
            return true;
        }
        return false;
    }
    
    public boolean verificarMejoresClientes(){
        for(Cliente a: clientes){
            if(a.reparaciones.size()>=3){
                return true;
            }
        }
        return false;
    }
    public void verReparaciones(Cliente i){
        System.out.printf("| %-20s | %-20s | %-20s |%-20s |\n","NOMBRE","ESTADO","INGRESO","PRECIO");
        for(Reparacion a: i.reparaciones){
            System.out.println(a.toString());
        }
    
    }
    
    
}
