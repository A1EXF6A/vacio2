/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

public class Curso {
    String nombre;
    int horas;
    Estudiante[] estudiantes;
    Profesor docente;
    int cantidadEstudiantes;

    public Curso(String nombre, int horas, Profesor docente, int cupo) {
        this.nombre = nombre;
        this.horas = horas;
        this.docente = docente;
        this.estudiantes = new Estudiante[cupo];
        this.cantidadEstudiantes = 0;
        docente.agregarCurso(this);
    }

    public void matricular(Estudiante a) {
    if (!Verificacion(a)) {
        if (cantidadEstudiantes < estudiantes.length) {
            estudiantes[cantidadEstudiantes] = a;
            cantidadEstudiantes++;
            a.agregarCurso(this); 
            asignarNota(a, 0);
        } else {
            System.out.println("No hay cupo disponible para matricular al estudiante " + a.getNombreCompleto());
        }
    } else {
        System.out.println("El estudiante " + a.getNombreCompleto() + " ya está matriculado en este curso.");
    }
}

    public boolean Verificacion(Estudiante a) {
        for (int i = 0; i < cantidadEstudiantes; i++) {
            if (estudiantes[i].getCedula().equals(a.getCedula())) {
                return true;
            }
        }
        return false;
    }

    public void asignarNota(Estudiante estudiante, float nota) {
        estudiante.asignarNota(this, nota);
    }

    public void ReporteInscritos() {
        System.out.println("Estudiantes inscritos en el curso " + nombre + ":");
        for (int i = 0; i < cantidadEstudiantes; i++) {
            System.out.println(estudiantes[i].toString());
        }
    }
    
    public String toString(){
        return "Curso: "+this.nombre+" Horas: "+this.horas+" Profesor: "+docente.Nombre1+" Estudiantes: "+cantidadEstudiantes;
    }
}
