/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
public class Trabajador extends Persona {
    float salario;

    public Trabajador(float salario, String cedula, String Nombre1, String Nombre2, String Apellido1, String Apellido2, String F_nacimiento) {
        super(cedula, Nombre1, Apellido1, F_nacimiento);
        this.salario = salario;
    }

    @Override
    public String toString() {
        return super.toString() + " Salario: " + salario;
    }
}
