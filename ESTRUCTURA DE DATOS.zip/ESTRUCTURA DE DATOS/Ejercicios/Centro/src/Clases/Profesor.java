/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
public class Profesor extends Trabajador {
    Curso[] cursos;
    String añosExperiencia;
    int cantidadCursos;

    public Profesor(float salario, String cedula, String Nombre1, String Nombre2, String Apellido1, String Apellido2, String F_nacimiento, String añosExperiencia) {
        super(salario, cedula, Nombre1, Nombre2, Apellido1, Apellido2, F_nacimiento);
        this.cursos = new Curso[10]; // Tamaño arbitrario
        this.añosExperiencia = añosExperiencia;
        this.cantidadCursos = 0;
    }

    @Override
    public String toString() {
        return super.toString() + " Años de Experiencia: " + añosExperiencia;
    }

    public void agregarCurso(Curso curso) {
        cursos[cantidadCursos] = curso;
        cantidadCursos++;
    }
}