/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
public class Gestor {
    Curso[] cursos;
    Persona[] personas;
    int cantidadCursos;
    int cantidadPersonas;

    public Gestor() {
        cursos = new Curso[10]; 
        personas = new Persona[10];
        cantidadCursos = 0;
        cantidadPersonas = 0;
    }

    public void mostrarDatosCursos() {
        System.out.println("Datos de los cursos:");
        for (int i = 0; i < cantidadCursos; i++) {
            System.out.println(cursos[i].toString());
        }
    }

    public void hacerReporteInscritos() {
        System.out.println("Reporte de inscritos:");
        for (int i = 0; i < cantidadCursos; i++) {
            cursos[i].ReporteInscritos();
        }
    }

    public void hacerReporteProfesores() {
        System.out.println("Reporte de profesores:");
        for (int i = 0; i < cantidadPersonas; i++) {
            if (personas[i] instanceof Profesor) {
                System.out.println(personas[i].toString());
            }
        }
    }

    public void hacerReporteEstudiantes() {
        System.out.println("Reporte de estudiantes:");
        for (int i = 0; i < cantidadPersonas; i++) {
            if (personas[i] instanceof Estudiante) {
                System.out.println(personas[i].toString());
            }
        }
    }

    public void agregarCurso(Curso curso) {
        cursos[cantidadCursos] = curso;
        cantidadCursos++;
    }

    public void matricularEstudiante(Estudiante estudiante, Curso curso) {
        curso.matricular(estudiante);
    }

    public void agregarPersona(Persona persona) {
        personas[cantidadPersonas] = persona;
        cantidadPersonas++;
    }
    public void mostrarPromedioNotasEstudiante(Estudiante estudiante) {
    float promedio = 0;
    int totalCursos = estudiante.cantidadCursos;

    System.out.println("Promedio de notas para el estudiante " + estudiante.getNombreCompleto() + ":");
    for (int i = 0; i < totalCursos; i++) {
        Curso curso = estudiante.cursos[i];
        Nota nota = estudiante.notas[i];
        if (curso != null && nota != null) {
            promedio += nota.nota;
            System.out.println(curso.nombre + " - Nota: " + nota.nota);
        } else {
            System.out.println("Curso no encontrado o sin nota asignada");
        }
    }

    if (totalCursos > 0) {
        promedio /= totalCursos;
    }
    System.out.println("Promedio: " + promedio);
}

    
    public void asignarNotaEstudiante(Estudiante estudiante, Curso curso, float nota) {
        curso.asignarNota(estudiante, nota);
    }
}