/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
public class Estudiante extends Persona {
    String direccion;
    Curso[] cursos;
    Nota[] notas;
    int cantidadCursos;

    public Estudiante(String direccion, String cedula, String Nombre1, String Nombre2, String Apellido1, String Apellido2, String F_nacimiento) {
        super(cedula, Nombre1, Apellido1, F_nacimiento);
        this.direccion = direccion;
        this.cursos = new Curso[10];
        this.notas = new Nota[10];
        this.cantidadCursos = 0;
    }

    @Override
    public String toString() {
        return super.toString() + " Direccion: " + direccion;
    }

   public void asignarNota(Curso curso, float nota) {
    for (int i = 0; i < cantidadCursos; i++) {
        if (cursos[i].equals(curso)) {
            if (cantidadCursos < cursos.length) {
                Nota notaAsignada = new Nota(nota, curso);
                notas[i] = notaAsignada;
                return; 
            } else {
                System.out.println("No se puede asignar nota. Límite de cursos alcanzado para el estudiante " + getNombreCompleto());
                return;
            }
        }
    }
    //no está en la lista de cursos del estudiante
    System.out.println("El estudiante " + getNombreCompleto() + " no está matriculado en el curso " + curso.nombre);
}

    public void agregarCurso(Curso curso) {
        cursos[cantidadCursos] = curso;
        cantidadCursos++;
    }
}