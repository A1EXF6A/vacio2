/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
public class Persona {
    protected String cedula;
    protected String Nombre1;
    protected String Apellido1;
    protected String F_nacimiento;

    public Persona(String cedula, String Nombre1, String Apellido1, String F_nacimiento) {
        this.cedula = cedula;
        this.Nombre1 = Nombre1;
        this.Apellido1 = Apellido1;
        this.F_nacimiento = F_nacimiento;
    }

    public String getNombreCompleto() {
        return Nombre1 + " " + Apellido1;
    }

    public String getCedula() {
        return cedula;
    }

    @Override
    public String toString() {
        return "Cedula: " + cedula + " Nombre: " + Nombre1 + " " + Apellido1 + " Fecha de Nacimiento: " + F_nacimiento;
    }
}

