/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
public class Nota {
    float nota;
    Curso curso;

    public Nota(float nota, Curso curso) {
        this.nota = nota;
        this.curso = curso;
    }
}
