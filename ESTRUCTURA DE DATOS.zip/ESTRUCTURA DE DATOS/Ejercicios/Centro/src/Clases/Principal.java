/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
public class Principal {
    public static void main(String[] args) {
        Profesor profesor = new Profesor(2000, "123456789", "Juan", "", "Pérez", "", "1990-02-18", "10 años");
        Profesor profesor2 = new Profesor(3000, "123456789", "Fernando", "", "Ibarra", "", "1995-05-15", "5 años");
        Profesor profesor3 = new Profesor(1500, "123456789", "Andrea", "", "Sanchez", "", "1997-12-10", "3 años");

        Curso curso = new Curso("Matemáticas", 40, profesor, 40);
        Curso curso1 = new Curso("Redes", 45, profesor2, 40);
        Curso curso2 = new Curso("Metodos", 50, profesor3, 40);

        
        Estudiante estudiante1 = new Estudiante("loja 123", "987654321", "María", "", "Gómez", "", "2000-03-20");
        Estudiante estudiante2 = new Estudiante("cuenca", "456789123", "Pedro", "", "López", "", "2001-07-10");
        Estudiante estudiante3 = new Estudiante("quito", "454552123", "Luisa", "", "Andrade", "", "2003-08-11");
        Estudiante estudiante4 = new Estudiante("ambato", "142479123", "Madelaine", "", "Moposita", "", "2001-12-10");
        Estudiante estudiante5 = new Estudiante("guayaquil", "142759123", "Keila", "", "Noboa", "", "2001-12-25");
        Estudiante estudiante6 = new Estudiante("pelileo", "2145479123", "Giomaira", "", "Diaz", "", "2003-12-27");
        
        Gestor gestor = new Gestor();

        //agregar cursos
        gestor.agregarCurso(curso);
        gestor.agregarCurso(curso1);
        gestor.agregarCurso(curso2);
        //agregar personas
        gestor.agregarPersona(profesor);
        gestor.agregarPersona(profesor2);
        gestor.agregarPersona(profesor3);
        gestor.agregarPersona(estudiante1);
        gestor.agregarPersona(estudiante2);
        gestor.agregarPersona(estudiante3);
        gestor.agregarPersona(estudiante4);
        gestor.agregarPersona(estudiante5);
        gestor.agregarPersona(estudiante6);
        //matricular
        gestor.matricularEstudiante(estudiante1, curso1);
        gestor.matricularEstudiante(estudiante2, curso1);
        gestor.matricularEstudiante(estudiante3, curso1);
        gestor.matricularEstudiante(estudiante4, curso1);
        gestor.matricularEstudiante(estudiante5, curso1);
        gestor.matricularEstudiante(estudiante1, curso);
        gestor.matricularEstudiante(estudiante1, curso2);
        //calificar
        gestor.asignarNotaEstudiante(estudiante1, curso, 8.0f);
        gestor.asignarNotaEstudiante(estudiante1, curso1, 5.0f);
        gestor.asignarNotaEstudiante(estudiante1, curso2, 10.0f);
        // datos de los cursos
        gestor.mostrarDatosCursos();
        System.out.println("\n");
        //reporte de inscritos
        gestor.hacerReporteInscritos();
        System.out.println("\n");
        //reporte de profesores
        gestor.hacerReporteProfesores();
        System.out.println("\n");
        //reporte de estudiantes
        gestor.hacerReporteEstudiantes();
        System.out.println("\n");
        //promedio de notas de un estudiante
        gestor.mostrarPromedioNotasEstudiante(estudiante1);
    }
}

