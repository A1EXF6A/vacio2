/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */
public class SolicitudReparaciones {
    Cliente cliente;
    LocalDateTime fechaIngreso;
    LocalDateTime fechaFin;
    Reparacion reparacion;
    double precio;
    long tiempo;

    public SolicitudReparaciones(Cliente cliente, Reparacion reparacion) {
        this.cliente = cliente;
        this.reparacion = reparacion;
        this.fechaIngreso = LocalDateTime.now();
        this.precio = 0;
        this.tiempo = 0;
    }
    public void calcularPrecio() {
    if(fechaIngreso != null && reparacion.estado.actual.equalsIgnoreCase("solucionada") || reparacion.estado.actual.equalsIgnoreCase("sin solucion")) {
        if(tiempo==0&&precio==0)reparacion.terminada(); 
        fechaFin = reparacion.fin;
        Duration duracion = Duration.between(fechaIngreso, fechaFin);
        long minutos = duracion.toMinutes();
        this.tiempo = minutos;
        precio = minutos * 0.5;
    }
}

    
    
}
