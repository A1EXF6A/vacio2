/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */
public class Reparacion {
    String nombre;
    LocalDateTime fin;
    Estado estado;

    public Reparacion(String nombre, Estado estado) {
        this.nombre = nombre;
        this.estado = estado;
    }
    
    
    public void terminada(){
    if(estado.actual.equalsIgnoreCase("solucionada") || estado.actual.equalsIgnoreCase("sin solucion")){
        fin = LocalDateTime.now();
    }
}

}
