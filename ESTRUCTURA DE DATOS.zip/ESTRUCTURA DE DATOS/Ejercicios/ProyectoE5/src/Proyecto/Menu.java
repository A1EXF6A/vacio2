/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

/**
 *
 * @author HOME
 */
import java.time.LocalDateTime;
import java.util.Scanner;

import java.time.LocalDateTime;
import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cliente cliente = null;
        Reparacion reparacion = null;
        SolicitudReparaciones solicitud = null;

        int opcion;
        do {
            System.out.println("Bienvenido al Sistema de Reparaciones");
            System.out.println("1. Ingresar nueva solicitud");
            System.out.println("2. Ver estado de reparación");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el nombre del cliente:");
                    scanner.nextLine(); // Consume la nueva línea pendiente
                    String nombreCliente = scanner.nextLine();
                    System.out.println("Ingrese la cédula del cliente:");
                    String cedulaCliente = scanner.nextLine();
                    cliente = new Cliente(nombreCliente, cedulaCliente);

                    System.out.println("Ingrese el nombre de la reparación:");
                    String nombreReparacion = scanner.nextLine();

                    System.out.println("Ingrese el estado de la reparación:");
                    String estadoReparacion = scanner.nextLine();
                    Estado estado = new Estado(estadoReparacion);
                    reparacion = new Reparacion(nombreReparacion,estado);
                    //reparacion.nombre = nombreReparacion;
                    
                    Thread estadoThread = new Thread(estado);
                    estadoThread.start();
                    //reparacion.estado = estado;

                    solicitud = new SolicitudReparaciones(cliente, reparacion);
                    
                    System.out.println("Solicitud ingresada con éxito.");
                    break;
                case 2:
                    if (solicitud != null && solicitud.reparacion != null) {
                        //reparacion.terminada();
                        solicitud.calcularPrecio();
                        
                        System.out.println("Estado de la reparación:");
                        System.out.println("Nombre: " + solicitud.reparacion.nombre);
                        System.out.println("Estado actual: " + solicitud.reparacion.estado.actual);
                        System.out.println("Fecha de ingreso: " + solicitud.fechaIngreso);
                        System.out.println("Fecha de finalización: " + solicitud.fechaFin);
                        System.out.println("Precio: $" + solicitud.precio);
                        System.out.println("Tiempo de reparacion: "+solicitud.tiempo);
                    } else {
                        System.out.println("No hay una solicitud ingresada aún.");
                    }
                    break;
                case 3:
                    System.out.println("Saliendo del Sistema de Reparaciones. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione nuevamente.");
            }
        } while (opcion != 3);

        scanner.close();
    }
}
