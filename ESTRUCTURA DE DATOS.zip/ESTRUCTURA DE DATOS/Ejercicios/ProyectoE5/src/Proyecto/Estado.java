/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

public class Estado implements Runnable {
   String actual;
    private volatile boolean running; // Variable para controlar si el hilo debe seguir ejecutándose

    public Estado(String actual) {
        this.actual = actual;
        this.running = true; // Inicializar como true para que el hilo comience ejecutándose
    }

    @Override
    public void run() {
        String[] posiblesEstados = {"mojado", "quemado", "roto"};
        String temp = actual;

        try {
            while (running) { // El hilo continuará ejecutándose mientras running sea true
                actual = "ingresada";
                TimeUnit.MINUTES.sleep(1);
                actual = "en revision";
                TimeUnit.MINUTES.sleep(1);
                for (String posible : posiblesEstados) {
                    if (posible.equals(temp)) {
                        actual = "solucionada";
                        running = false; // Detener el hilo cuando el estado cambie a "solucionada"
                        return;
                    }
                }
                actual = "sin solucion";
                running = false; // Detener el hilo cuando el estado cambie a "sin solucion"
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getActual() {
        return actual;
    }
}

