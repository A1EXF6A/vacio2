/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoe;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author HOME
 */
import java.time.Duration;
import java.time.LocalDateTime;

public class SolicitudReparacion {
    private Cliente cliente;
    private Reparacion reparacion;
    private LocalDateTime fechaIngreso;
    private LocalDateTime fechaSalida;
    private double precioPagar;

    public SolicitudReparacion(Cliente cliente, Reparacion reparacion) {
        this.cliente = cliente;
        this.reparacion = reparacion;
        this.fechaIngreso = LocalDateTime.now();
        this.precioPagar = 0;
    }

    // Método para calcular el precio a pagar
    public void calcularPrecio() {
        if (fechaSalida != null && reparacion.getEstado().equals("solucionada")) {
            Duration duracion = Duration.between(fechaIngreso, fechaSalida);
            long minutos = duracion.toMinutes();
            // Aquí puedes establecer la lógica para calcular el precio basado en el tiempo transcurrido
            this.precioPagar = minutos * 0.5; // Ejemplo: $0.5 por minuto
        }
    }

    // Otros métodos getter y setter...

    public LocalDateTime getFechaIngreso() {
        return fechaIngreso;
    }

    public LocalDateTime getFechaSalida() {
        return fechaSalida;
    }

    public double getPrecioPagar() {
        return precioPagar;
    }

    public void setFechaSalida(LocalDateTime fechaSalida) {
        this.fechaSalida = fechaSalida;
    }
    public Cliente getCliente(){
        return this.cliente;
        
    }
    public Reparacion getReparacion(){
        return this.reparacion;
    }
}