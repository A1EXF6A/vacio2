/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoe;

/**
 *
 * @author HOME
 */
class CambioEstadoReparacion implements Runnable {
    private Reparacion reparacion;

    public CambioEstadoReparacion(Reparacion reparacion) {
        this.reparacion = reparacion;
    }

    @Override
    public void run() {
        try {
            // Espera 2 minutos
            Thread.sleep(2 * 60 * 1000);
            // Actualiza el estado de la reparación
            reparacion.estado().actualizarEstado();
            
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
