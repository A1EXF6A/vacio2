/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoe;

import java.time.LocalDateTime;

/**
 *
 * @author HOME
 */

import java.util.Scanner;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Scanner;

public class ProyectoE {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ListaSolicitudes listaSolicitudes = new ListaSolicitudes();

        int opcion;
        do {
            System.out.println("Menú:");
            System.out.println("1. Ingresar una solicitud");
            System.out.println("2. Ver estado de una solicitud por cédula del cliente");
            System.out.println("3. Salir");
            System.out.print("Ingrese su opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea después de la entrada del entero

            switch (opcion) {
                case 1:
                    ingresarSolicitud(scanner, listaSolicitudes);
                    break;
                case 2:
                    verEstadoPorCedula(scanner, listaSolicitudes);
                    break;
                case 3:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, ingrese una opción válida.");
            }
        } while (opcion != 3);
    }

    private static void ingresarSolicitud(Scanner scanner, ListaSolicitudes listaSolicitudes) {
        System.out.println("Ingrese los datos de la solicitud:");
        System.out.print("Nombre del cliente: ");
        String nombreCliente = scanner.nextLine();
        System.out.print("Cédula del cliente: ");
        String cedulaCliente = scanner.nextLine();
        System.out.print("Nombre de la reparación: ");
        String nombreReparacion = scanner.nextLine();
        System.out.print("Estado de la reparación (mojado, quemado, etc.): ");
        String estadoReparacion = scanner.nextLine();

        Cliente cliente = new Cliente(nombreCliente, cedulaCliente);
        Reparacion reparacion = new Reparacion(nombreReparacion, estadoReparacion);
        SolicitudReparacion solicitud = new SolicitudReparacion(cliente, reparacion);
        listaSolicitudes.agregarSolicitud(solicitud);
        System.out.println("Solicitud ingresada correctamente.");

        // Inicia el hilo para el cambio de estado
        new Thread(new CambioEstadoReparacion(reparacion)).start();
    }

    private static void verEstadoPorCedula(Scanner scanner, ListaSolicitudes listaSolicitudes) {
        System.out.print("Ingrese la cédula del cliente: ");
        String cedulaCliente = scanner.nextLine();
        listaSolicitudes.mostrarEstadoYPrecioPorCedula(cedulaCliente);
    }
}
