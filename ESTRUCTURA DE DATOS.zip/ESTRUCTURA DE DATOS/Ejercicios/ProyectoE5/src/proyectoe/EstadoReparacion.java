/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoe;

/**
 *
 * @author HOME
 */
class EstadoReparacion {
    private String estadoActual;

    public EstadoReparacion(String estadoInicial) {
        this.estadoActual = estadoInicial;
    }

    public void setEstadoActual(String estadoActual) {
        this.estadoActual = estadoActual;
    }

    // Método para actualizar el estado
    public void actualizarEstado() {
        String[] posiblesEstados = {"mojado", "quemado", "otros"}; // Agrega los estados que necesites
        for (String posible : posiblesEstados) {
            if (posible.equals(estadoActual)) {
                // Cambiar el estado a "solucionada" si el estado actual es uno de los posibles
                this.estadoActual = "solucionada";
                return;
            }
        }
        // Si el estado no es uno de los posibles, cambiar a "sin solucion"
        this.estadoActual = "sin solucion";
    }

    // Otros métodos getter y setter...

    public String getEstadoActual() {
        return estadoActual;
    }
}
