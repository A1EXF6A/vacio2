/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoe;

import java.time.LocalDateTime;

class Reparacion {
    private String nombre;
    private EstadoReparacion estado;
    private LocalDateTime horaCreacion;
    private LocalDateTime ultimaActualizacion;

    public Reparacion(String nombre, String estadoInicial) {
        this.nombre = nombre;
        this.estado = new EstadoReparacion(estadoInicial);
        this.horaCreacion = LocalDateTime.now();
        this.ultimaActualizacion = horaCreacion;
    }

    // Método para actualizar el estado
    public void actualizarEstado() {
        // Este método ya no realiza el cambio de estado directamente, en lugar de eso, se inicia un hilo para hacerlo
        new Thread(new CambioEstadoReparacion(this)).start();
    }

    // Otros métodos getter y setter...

    public String getEstado() {
        return estado.getEstadoActual();
    }
    
    public EstadoReparacion estado(){
        return this.estado;
    }
}
