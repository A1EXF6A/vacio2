/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoe;

/**
 *
 * @author HOME
 */
class ListaSolicitudes {
    private SolicitudReparacion[] solicitudes;
    private int cantidad;

    public ListaSolicitudes() {
        this.solicitudes = new SolicitudReparacion[10]; // Cambiar el tamaño según sea necesario
        this.cantidad = 0;
    }

    public void agregarSolicitud(SolicitudReparacion solicitud) {
        if (cantidad < solicitudes.length) {
            solicitudes[cantidad++] = solicitud;
        } else {
            System.out.println("No se pueden agregar más solicitudes. La lista está llena.");
        }
    }

    public void mostrarEstadoPorCedula(String cedulaCliente) {
        boolean encontrado = false;
        for (int i = 0; i < cantidad; i++) {
            if (solicitudes[i].getCliente().getCedula().equals(cedulaCliente)) {
                encontrado = true;
                System.out.println("Estado de la solicitud para el cliente " + cedulaCliente + ": " + solicitudes[i].getReparacion().getEstado());
            }
        }
        if (!encontrado) {
            System.out.println("No se encontró ninguna solicitud para el cliente con cédula " + cedulaCliente);
        }
    }
    public void mostrarEstadoYPrecioPorCedula(String cedulaCliente) {
    boolean encontrado = false;
    for (int i = 0; i < cantidad; i++) {
        if (solicitudes[i].getCliente().getCedula().equals(cedulaCliente)) {
            encontrado = true;
            System.out.println("Estado de la solicitud para el cliente " + cedulaCliente + ": " + solicitudes[i].getReparacion().getEstado());
            System.out.println("Precio a pagar: $" + solicitudes[i].getPrecioPagar());
        }
    }
    if (!encontrado) {
        System.out.println("No se encontró ninguna solicitud para el cliente con cédula " + cedulaCliente);
    }
}

}

