/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author HOME
 */
import javax.swing.JOptionPane;
import java.util.LinkedList;

public class Consola {
    private CentroReparaciones centro;

    public Consola(CentroReparaciones centro) {
        this.centro = centro;
    }

    public void mostrarMenu() {
        int opcion;
        do {
            String menu = "----- Menú de Centro de Reparaciones -----\n"
                        + "1. Realizar una solicitud de reparación\n"
                        + "2. Ver estado de todas las reparaciones\n"
                        + "3. Ver el mejor cliente\n"
                        + "4. Ver tiempo promedio de reparaciones\n"
                        + "5. Ver las reparaciones por cliente\n"
                        + "0. Salir";
            opcion = Integer.parseInt(JOptionPane.showInputDialog(null, menu + "\nIngrese su opción:", "Menú", JOptionPane.PLAIN_MESSAGE));

            switch (opcion) {
                case 1:
                    realizarSolicitudReparacion();
                    break;
                case 2:
                    verEstadoReparaciones();
                    break;
                case 3:
                    verMejorCliente();
                    break;
                case 4:
                    verTiempoPromedioReparaciones();
                    break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema...", "Salir", JOptionPane.INFORMATION_MESSAGE);
                    System.exit(0);
                    break;
                case 5:
                    String cedula = ingreso("Cedula");
                    centro.ver(cedula);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Por favor, elija una opción válida.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (opcion != 0);
    }

    private void realizarSolicitudReparacion() {
    JOptionPane.showMessageDialog(null, "Bienvenido al centro xxxx\nIngrese sus datos personales:", "Solicitud de Reparación", JOptionPane.PLAIN_MESSAGE);
    String nombre, apellido, direccion, cedula, telefono;
    do {
        nombre = ingreso("nombre");
        if (!validaciones.Validacion.validarNombreApellido(nombre)) {
            JOptionPane.showMessageDialog(null, "Nombre inválido. Por favor, ingrese un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } while (!validaciones.Validacion.validarNombreApellido(nombre));
    do {
        apellido = ingreso("apellido");
        if (!validaciones.Validacion.validarNombreApellido(apellido)) {
            JOptionPane.showMessageDialog(null, "Apellido inválido. Por favor, ingrese un apellido válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } while (!validaciones.Validacion.validarNombreApellido(apellido));
    do {
        direccion = ingreso("direccion");
        if (!validaciones.Validacion.validarDireccion(direccion)) {
            JOptionPane.showMessageDialog(null, "Dirección inválida. Por favor, ingrese una dirección válida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } while (!validaciones.Validacion.validarDireccion(direccion));
    do {
        cedula = ingreso("cedula");
        if (!validaciones.Validacion.validarCedula(cedula)) {
            JOptionPane.showMessageDialog(null, "Cédula inválida. Por favor, ingrese una cédula válida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } while (!validaciones.Validacion.validarCedula(cedula));
    do {
        telefono = ingreso("telefono");
        if (!validaciones.Validacion.validarTelefonoCelularEcuador(telefono)) {
            JOptionPane.showMessageDialog(null, "Teléfono inválido. Por favor, ingrese un teléfono válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } while (!validaciones.Validacion.validarTelefonoCelularEcuador(telefono));

    Cliente a = new Cliente(nombre, apellido, direccion, telefono, cedula);
    JOptionPane.showMessageDialog(null, "Ingrese los datos de su reparacion:", "Solicitud de Reparación", JOptionPane.PLAIN_MESSAGE);
    String reparacion = ingreso("reparacion");
    String estado = ingreso("estado");
    EstadoReparacion actual = new EstadoReparacion(estado);
    Reparacion b = new Reparacion(reparacion, actual, a);
    SolicitudReparaciones nueva = new SolicitudReparaciones(a, b);
    centro.agregarSolicitud(nueva);
    a.getSolicitudesReparacion().add(nueva);
    centro.agregarCliente(a);
    centro.agregarReparacion(b);
    
    // Aquí inicia el hilo que maneja el estado de la reparación
    Thread estadoThread = new Thread(actual);
    estadoThread.start();
}


    private void verEstadoReparaciones() {
        StringBuilder mensaje = new StringBuilder("Lista de todas las reparaciones del centro: \n");
        for (Reparacion reparacion : centro.getReparaciones()) {
            mensaje.append(String.format("%-10s %5s\n", reparacion.getNombre(), reparacion.getEstado().getActual()));
            reparacion.terminada();
        }
        JOptionPane.showMessageDialog(null, mensaje.toString(), "Estado de Reparaciones", JOptionPane.PLAIN_MESSAGE);
    }

    private void verMejorCliente() {
        LinkedList<String> mejoresClientes = centro.obtenerMejoresClientes();
        StringBuilder mensaje = new StringBuilder("Los mejores clientes son: \n");
        for (String nombre : mejoresClientes) {
            mensaje.append("Nombre: ").append(nombre).append("\n");
        }
        JOptionPane.showMessageDialog(null, mensaje.toString(), "Mejor Cliente", JOptionPane.PLAIN_MESSAGE);
    }

    private void verTiempoPromedioReparaciones() {
        long tiempoPromedio = centro.tiempoPromedioReparaciones();
        JOptionPane.showMessageDialog(null, "El tiempo promedio de reparaciones es: " + tiempoPromedio + " segundos", "Tiempo Promedio de Reparaciones", JOptionPane.PLAIN_MESSAGE);
    }
    private void verReparacionesPorCliente() {
        String cedula = ingreso("Cedula");
    LinkedList<String> reparacionesPorCliente = centro.obtenerRearacionesPorCliente(cedula);
    StringBuilder mensaje = new StringBuilder("Reparaciones para el cliente con cédula " + cedula + ":\n");
    if (reparacionesPorCliente.isEmpty()) {
        mensaje.append("No hay reparaciones para este cliente.");
    } else {
        for (String reparacion : reparacionesPorCliente) {
            mensaje.append(reparacion).append("\n");
        }
    }
    JOptionPane.showMessageDialog(null, mensaje.toString(), "Reparaciones por Cliente", JOptionPane.PLAIN_MESSAGE);
}

    public static void main(String[] args) {
        CentroReparaciones centro = new CentroReparaciones();
        Consola interfaz = new Consola(centro);
        interfaz.mostrarMenu();
    }

    public String ingreso(String a) {
        return JOptionPane.showInputDialog(null, "Ingrese su " + a + ":", "Ingreso de Datos", JOptionPane.PLAIN_MESSAGE);
    }
}
