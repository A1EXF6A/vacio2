/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class Graficos extends JFrame implements ActionListener {

    private CentroReparaciones centro;

    public Graficos(CentroReparaciones centro) {
        this.centro = centro;
        setTitle("Centro de Reparaciones");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        JButton btnSolicitud = new JButton("Realizar una solicitud de reparación");
        JButton btnEstado = new JButton("Ver estado de todas las reparaciones");
        JButton btnMejorCliente = new JButton("Ver el mejor cliente");
        JButton btnTiempoPromedio = new JButton("Ver tiempo promedio de reparaciones");

        btnSolicitud.addActionListener(this);
        btnEstado.addActionListener(this);
        btnMejorCliente.addActionListener(this);
        btnTiempoPromedio.addActionListener(this);

        panel.add(btnSolicitud);
        panel.add(btnEstado);
        panel.add(btnMejorCliente);
        panel.add(btnTiempoPromedio);

        add(panel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        switch (command) {
            case "Realizar una solicitud de reparación":
                // Lógica para realizar una solicitud de reparación
                break;
            case "Ver estado de todas las reparaciones":
                // Lógica para ver el estado de todas las reparaciones
                break;
            case "Ver el mejor cliente":
                CentroReparaciones centroReparaciones = new CentroReparaciones();
                LinkedList<String> mejoresClientes = centro.obtenerMejoresClientes();
                centro.obtenerMejoresClientes();
                // Imprimir los nombres de los mejores clientes
                System.out.println("Los mejores clientes son: ");
                for (String nombre : mejoresClientes) {
                    System.out.println("Nombre: " + nombre);
                }
                break;

            case "Ver tiempo promedio de reparaciones":
                long tiempoPromedio = centro.tiempoPromedioReparaciones();
                JOptionPane.showMessageDialog(this, "El tiempo promedio de reparaciones es: " + tiempoPromedio + " segundos");
                break;
        }
    }

    public static void main(String[] args) {
        CentroReparaciones centro = new CentroReparaciones();
        Graficos interfaz = new Graficos(centro);
        interfaz.setVisible(true);
    }
}
