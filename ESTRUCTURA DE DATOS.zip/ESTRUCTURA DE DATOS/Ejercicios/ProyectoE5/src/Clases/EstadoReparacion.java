
package Clases;

/**
 *
 * @author Anthony
 */
class EstadoReparacion implements Runnable {
    public String actual;
    public volatile boolean running;

    public EstadoReparacion(String actual) {
        this.actual = actual;
        this.running = true;
    }

    @Override
    public void run() {
        String[] posiblesEstados = {"mojado", "quemado", "roto"};
        String temp = actual;
        long a = (long) (Math.floor(Math.random() * 3) + 1)*100000;

        try {
            while (running) {
                actual = "ingresada";
                Thread.sleep(a); // 1 minuto
                actual = "en revision";
                Thread.sleep(a); // 1 minuto
                for (String posible : posiblesEstados) {
                    if (posible.equals(temp)) {
                        actual = "solucionada";
                        running = false;
                        return;
                    }
                }
                actual = "sin solucion";
                running = false;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getActual() {
        return actual;
    }
}
