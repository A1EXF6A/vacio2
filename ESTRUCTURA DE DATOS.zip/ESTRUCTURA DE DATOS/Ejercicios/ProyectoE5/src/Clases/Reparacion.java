
package Clases;

import java.time.LocalDateTime;

/**
 *
 * @author Anthony
 */
class Reparacion {

    public String nombre;
    public LocalDateTime inicio;
    public LocalDateTime fin;
    public EstadoReparacion estado;
    Cliente cliente;

    public Reparacion(String nombre, EstadoReparacion estado, Cliente cliente) {
        this.nombre = nombre;
        this.estado = estado;
        this.cliente = cliente;
        this.inicio = LocalDateTime.now();
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDateTime getInicio() {
        return inicio;
    }

    public LocalDateTime getFin() {
        return fin;
    }

    public EstadoReparacion getEstado() {
        return estado;
    }

    public Cliente getCliente() {
        return cliente;
    }

public void terminada() {
    if (estado.getActual().equalsIgnoreCase("solucionada") || estado.getActual().equalsIgnoreCase("sin solucion")) {
        fin = LocalDateTime.now();
        cliente.solicitudTerminada();
    }
}



}
