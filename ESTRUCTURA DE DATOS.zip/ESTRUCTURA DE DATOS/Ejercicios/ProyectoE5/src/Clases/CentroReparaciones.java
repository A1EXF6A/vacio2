
package Clases;

/**
 *
 * @author ASUS
 */
import java.time.Duration;
import java.util.LinkedList;

public class CentroReparaciones {
    private LinkedList<Cliente> clientes;
    private LinkedList<Reparacion> reparaciones;
    public LinkedList<SolicitudReparaciones> solicitudes;
    public CentroReparaciones() {
        this.clientes = new LinkedList<>();
        this.reparaciones = new LinkedList<>();
        this.solicitudes = new LinkedList<>();
    }

    public void agregarCliente(Cliente cliente) {
        if (cliente != null) {
            clientes.add(cliente);
        } else {
            System.out.println("Error: Intentando agregar un cliente nulo.");
        }
    }
    public void agregarSolicitud(SolicitudReparaciones a){
        solicitudes.add(a);
    }

    public void agregarReparacion(Reparacion reparacion) {
        reparaciones.add(reparacion);
    }

    // Método para marcar una reparación como completada
    public void reparacionCompletada(Reparacion reparacion) {
    reparacion.terminada(); // Esto marca la reparación como completada
    Cliente cliente = reparacion.getCliente();
    if (cliente != null) {
        cliente.solicitudTerminada(); // Esto incrementa el contador de reparaciones completadas para el cliente
    }
}


 public LinkedList<String> obtenerMejoresClientes() {
    LinkedList<String> mejoresClientes = new LinkedList<>();
    int maxCantidad = 3; 
    for (Cliente cliente : clientes) {
        int numSolicitudes = cliente.getSolicitudesReparacion().size();
        if (numSolicitudes > maxCantidad) {
            mejoresClientes.add(cliente.getNombre());
        }
    }

    return mejoresClientes;
}


    public int cantidadSolicitudesEstado(String estado) {
        int cantidad = 0;
        for (Reparacion reparacion : reparaciones) {
            if (reparacion.getEstado().getActual().equalsIgnoreCase(estado)) {
                cantidad++;
            }
        }
        return cantidad;
    }

    public long tiempoPromedioReparaciones() {
        long tiempoTotal = 0;
        int cantidad = 0;
        for (Reparacion reparacion : reparaciones) {
            if (reparacion.getFin() != null) {
                tiempoTotal += Duration.between(reparacion.getInicio(), reparacion.getFin()).getSeconds();
                cantidad++;
            }
        }
        return cantidad > 0 ? tiempoTotal / cantidad : 0;
    }

    /**
     *
     * @param cedula
     * @return
     */
    public LinkedList<String> obtenerRearacionesPorCliente(String cedula){
    LinkedList<String> reparacionesPorCliente = new LinkedList<>();
    for (Reparacion reparacion : reparaciones){
        if (reparacion.getCliente().getCedula().equals(cedula)) {
            
         reparacionesPorCliente.add(reparacion.getNombre());   
        }
    }
    return reparacionesPorCliente;
}
    public LinkedList<Cliente> getClientes() {
        return clientes;
    }

    public LinkedList<Reparacion> getReparaciones() {
        return reparaciones;
    }
    public void ver(String cedula){
        for (int i = 0; i < solicitudes.size(); i++) {
            if(solicitudes.get(i).getCliente().cedula.equals(cedula)){
                solicitudes.get(i).calcularPrecio();
                System.out.println(solicitudes.get(i).getReparacion().nombre+" "+solicitudes.get(i).getPrecio());
            }
        }
    }
}
