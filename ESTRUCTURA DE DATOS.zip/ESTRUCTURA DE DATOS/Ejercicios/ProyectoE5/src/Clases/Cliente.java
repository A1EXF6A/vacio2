
package Clases;

import java.util.LinkedList;

/**
 *
 * @author Anthony
 */
class Cliente extends Persona {
    private LinkedList<SolicitudReparaciones> solicitudesReparacion;
    private int vecesReparadas;

    public Cliente(String nombres, String apellidos, String direccion, String telefono, String cedula) {
        super(nombres, apellidos, direccion, telefono, cedula);
        this.solicitudesReparacion = new LinkedList<>();
        this.vecesReparadas = 0;
    }

    public LinkedList<SolicitudReparaciones> getSolicitudesReparacion() {
        return solicitudesReparacion;
    }

    public LinkedList<Reparacion> getReparacionesCompletadas() {
        LinkedList<Reparacion> reparacionesCompletadas = new LinkedList<>();
        for (SolicitudReparaciones solicitud : solicitudesReparacion) {
            if (solicitud.getReparacion().getEstado().getActual().equalsIgnoreCase("solucionada")) {
                reparacionesCompletadas.add(solicitud.getReparacion());
            }
        }
        return reparacionesCompletadas;
    }

    public int getVecesReparadas() {
        return vecesReparadas;
    }

    public void enviarSolicitud(SolicitudReparaciones solicitud) {
        solicitudesReparacion.add(solicitud);
    }

    public void solicitudTerminada() {
        vecesReparadas++;
    }

    public int getNumReparaciones() {
        int numReparaciones = 0;
        for (SolicitudReparaciones solicitud : solicitudesReparacion) {
            if (solicitud.getReparacion().getEstado().getActual().equalsIgnoreCase("solucionada")) {
                numReparaciones++;
            }
        }
        return vecesReparadas;
    }
}
