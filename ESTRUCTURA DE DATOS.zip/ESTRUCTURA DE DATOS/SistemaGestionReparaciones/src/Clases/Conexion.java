/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author User
 */
import java.sql.Connection;
import java.sql.*;
import javax.swing.JOptionPane;

public class Conexion {

    Connection conectar;

    public Connection Conectar() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestorreparacion", "root", "");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);

        }
        return conectar;

    }
}
