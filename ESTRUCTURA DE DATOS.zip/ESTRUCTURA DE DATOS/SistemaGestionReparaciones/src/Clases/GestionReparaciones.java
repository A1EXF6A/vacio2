/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class GestionReparaciones {

    // Función para agregar una reparación
public void agregarReparacion(String cliente, int trabajador, String estado, String fechaIngreso, String descripcion) {
    Connection conn = null;
    PreparedStatement stmt = null;

    try {
        Conexion cc = new Conexion();
        Connection cn = cc.Conectar();

        // Query para insertar una nueva reparación en la tabla Reparaciones
        String query = "INSERT INTO Reparaciones (nombres_clientes, trabajador, estado, fecha_ingreso, descripcion_reparacion) VALUES (?, ?, ?, ?, ?)";

        // Preparar la declaración SQL
        stmt = cn.prepareStatement(query);
        stmt.setString(1, cliente);
        stmt.setInt(2, trabajador);
        stmt.setString(3, estado);
        stmt.setString(4, fechaIngreso);
        stmt.setString(5, descripcion);

        // Ejecutar la consulta
        stmt.executeUpdate();

        // Mostrar mensaje de éxito
        JOptionPane.showMessageDialog(null, "Reparación agregada correctamente.");

    } catch (SQLException ex) {
        // Mostrar mensaje de error en caso de excepción
        JOptionPane.showMessageDialog(null, "Error al agregar la reparación: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Cerrar la conexión y la declaración
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}




    // Función para modificar el estado de una reparación
    public void modificarEstadoReparacion(int reparacion, String nuevoEstado) {
        try {
            Conexion cc = new Conexion();
            Connection cn = cc.Conectar();

            String sql = "UPDATE Reparaciones SET estado = ? WHERE id_reparacion = ?";
            PreparedStatement pst = cn.prepareStatement(sql);
            pst.setString(1, nuevoEstado);
            pst.setInt(2, reparacion);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Estado de reparación modificado correctamente");
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar el estado de la reparación");
            }

            pst.close();
            cn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar el estado de la reparación: " + ex.getMessage());
        }
    }

    // Función para finalizar una reparación
    public void finalizarReparacion(int reparacion, String fechaSalida) {
        try {
            Conexion cc = new Conexion();
            Connection cn = cc.Conectar();

            String sql = "UPDATE Reparaciones SET estado = 'solucionada', fecha_salida = ? WHERE id_reparacion = ?";
            PreparedStatement pst = cn.prepareStatement(sql);
            pst.setString(1, fechaSalida);
            pst.setInt(2, reparacion);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Reparación finalizada correctamente");
            } else {
                JOptionPane.showMessageDialog(null, "Error al finalizar la reparación");
            }

            pst.close();
            cn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al finalizar la reparación: " + ex.getMessage());
        }
    }

    // Función para buscar una reparación por estado
    public ResultSet buscarReparacionPorEstado(String estado) {
        try {
            Conexion cc = new Conexion();
            Connection cn = cc.Conectar();

            String sql = "SELECT * FROM Reparaciones WHERE estado = ?";
            PreparedStatement pst = cn.prepareStatement(sql);
            pst.setString(1, estado);

            ResultSet rs = pst.executeQuery();
            return rs; // Devolver el ResultSet con los resultados de la consulta
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al buscar reparaciones: " + ex.getMessage());
            return null;
        }
    }
}
