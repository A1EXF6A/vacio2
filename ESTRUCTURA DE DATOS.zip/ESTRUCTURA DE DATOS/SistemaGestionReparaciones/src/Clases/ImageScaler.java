package Clases;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class ImageScaler {

    public static ImageIcon scaleImage(String imagePath, int width, int height) {
        ImageIcon icon = null;
        try {
            InputStream inputStream = ImageScaler.class.getResourceAsStream(imagePath);
            BufferedImage originalImage = ImageIO.read(inputStream);
            Image scaledImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(scaledImage);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return icon;
    }
}
