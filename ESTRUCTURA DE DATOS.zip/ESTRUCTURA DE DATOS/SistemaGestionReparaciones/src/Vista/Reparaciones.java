/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Clases.Conexion;
import Clases.GestionReparaciones;
import Clases.ImageScaler;
import java.sql.Connection;
import javax.swing.ImageIcon;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author User
 */
public final class Reparaciones extends javax.swing.JFrame {

    DefaultTableModel modelo;

    /**
     * Creates new form Reparaciones
     */
    public Reparaciones() {

        initComponents();
        CargarTabla("");
        SeleccionarClienteTabla();
        CargarTrabajadores();
        CargarEstados();
        TextosInicio();
        BotonesInicio();

        ImageIcon scaledIcon1 = ImageScaler.scaleImage("/Imagenes/logo.png", 120, 120);
        jlalogo.setIcon(scaledIcon1);
        
        ImageIcon scaledIcon2 = ImageScaler.scaleImage("/Imagenes/inicio.png", 100, 70);
        jlblinicio.setIcon(scaledIcon2);
    }

    // Método para buscar reparaciones por estado
    private void buscarReparacionPorEstado() {
        String estadoBuscar = txtEstadoBuscar.getText();

        // Llamar al método buscarReparacionPorEstado de la clase GestionReparaciones
        GestionReparaciones gestionReparaciones = new GestionReparaciones();
        ResultSet rs = gestionReparaciones.buscarReparacionPorEstado(estadoBuscar);

        // Mostrar los resultados en la tabla jTable1
        jTable1.setModel(DbUtils.resultSetToTableModel(rs));
    }

    // Método para agregar una reparación
  private void agregarReparacion() {
    try {
        // Obtener los valores seleccionados y las entradas de texto
        String cliente = txtIdCliente.getText().trim();
        String fechaIngreso = txtFechaIngreso.getText().trim();
        String descripcion = txtIdReparacion.getText().trim();
        
        // Verificar si los campos de texto no están vacíos
        if (cliente.isEmpty() || fechaIngreso.isEmpty() || descripcion.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Obtener el ID del trabajador y el estado
        int trabajador = Integer.parseInt(cbxReparador.getSelectedItem().toString().split(" ")[0]);
        String estado = cbxEstado.getSelectedItem().toString().split(" ")[0]; // Corregido para obtener el ID del estado

        // Llamar al método agregarReparacion de la clase GestionReparaciones
        GestionReparaciones gestionReparaciones = new GestionReparaciones();
        gestionReparaciones.agregarReparacion(cliente, trabajador, estado, fechaIngreso, descripcion);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Error al convertir los datos.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}





    // Método para modificar el estado de una reparación
    private void modificarEstadoReparacion() {
        int idReparacion = Integer.parseInt(txtIdReparacion.getText());
        String nuevoEstado = txtNuevoEstado.getText();

        // Llamar al método modificarEstadoReparacion de la clase GestionReparaciones
        GestionReparaciones gestionReparaciones = new GestionReparaciones();
        gestionReparaciones.modificarEstadoReparacion(idReparacion, nuevoEstado);
    }

    // Método para finalizar una reparación
    private void finalizarReparacion() {
        int idReparacion = Integer.parseInt(txtIdReparacion.getText());
        String fechaSalida = txtFechaSalida.getText();

        // Llamar al método finalizarReparacion de la clase GestionReparaciones
        GestionReparaciones gestionReparaciones = new GestionReparaciones();
        gestionReparaciones.finalizarReparacion(idReparacion, fechaSalida);
    }

    public void CargarTabla(String Dato) {
        try {
            String titulos[] = {"Cedula", "Nombre", "Apellido", "Telefono", "Direccion"};
            String registros[] = new String[5];

            modelo = new DefaultTableModel(null, titulos);

            Conexion cn = new Conexion();
            Connection cc = cn.Conectar();
            String Sql = "SELECT cedula, nombres, apellidos, telefono, direccion FROM Clientes WHERE cedula LIKE '%" + Dato + "%' OR nombres LIKE '%" + Dato + "%' OR apellidos LIKE '%" + Dato + "%'";
            Statement psd = cc.createStatement();
            ResultSet rs = psd.executeQuery(Sql);
            while (rs.next()) {
                registros[0] = rs.getString("cedula");
                registros[1] = rs.getString("nombres");
                registros[2] = rs.getString("apellidos");
                registros[3] = rs.getString("telefono");
                registros[4] = rs.getString("direccion");
                modelo.addRow(registros);
            }
            jTable1.setModel(modelo);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void SeleccionarClienteTabla() {
        jTable1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (jTable1.getSelectedRow() != -1) {

                    int fila = jTable1.getSelectedRow();

                    txtIdCliente.setText(jTable1.getValueAt(fila, 1).toString());

                }
            }
        });

    }

    public void CargarTrabajadores() {
        try {
            String idTrabajador, nombreTrabajador;
            Conexion cc = new Conexion();
            Connection cn = cc.Conectar();
            String sql = "SELECT * FROM trabajadores";
            Statement psd = cn.createStatement();
            ResultSet rs = psd.executeQuery(sql);
            while (rs.next()) {
                idTrabajador = rs.getString("id_trabajador");
                nombreTrabajador = rs.getString("nombre");

                cbxReparador.addItem(idTrabajador + " " + nombreTrabajador);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void CargarEstados() {
        try {
            String idTrabajador, nombreTrabajador;
            Conexion cc = new Conexion();
            Connection cn = cc.Conectar();
            String sql = "SELECT * FROM estado";
            Statement psd = cn.createStatement();
            ResultSet rs = psd.executeQuery(sql);
            while (rs.next()) {
                idTrabajador = rs.getString("id_estado");
                nombreTrabajador = rs.getString("nombre_estado");

                cbxEstado.addItem(idTrabajador + " " + nombreTrabajador);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        
    }
public void TextosInicio(){
        txtNuevoEstado.setEnabled(false);
        txtFechaSalida.setEnabled(false);
        txtCosto.setEnabled(false);
        txtEstadoBuscar.setEnabled(false);
        
    }
 public void BotonesInicio(){
        btnBuscarPorEstado.setEnabled(false);
        btnFinalizarReparacion.setEnabled(false);
        btnModificarEstado.setEnabled(false);
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jlalogo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jlblinicio = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblIdCliente = new javax.swing.JLabel();
        txtIdCliente = new javax.swing.JTextField();
        lblIdReparador = new javax.swing.JLabel();
        lblEstado = new javax.swing.JLabel();
        lblCosto = new javax.swing.JLabel();
        txtCosto = new javax.swing.JTextField();
        lblFechaIngreso = new javax.swing.JLabel();
        txtFechaIngreso = new javax.swing.JTextField();
        lblFechaSalida = new javax.swing.JLabel();
        txtFechaSalida = new javax.swing.JTextField();
        lblIdReparacion = new javax.swing.JLabel();
        txtIdReparacion = new javax.swing.JTextField();
        lblNuevoEstado = new javax.swing.JLabel();
        txtNuevoEstado = new javax.swing.JTextField();
        lblEstadoBuscar = new javax.swing.JLabel();
        txtEstadoBuscar = new javax.swing.JTextField();
        cbxReparador = new javax.swing.JComboBox<>();
        cbxEstado = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        btnAgregarReparacion = new javax.swing.JButton();
        btnModificarEstado = new javax.swing.JButton();
        btnFinalizarReparacion = new javax.swing.JButton();
        btnBuscarPorEstado = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jCalendar1 = new com.toedter.calendar.JCalendar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(130, 123, 123));
        jPanel2.setForeground(new java.awt.Color(130, 123, 123));
        jPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel2MouseClicked(evt);
            }
        });

        jlalogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Logo.png"))); // NOI18N
        jlalogo.setText("jLabel1");

        jLabel2.setBackground(new java.awt.Color(255, 204, 0));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Demi", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 204, 0));
        jLabel2.setText("Reparaciones");

        jlblinicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/inicio.png"))); // NOI18N
        jlblinicio.setText("jLabel1");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlalogo, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlblinicio, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jlalogo, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jlblinicio, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblIdCliente.setText("Cliente");

        lblIdReparador.setText("Reparador");

        lblEstado.setText("Estado");

        lblCosto.setText("Costo");

        lblFechaIngreso.setText("Fecha Ingreso");

        lblFechaSalida.setText("Fecha Salida");

        lblIdReparacion.setText("Reparacion");

        lblNuevoEstado.setText("Nuevo Estado");

        lblEstadoBuscar.setText("Estado a Buscar");

        cbxReparador.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        cbxReparador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxReparadorActionPerformed(evt);
            }
        });

        cbxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblEstadoBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtEstadoBuscar))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblIdReparador)
                        .addGap(41, 41, 41)
                        .addComponent(cbxReparador, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(lblEstado)
                                .addGap(60, 60, 60))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(lblFechaIngreso)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbxEstado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtFechaIngreso)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblIdCliente)
                        .addGap(61, 61, 61)
                        .addComponent(txtIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNuevoEstado)
                            .addComponent(lblFechaSalida)
                            .addComponent(lblCosto)
                            .addComponent(lblIdReparacion))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtIdReparacion)
                            .addComponent(txtNuevoEstado)
                            .addComponent(txtFechaSalida)
                            .addComponent(txtCosto))))
                .addGap(79, 166, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIdCliente)
                    .addComponent(txtIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIdReparador)
                    .addComponent(cbxReparador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblEstado)
                    .addComponent(cbxEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFechaIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFechaIngreso))
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIdReparacion)
                    .addComponent(txtIdReparacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNuevoEstado)
                    .addComponent(txtNuevoEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFechaSalida)
                    .addComponent(txtFechaSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCosto))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEstadoBuscar)
                    .addComponent(txtEstadoBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(125, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnAgregarReparacion.setText("Agregar Reparacion");
        btnAgregarReparacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarReparacionActionPerformed(evt);
            }
        });

        btnModificarEstado.setText("Modificar Estado");
        btnModificarEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarEstadoActionPerformed(evt);
            }
        });

        btnFinalizarReparacion.setText("Finalizar Reparacion");
        btnFinalizarReparacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarReparacionActionPerformed(evt);
            }
        });

        btnBuscarPorEstado.setText("Buscar por Estado");
        btnBuscarPorEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarPorEstadoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(72, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBuscarPorEstado)
                    .addComponent(btnFinalizarReparacion)
                    .addComponent(btnModificarEstado)
                    .addComponent(btnAgregarReparacion))
                .addGap(52, 52, 52))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnAgregarReparacion)
                .addGap(42, 42, 42)
                .addComponent(btnModificarEstado)
                .addGap(48, 48, 48)
                .addComponent(btnFinalizarReparacion)
                .addGap(44, 44, 44)
                .addComponent(btnBuscarPorEstado)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jCalendar1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jCalendar1PropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(80, 80, 80)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 507, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarReparacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarReparacionActionPerformed
        // TODO add your handling code here:
        agregarReparacion();

    }//GEN-LAST:event_btnAgregarReparacionActionPerformed

    private void btnModificarEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarEstadoActionPerformed
        // TODO add your handling code here:
        modificarEstadoReparacion();

    }//GEN-LAST:event_btnModificarEstadoActionPerformed

    private void btnFinalizarReparacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizarReparacionActionPerformed
        // TODO add your handling code here:
        finalizarReparacion();

    }//GEN-LAST:event_btnFinalizarReparacionActionPerformed

    private void btnBuscarPorEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarPorEstadoActionPerformed
        // TODO add your handling code here:
        buscarReparacionPorEstado();

    }//GEN-LAST:event_btnBuscarPorEstadoActionPerformed

    private void cbxReparadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxReparadorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxReparadorActionPerformed

    private void jCalendar1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jCalendar1PropertyChange

        if (evt.getOldValue() != null) {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    txtFechaIngreso.setText(dateFormat.format(jCalendar1.getCalendar().getTime()));
}

    }//GEN-LAST:event_jCalendar1PropertyChange

    private void jPanel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel2MouseClicked
        // TODO add your handling code here:
         Principal prin=new Principal();
            prin.setVisible(true);
            dispose(); 
    }//GEN-LAST:event_jPanel2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reparaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reparaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reparaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reparaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reparaciones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarReparacion;
    private javax.swing.JButton btnBuscarPorEstado;
    private javax.swing.JButton btnFinalizarReparacion;
    private javax.swing.JButton btnModificarEstado;
    private javax.swing.JComboBox<String> cbxEstado;
    private javax.swing.JComboBox<String> cbxReparador;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel jlalogo;
    private javax.swing.JLabel jlblinicio;
    private javax.swing.JLabel lblCosto;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JLabel lblEstadoBuscar;
    private javax.swing.JLabel lblFechaIngreso;
    private javax.swing.JLabel lblFechaSalida;
    private javax.swing.JLabel lblIdCliente;
    private javax.swing.JLabel lblIdReparacion;
    private javax.swing.JLabel lblIdReparador;
    private javax.swing.JLabel lblNuevoEstado;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtEstadoBuscar;
    private javax.swing.JTextField txtFechaIngreso;
    private javax.swing.JTextField txtFechaSalida;
    private javax.swing.JTextField txtIdCliente;
    private javax.swing.JTextField txtIdReparacion;
    private javax.swing.JTextField txtNuevoEstado;
    // End of variables declaration//GEN-END:variables
}
